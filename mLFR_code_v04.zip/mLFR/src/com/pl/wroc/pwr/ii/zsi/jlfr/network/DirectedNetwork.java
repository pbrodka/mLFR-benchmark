package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class DirectedNetwork extends Network {
    protected final List<Set<Integer>> inAdjacencyMatrix;

    public DirectedNetwork(int numberOfNodes) {
        super(numberOfNodes);
        this.inAdjacencyMatrix = new ArrayList<Set<Integer>>();
    }

    @Override
    public void onInit() {
        for (int i = 0; i < numberOfNodes; i++) {
            inAdjacencyMatrix.add(new TreeSet<Integer>());
            adjacencyMatrix.add(new TreeSet<Integer>());
            memberList.add(new ArrayList<Integer>());
        }
    }

    public List<Set<Integer>> getInAdjacencyMatrix() {
        return inAdjacencyMatrix;
    }

    public List<Set<Integer>> getOutAdjacencyMatrix() {
        return getAdjacencyMatrix();
    }

    @Override
    public List<Set<Integer>> getAdjacencyMatrix() {
        return adjacencyMatrix;
    }
}
