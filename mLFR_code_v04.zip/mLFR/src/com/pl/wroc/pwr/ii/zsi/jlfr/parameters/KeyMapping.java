package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

import static com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType.D;
import static com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType.DW;
import static com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType.UU;
import static com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType.W;
import static com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType.DoubleType;
import static com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType.IntegerType;
import static com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType.PercentageType;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;

public enum KeyMapping {
    /** Number of nodes */
    N(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Average degree */
    AVG(DoubleType, 0., 0., null, SupportedNetworks.ALL),
    /** Max degree */
    MAX(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Mixing */
    MIX(DoubleType, 0., 0., 1., SupportedNetworks.ALL),
    /** Powerlaw parameter: degree */
    TAU1(DoubleType, 2.0, 0., null, SupportedNetworks.ALL),
    /** Powerlaw parameter: community size */
    TAU2(DoubleType, 1.0, 0., null, SupportedNetworks.ALL),
    /** Number of overlapping nodes */
    ON(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Number of overlapping memberships */
    OM(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Maximal community size */
    MAXCOM(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Minimal community size */
    MINCOM(IntegerType, 0, 0, null, SupportedNetworks.ALL),
    /** Number of layers */
    L(IntegerType, 1, 1, null, SupportedNetworks.ALL),
    /** Degree change chance (from 0 to 1) */
    DC(PercentageType, 0., 0., 1., SupportedNetworks.ALL),
    /** Relocating membership chance (from 0 to 1) */
    RC(PercentageType, 0., 0., 1., SupportedNetworks.ALL),
    /** Number of nodes */
    MPARAM1(DoubleType, 2.0, 0., null, SupportedNetworks.ALL),

    MIXW(DoubleType, 0.2, 0.0, 1., SupportedNetworks.WEIGHTED), TAU3(DoubleType, 1.5, 0., null,
            SupportedNetworks.WEIGHTED);

    private static enum SupportedNetworks {
        ALL(UU, D, W, DW), WEIGHTED(W, DW);

        private NetworkType[] networkTypes;

        private SupportedNetworks(NetworkType... networkTypes) {
            this.networkTypes = networkTypes;
        }

        public NetworkType[] getNetworkTypes() {
            return networkTypes;
        }
    }

    private static final Messages messages = Messages.getInstance();
    private final Object defaultValue;
    private final boolean obligatory;
    private final List<NetworkType> networkTypes;
    private final InputType inputType;
    private final Object minimum;
    private final Object maximum;

    private KeyMapping(InputType inputType, Object defaultValue, Object minimum, Object maximum,
            SupportedNetworks supportedNetwork) {
        this.inputType = inputType;
        this.defaultValue = defaultValue;
        this.minimum = minimum;
        this.maximum = maximum;
        obligatory = defaultValue == null;
        this.networkTypes = Arrays.asList(supportedNetwork.getNetworkTypes());
    }

    public Object getMinimum() {
        return minimum;
    }

    public Object getMaximum() {
        return maximum;
    }

    public InputType getInputType() {
        return inputType;
    }

    public Object getDefaultValue() {
        return defaultValue;
    }

    public boolean isObligatory() {
        return obligatory;
    }

    public static List<KeyMapping> getAllForNetwork(NetworkType type) {
        List<KeyMapping> result = new ArrayList<KeyMapping>();
        for (KeyMapping keyMapping : KeyMapping.values()) {
            if (keyMapping.networkTypes.contains(type)) {
                result.add(keyMapping);
            }
        }
        return result;
    }

    public String toString() {
        return messages.getMessage(this);
    }
}
