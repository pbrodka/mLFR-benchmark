package com.pl.wroc.pwr.ii.zsi.jlfr.gui.cellrenderers;

import java.awt.Component;
import java.awt.Font;
import java.text.NumberFormat;
import java.util.Locale;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import com.pl.wroc.pwr.ii.zsi.jlfr.gui.table.ParameterTable;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;

public class ParameterCellRenderer extends JLabel implements TableCellRenderer {
    private final static Messages messages = Messages.getInstance();
    private NumberFormat numberFormat;
    private NumberFormat percentageFormat;

    public ParameterCellRenderer() {
        this(2, 2, Locale.ENGLISH);
    }

    public ParameterCellRenderer(int minimumFractionDigits, int maximumFractionDigits, Locale locale) {
        setHorizontalAlignment(CENTER);
        numberFormat = NumberFormat.getNumberInstance(locale);
        percentageFormat = NumberFormat.getPercentInstance(locale);
        setFractionDigits(numberFormat, minimumFractionDigits, maximumFractionDigits);
        setFractionDigits(percentageFormat, minimumFractionDigits, maximumFractionDigits);
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
            boolean hasFocus, int rowIndex, int colIndex) {
        ParameterTable parameterTable = (ParameterTable) table;
        InputType inputTypeForRow = parameterTable.getInputTypeForRow(rowIndex);

        // Configure the component with the specified value
        if (value != null) {
            String returnedValue = "";
            try {
                switch (inputTypeForRow) {
                case IntegerType:
                    returnedValue = numberFormat.format(Integer.parseInt(value.toString()));
                    break;
                case DoubleType:
                    returnedValue = numberFormat.format(Double.parseDouble(value.toString()));
                    break;
                case PercentageType:
                    returnedValue = percentageFormat.format(Double.parseDouble(value.toString()));
                }
                setText(returnedValue);
            } catch (NumberFormatException e) {
                System.out.println(e);
            }
        }

        if (colIndex == 0) {
            Font newLabelFont = new Font(getFont().getName(), Font.ITALIC, getFont().getSize());

            setFont(newLabelFont);
        } else {
            setToolTip(table, rowIndex, colIndex);
        }

        // Since the renderer is a component, return itself
        return this;
    }

    private void setToolTip(JTable table, int rowIndex, int colIndex) {
        KeyMapping keyMapping = (KeyMapping) table.getValueAt(rowIndex, 0);

        String tooltipKey = keyMapping.getClass().getCanonicalName().toString() + "."
                + keyMapping.name() + ".tooltip";
        setToolTipText(messages.getMessage(tooltipKey));
    }

    private void setFractionDigits(NumberFormat numberFormat, int minimumFractionDigits,
            int maximumFractionDigits) {
        numberFormat.setMaximumFractionDigits(maximumFractionDigits);
        numberFormat.setMinimumFractionDigits(minimumFractionDigits);
    }
}
