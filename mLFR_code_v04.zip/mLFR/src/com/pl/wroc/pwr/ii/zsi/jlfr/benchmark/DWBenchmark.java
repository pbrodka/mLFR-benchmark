package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.DirectedWeightedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRWeightedNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class DWBenchmark extends LFRDirectedBenchmark<DirectedWeightedNetwork> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    private final LFRWeightedNetworkParameters parameters;

    public DWBenchmark(LFRWeightedNetworkParameters parameters) {
        super(parameters);
        this.parameters = parameters;
    }

    @Override
    public MultiLayeredNetwork<DirectedWeightedNetwork> generate() throws BenchmarkException {
        MultiLayeredNetwork<DirectedWeightedNetwork> network = NetworkFactory
                .createMultiLayeredDirectedWeightedNetwork(parameters);

        writer.println(messages.getMessage("Benchmark.StartGeneration"), true, true);

        List<Integer> inDegreeSequence = new ArrayList<Integer>();
        List<Integer> outDegreeSequence = new ArrayList<Integer>();

        getDegreeSequences(inDegreeSequence, outDegreeSequence);

        Map<Integer, List<List<Integer>>> memberMatrixML = new HashMap<Integer, List<List<Integer>>>();
        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberMatrixML.put(layer, new ArrayList<List<Integer>>());
        }

        List<Integer> numSeq = new ArrayList<Integer>();
        List<Integer> inInternalDegreeSeq = new ArrayList<Integer>();
        List<Integer> outInternalDegreeSeq = new ArrayList<Integer>();

        internalDegreeAndMembership(memberMatrixML.get(0), inDegreeSequence, outDegreeSequence,
                numSeq, inInternalDegreeSeq, outInternalDegreeSeq);

        List<DirectedWeightedNetwork> layers = network.getLayers();

        Map<Integer, List<List<Integer>>> linkListInML = new HashMap<Integer, List<List<Integer>>>(); // row
        Map<Integer, List<List<Integer>>> linkListOutML = new HashMap<Integer, List<List<Integer>>>(); // row

        Map<Integer, List<List<Integer>>> memberListML = new HashMap<Integer, List<List<Integer>>>(); // row

        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberListML.put(layer, layers.get(layer).getMemberList());
            linkListInML.put(layer, new ArrayList<List<Integer>>());
            linkListOutML.put(layer, new ArrayList<List<Integer>>());

        }

        DirectedWeightedNetwork baseLayer = layers.get(0);

        buildSubgraphs(layers.get(0), memberMatrixML.get(0), memberListML.get(0),
                linkListInML.get(0), linkListOutML.get(0), inInternalDegreeSeq, inDegreeSequence,
                outInternalDegreeSeq, outDegreeSequence);

        for (int i = 0; i < baseLayer.getInAdjacencyMatrix().size(); i++) {
            if (baseLayer.getInAdjacencyMatrix().get(i).size() != linkListInML.get(0).get(i).get(0)) {
                linkListInML.get(0).get(i).set(0, baseLayer.getInAdjacencyMatrix().get(i).size());
            }
        }
        for (int i = 0; i < baseLayer.getOutAdjacencyMatrix().size(); i++) {
            if (baseLayer.getOutAdjacencyMatrix().get(i).size() != linkListOutML.get(0).get(i)
                    .get(0)) {
                linkListOutML.get(0).get(i).set(0, baseLayer.getOutAdjacencyMatrix().get(i).size());
            }
        }

        initializeLayers(memberMatrixML, memberListML, linkListInML, linkListOutML);

        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListInML);
        }
        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListOutML);
        }
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListInML);
        }
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListOutML);
        }

        buildLayers(layers, memberMatrixML, memberListML, linkListInML, linkListOutML);

        writer.println(messages.getMessage("Benchmark.ConnectingCommunities"), true, true);
        for (int layer = 0; layer < layers.size(); layer++) {
            connectAllTheParts(layers.get(layer).getInAdjacencyMatrix(), layers.get(layer)
                    .getOutAdjacencyMatrix(), memberListML.get(layer), linkListInML.get(layer),
                    linkListOutML.get(layer));
        }

        writer.println(messages.getMessage("Benchmark.IntroducingWeights"), true, true);
        // Map<Integer, List<Map<Integer, Double>>> neighboursWeightsInML =
        // network.g
        // Map<Integer, List<Map<Integer, Double>>> neighboursWeightsOutML =
        // new HashMap<Integer, List<Map<Integer, Double>>>();
        for (int layer = 0; layer < layers.size(); layer++) {
            // neighboursWeightsInML.put(layer, new ArrayList<Map<Integer,
            // Double>>());
            // neighboursWeightsOutML.put(layer, new ArrayList<Map<Integer,
            // Double>>());
            DirectedWeightedNetwork directedWeightedNetwork = layers.get(layer);
            weights(directedWeightedNetwork.getInAdjacencyMatrix(),
                    directedWeightedNetwork.getOutAdjacencyMatrix(), memberListML.get(layer),
                    directedWeightedNetwork.getWeightsIn(), directedWeightedNetwork.getWeightsOut());
        }

        return network;
    }

    private void weights(List<Set<Integer>> adjacencyMatrixIn,
            List<Set<Integer>> adjacencyMatrixOut, List<List<Integer>> memberList,
            List<Map<Integer, Double>> neighboursWeightsIn,
            List<Map<Integer, Double>> neighboursWeightsOut) {

        double tStrength = 0;

        List<Integer> ve = new ArrayList<Integer>();
        // VE is the degree of the nodes (in + out)

        List<Integer> internalKinTop = new ArrayList<Integer>();
        // this is the internal degree of the nodes (in + out)

        for (int i = 0; i < adjacencyMatrixIn.size(); i++) {
            internalKinTop.add(Methods.internalKin(adjacencyMatrixIn, memberList, i)
                    + Methods.internalKin(adjacencyMatrixOut, memberList, i));
            ve.add(adjacencyMatrixIn.get(i).size() + adjacencyMatrixOut.get(i).size());
            tStrength += Math.pow(ve.get(i), parameters.getWeightDistributionExponent());
        }

        double[] strs = new double[ve.size()]; // strength of the nodes
        // build a matrix like this: deque < map <int, double > > each row
        // corresponds to link - weights

        for (int i = 0; i < ve.size(); i++) {

            for (int its : adjacencyMatrixIn.get(i)) {
                neighboursWeightsIn.get(i).put(its, 0.);
            }
            for (int its : adjacencyMatrixOut.get(i)) {
                neighboursWeightsOut.get(i).put(its, 0.);
            }
            strs[i] = Math.pow((double) ve.get(i), parameters.getWeightDistributionExponent());

        }

        List<Double> sInOutIdRow = new ArrayList<Double>(3);
        sInOutIdRow.add(0.0);
        sInOutIdRow.add(0.0);
        sInOutIdRow.add(0.0);

        List<List<Double>> wished = new ArrayList<List<Double>>(ve.size());
        // 3 numbers for each node: internal, idle and extra strength. the sum
        // of the three is strs[i]. wished is the theoretical, factual the
        // factual one.

        List<List<Double>> factual = new ArrayList<List<Double>>(ve.size());

        for (int i = 0; i < ve.size(); i++) {
            wished.add(new ArrayList<Double>(sInOutIdRow));
            factual.add(new ArrayList<Double>(sInOutIdRow));
        }

        double totVar = 0;

        for (int i = 0; i < ve.size(); i++) {
            List<Double> wishedI = wished.get(i);

            wishedI.set(0, (1. - parameters.getWeightsMixingParameter()) * strs[i]);
            wishedI.set(1, parameters.getWeightsMixingParameter() * strs[i]);

            factual.get(i).set(2, strs[i]);

            totVar += wishedI.get(0) * wishedI.get(0) + wishedI.get(1) * wishedI.get(1) + strs[i]
                    * strs[i];
        }

        double precision = 1e-9;
        double precision2 = 1e-2;
        double notBetterThan = Math.pow(tStrength, 2) * precision;

        int step = 0;

        while (true) {
            double preVar = totVar;

            for (int i = 0; i < ve.size(); i++) {
                propagate(neighboursWeightsIn, neighboursWeightsOut, ve, memberList, wished,
                        factual, i, totVar, strs, internalKinTop);
            }

            double relativeImprovement = (double) (preVar - totVar) / preVar;
            // cout<<"tot_var "<<tot_var<<"\trelative improvement: "<<relative_improvement<<endl;

            if (totVar < notBetterThan) {
                break;
            }
            if (relativeImprovement < precision2) {
                break;
            }
            step++;
        }
    }

    private int propagate(List<Map<Integer, Double>> neighboursWeightsIn,
            List<Map<Integer, Double>> neighboursWeightsOut, List<Integer> ve,
            List<List<Integer>> memberList, List<List<Double>> wished, List<List<Double>> factual,
            int i, double totVar, double[] strs, List<Integer> internalKinTop) {

        propagateOne(neighboursWeightsIn, ve, memberList, wished, factual, i, totVar, strs,
                internalKinTop, neighboursWeightsOut);
        propagateOne(neighboursWeightsOut, ve, memberList, wished, factual, i, totVar, strs,
                internalKinTop, neighboursWeightsIn);
        propagateTwo(neighboursWeightsIn, ve, memberList, wished, factual, i, totVar, strs,
                internalKinTop, neighboursWeightsOut);
        propagateTwo(neighboursWeightsOut, ve, memberList, wished, factual, i, totVar, strs,
                internalKinTop, neighboursWeightsIn);

        return 0;

    }

    private int propagateOne(List<Map<Integer, Double>> neighboursWeights, List<Integer> ve,
            List<List<Integer>> memberList, List<List<Double>> wished, List<List<Double>> factual,
            int i, double totVar, double[] strs, List<Integer> internalKinTop,
            List<Map<Integer, Double>> others) {
        double change = factual.get(i).get(2) / ve.get(i);

        double oldPartVar = 0;
        for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {
            if (itm.getValue() + change > 0) {
                for (int bw = 0; bw < 3; bw++) {
                    oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                            .get(bw))
                            * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey()).get(bw));
                }
            }
        }
        for (int bw = 0; bw < 3; bw++) {
            oldPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                    * (factual.get(i).get(bw) - wished.get(i).get(bw));
        }

        double newPartVar = 0;

        for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {
            if (Methods.theyAreMate(i, itm.getKey(), memberList)) {
                factual.get(itm.getKey()).set(0, factual.get(itm.getKey()).get(0) + change);
                factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                factual.get(i).set(0, factual.get(i).get(0) + change);
                factual.get(i).set(2, factual.get(i).get(2) - change);

            } else {

                factual.get(itm.getKey()).set(1, factual.get(itm.getKey()).get(1) + change);
                factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                factual.get(i).set(1, factual.get(i).get(1) + change);
                factual.get(i).set(2, factual.get(i).get(2) - change);

            }

            for (int bw = 0; bw < 3; bw++) {
                newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey()).get(bw))
                        * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey()).get(bw));
            }

            itm.setValue(itm.getValue() + change);
            Double mapValue = others.get(itm.getKey()).get(i);
            if (mapValue == null) {
                others.get(itm.getKey()).put(i, change);
            } else {
                others.get(itm.getKey()).put(i, mapValue + change);
            }
        }

        for (int bw = 0; bw < 3; bw++) {
            newPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                    * (factual.get(i).get(bw) - wished.get(i).get(bw));
        }
        totVar += newPartVar - oldPartVar;

        return 0;
    }

    private int propagateTwo(List<Map<Integer, Double>> neighboursWeights, List<Integer> ve,
            List<List<Integer>> memberList, List<List<Double>> wished, List<List<Double>> factual,
            int i, double totVar, double[] strs, List<Integer> internalKinTop,
            List<Map<Integer, Double>> others) {
        int internalNeighbour = internalKinTop.get(i);

        if (internalNeighbour != 0) {
            // in this case I rewire the difference strength

            double changeNN = (factual.get(i).get(0) - wished.get(i).get(0));

            double oldPartVar = 0;
            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {
                if (Methods.theyAreMate(i, itm.getKey(), memberList)) {

                    double change = changeNN / internalNeighbour;

                    if (itm.getValue() - change > 0) {
                        for (int bw = 0; bw < 3; bw++) {
                            oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }
                    }
                } else {

                    double change = changeNN / (ve.get(i) - internalNeighbour);

                    if (itm.getValue() + change > 0) {
                        for (int bw = 0; bw < 3; bw++) {
                            oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }
                    }
                }
            }

            for (int bw = 0; bw < 3; bw++) {
                oldPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }

            double newPartVar = 0;

            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {

                if (Methods.theyAreMate(i, itm.getKey(), memberList)) {
                    double change = changeNN / internalNeighbour;

                    if (itm.getValue() - change > 0) {
                        factual.get(itm.getKey()).set(0, factual.get(itm.getKey()).get(0) - change);
                        factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) + change);

                        factual.get(i).set(0, factual.get(i).get(0) - change);
                        factual.get(i).set(2, factual.get(i).get(2) + change);

                        for (int bw = 0; bw < 3; bw++) {
                            newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }

                        itm.setValue(itm.getValue() - change);
                        Double mapValue = others.get(itm.getKey()).get(i);
                        if (mapValue == null) {
                            others.get(itm.getKey()).put(i, change);
                        } else {
                            others.get(itm.getKey()).put(i, mapValue + change);
                        }
                    }

                }

                else {
                    double change = changeNN / (ve.get(i) - internalNeighbour);

                    if (itm.getValue() + change > 0) {
                        factual.get(itm.getKey()).set(1, factual.get(itm.getKey()).get(1) + change);
                        factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                        factual.get(i).set(1, factual.get(i).get(1) + change);
                        factual.get(i).set(2, factual.get(i).get(2) - change);

                        for (int bw = 0; bw < 3; bw++) {
                            newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }

                        itm.setValue(itm.getValue() + change);
                        Double mapValue = others.get(itm.getKey()).get(i);
                        if (mapValue == null) {
                            others.get(itm.getKey()).put(i, change);
                        } else {
                            others.get(itm.getKey()).put(i, mapValue + change);
                        }
                    }
                }
            }

            for (int bw = 0; bw < 3; bw++) {
                newPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }

            totVar += newPartVar - oldPartVar;

        }

        return 0;
    }

}
