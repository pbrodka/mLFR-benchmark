package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

public class LFRWeightedNetworkParameters extends LFRNetworkParameters {
    private double weightsMixingParameter;
    private double weightDistributionExponent;

    public double getWeightsMixingParameter() {
        return weightsMixingParameter;
    }

    public void setWeightsMixingParameter(Double weightsMixingParameter) {
        this.weightsMixingParameter = weightsMixingParameter;
    }

    public double getWeightDistributionExponent() {
        return weightDistributionExponent;
    }

    public void setWeightDistributionExponent(Double weightDistributionExponent) {
        this.weightDistributionExponent = weightDistributionExponent;
    }

}
