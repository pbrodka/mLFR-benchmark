package com.pl.wroc.pwr.ii.zsi.jlfr.generator;

public interface Task extends Runnable {
    public void setOnStartAction(TaskAction task);

    public void perform(TaskAction task);

    public void setOnEndAction(TaskAction task);
}
