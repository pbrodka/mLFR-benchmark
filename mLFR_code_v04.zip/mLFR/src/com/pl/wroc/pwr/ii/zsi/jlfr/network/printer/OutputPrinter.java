package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;

public interface OutputPrinter {

    void printNetwork(MultiLayeredNetwork<? extends INetwork> network,
            LFRNetworkParameters parameters, String destination);
}
