package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

public enum InputType {
    IntegerType, DoubleType, PercentageType, DistributionType;

    public Object convertToType(Object value) {
        String stringValue = value.toString();
        switch (this) {
        case IntegerType:
            return (Object) Integer.valueOf(stringValue);
        case DoubleType:
        case PercentageType:
            return (Object) Double.valueOf(stringValue);
        }
        throw new IllegalArgumentException("Type not supported.");
    }
}
