package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;

public abstract class AbstractNetwork implements INetwork {
    protected final List<List<Integer>> memberList;
    protected final List<Set<Integer>> adjacencyMatrix;

    protected final int numberOfNodes;

    protected AbstractNetwork(int numberOfNodes) {
        this.memberList = new ArrayList<List<Integer>>();
        this.adjacencyMatrix = new ArrayList<Set<Integer>>();

        this.numberOfNodes = numberOfNodes;
    }

    public void onInit() {
        for (int i = 0; i < numberOfNodes; i++) {
            memberList.add(new ArrayList<Integer>());
            adjacencyMatrix.add(new TreeSet<Integer>());
        }
    }

    @Override
    public List<List<Integer>> getMemberList() {
        return memberList;
    }

    @Override
    public int getNumberOfNodes() {
        return numberOfNodes;
    }

    @Override
    public List<Set<Integer>> getAdjacencyMatrix() {
        return adjacencyMatrix;
    }
}
