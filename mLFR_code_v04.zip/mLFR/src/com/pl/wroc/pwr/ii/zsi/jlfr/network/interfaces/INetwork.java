package com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces;

import java.util.List;
import java.util.Set;

public interface INetwork {

    List<Set<Integer>> getAdjacencyMatrix();

    List<List<Integer>> getMemberList();

    int getNumberOfNodes();
}
