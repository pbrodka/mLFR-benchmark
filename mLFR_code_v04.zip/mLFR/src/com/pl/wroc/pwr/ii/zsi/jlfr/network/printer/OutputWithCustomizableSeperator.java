package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

public abstract class OutputWithCustomizableSeperator implements OutputPrinter {

    protected String seperator = " ";

    public String getSeperator() {
        return seperator;
    }

    public void setSeperator(String seperator) {
        this.seperator = seperator;
    }
}
