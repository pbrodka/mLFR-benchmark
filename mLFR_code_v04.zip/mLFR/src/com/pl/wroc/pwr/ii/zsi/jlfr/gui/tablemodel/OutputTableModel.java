package com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputPrinter;

public class OutputTableModel extends AbstractTableModel {

    private static final Messages messages = Messages.getInstance();
    private static final String NAME_COLUMN = "Name";
    private static final String VALUE_COLUMN = "Enabled";

    List<OutputRow> allRows = new ArrayList<OutputRow>();

    public OutputTableModel(List<OutputPrinter> list) {
        for (OutputPrinter output : list) {
            allRows.add(new OutputRow(messages.getMessage(output.getClass().getName()), output));
        }
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 1) {
            return Boolean.class;
        }
        return super.getColumnClass(columnIndex);

    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public int getRowCount() {
        return allRows.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
        case 0:
            return getRow(rowIndex).getName();
        case 1:
            return getRow(rowIndex).isEnabled();
        }
        throw new IllegalArgumentException();
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return col == 1 ? true : false;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex == 1) {
            getRow(rowIndex).setEnabled((Boolean) aValue);
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    public OutputRow getRow(int rowIndex) {
        return allRows.get(rowIndex);
    }

    public String getColumnName(int columnIndex) {
        return columnIndex == 0 ? NAME_COLUMN : VALUE_COLUMN;
    }

    public List<OutputPrinter> getEnabledOutputPrinters() {
        List<OutputPrinter> enabledPrinters = new ArrayList<OutputPrinter>();
        for (OutputRow row : allRows) {
            if (row.isEnabled()) {
                enabledPrinters.add(row.getOutputer());
            }
        }
        return enabledPrinters;
    }

}
