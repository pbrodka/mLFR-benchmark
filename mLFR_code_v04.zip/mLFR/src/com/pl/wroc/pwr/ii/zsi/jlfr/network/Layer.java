package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class Layer {
    private final List<TreeSet<Integer>> adjacencyMatrix;
    private List<List<Integer>> memberList;

    public Layer() {
        super();
        this.adjacencyMatrix = new ArrayList<TreeSet<Integer>>();
        this.memberList = new ArrayList<List<Integer>>();
    }

    public Layer(int numberOfNodes) {
        this();
        for (int i = 0; i < numberOfNodes; i++) {
            adjacencyMatrix.add(new TreeSet<Integer>());
        }
    }

    public List<List<Integer>> getMemberList() {
        return memberList;
    }

    public void setMemberList(List<List<Integer>> memberList) {
        this.memberList = memberList;
    }

    public List<TreeSet<Integer>> getAdjacencyMatrix() {
        return adjacencyMatrix;
    }

}
