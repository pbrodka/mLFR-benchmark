package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.DirectedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class DBenchmark extends LFRDirectedBenchmark<DirectedNetwork> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    private final LFRNetworkParameters parameters;

    public DBenchmark(LFRNetworkParameters parameters) {
        super(parameters);
        this.parameters = parameters;
    }

    @Override
    public MultiLayeredNetwork<DirectedNetwork> generate() throws BenchmarkException {
        MultiLayeredNetwork<DirectedNetwork> network = NetworkFactory
                .createMultiLayeredDirectedNetwork(parameters);

        writer.println(messages.getMessage("Benchmark.StartGeneration"), true, true);

        List<Integer> inDegreeSequence = new ArrayList<Integer>();
        List<Integer> outDegreeSequence = new ArrayList<Integer>();

        getDegreeSequences(inDegreeSequence, outDegreeSequence);

        Map<Integer, List<List<Integer>>> memberMatrixML = new HashMap<Integer, List<List<Integer>>>();
        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberMatrixML.put(layer, new ArrayList<List<Integer>>());
        }

        List<Integer> numSeq = new ArrayList<Integer>();
        List<Integer> inInternalDegreeSeq = new ArrayList<Integer>();
        List<Integer> outInternalDegreeSeq = new ArrayList<Integer>();

        internalDegreeAndMembership(memberMatrixML.get(0), inDegreeSequence, outDegreeSequence,
                numSeq, inInternalDegreeSeq, outInternalDegreeSeq);

        List<DirectedNetwork> layers = network.getLayers();

        Map<Integer, List<List<Integer>>> linkListInML = new HashMap<Integer, List<List<Integer>>>(); // row
        Map<Integer, List<List<Integer>>> linkListOutML = new HashMap<Integer, List<List<Integer>>>(); // row

        Map<Integer, List<List<Integer>>> memberListML = new HashMap<Integer, List<List<Integer>>>(); // row

        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberListML.put(layer, layers.get(layer).getMemberList());
            linkListInML.put(layer, new ArrayList<List<Integer>>());
            linkListOutML.put(layer, new ArrayList<List<Integer>>());

        }

        DirectedNetwork baseLayer = layers.get(0);

        buildSubgraphs(baseLayer, memberMatrixML.get(0), memberListML.get(0), linkListInML.get(0),
                linkListOutML.get(0), inInternalDegreeSeq, inDegreeSequence, outInternalDegreeSeq,
                outDegreeSequence);

        for (int i = 0; i < baseLayer.getInAdjacencyMatrix().size(); i++) {
            if (baseLayer.getInAdjacencyMatrix().get(i).size() != linkListInML.get(0).get(i).get(0)) {
                linkListInML.get(0).get(i).set(0, baseLayer.getInAdjacencyMatrix().get(i).size());
            }
        }
        for (int i = 0; i < baseLayer.getOutAdjacencyMatrix().size(); i++) {
            if (baseLayer.getOutAdjacencyMatrix().get(i).size() != linkListOutML.get(0).get(i)
                    .get(0)) {
                linkListOutML.get(0).get(i).set(0, baseLayer.getOutAdjacencyMatrix().get(i).size());
            }
        }

        initializeLayers(memberMatrixML, memberListML, linkListInML, linkListOutML);

        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListInML);
        }
        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListOutML);
        }
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListInML);
        }
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListOutML);
        }

        buildLayers(layers, memberMatrixML, memberListML, linkListInML, linkListOutML);

        writer.println(messages.getMessage("Benchmark.ConnectingCommunities"), true, true);
        for (int layer = 0; layer < layers.size(); layer++) {
            connectAllTheParts(layers.get(layer).getInAdjacencyMatrix(), layers.get(layer)
                    .getOutAdjacencyMatrix(), memberListML.get(layer), linkListInML.get(layer),
                    linkListOutML.get(layer));
        }
        return network;
    }
}
