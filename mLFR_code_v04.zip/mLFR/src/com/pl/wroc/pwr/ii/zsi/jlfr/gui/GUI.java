package com.pl.wroc.pwr.ii.zsi.jlfr.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableColumn;

import com.pl.wroc.pwr.ii.zsi.jlfr.RunMode;
import com.pl.wroc.pwr.ii.zsi.jlfr.generator.Generator;
import com.pl.wroc.pwr.ii.zsi.jlfr.generator.GeneratorTask;
import com.pl.wroc.pwr.ii.zsi.jlfr.generator.TaskAction;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.table.ParameterTable;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel.OutputTableModel;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel.ParameterTableModel;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.AllLayersOutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.CommunityOutpitPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.GmlOutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.StandardOutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.TextAreaWriter;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class GUI extends JFrame {

    private static final Messages messages = Messages.getInstance();

    private static final RunMode runMode = RunMode.getInstance();
    private static final Writer writer = Writer.getInstance();

    private static final int PARAMETERS_PANEL_WIDTH = 250;
    private static final int PARAMETERS_PANEL_WIDTH_SPACE = 0;

    private NetworkType networkChosen = NetworkType.UU;
    private JTextArea messagesTextArea;
    private ParameterTableModel model = new ParameterTableModel();

    private JTextField outputTextField;

    private JTable outputTable;

    private JTable table = new ParameterTable(model);

    private JScrollPane scrollPane;

    private JPanel panelTable;

    private JTextField seperatorTextField;

    private JButton generateButton;

    private GUI() {
        super();
        initializeGUI();
    }

    private void initializeGUI() {

        // setJMenuBar(createMenu());

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(createTextArea(), BorderLayout.CENTER);
        mainPanel.add(createParametersPanel(), BorderLayout.EAST);
        mainPanel.add(createButtonsPanel(), BorderLayout.SOUTH);
        add(mainPanel);
        setFrameParameters();

    }

    private void setFrameParameters() {
        pack();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
        this.setMaximizedBounds(e.getMaximumWindowBounds());
        this.setTitle("mLFR");

        this.setSize(800, 600);
        this.setExtendedState(this.getExtendedState() | JFrame.MAXIMIZED_BOTH);
    }

    private Component createButtonsPanel() {
        JPanel panel = new JPanel();

        generateButton = new JButton();
        panel.add(generateButton);
        generateButton.setText("Generate");
        generateButton.setPreferredSize(new Dimension(100, 25));
        generateButton.addActionListener(new GenerateActionListener());

        return panel;
    }

    private JScrollPane createTextArea() {
        JScrollPane scrollPane = new JScrollPane();

        messagesTextArea = new JTextArea();
        messagesTextArea.setEditable(false);

        scrollPane.setViewportView(messagesTextArea);

        writer.addWriter(new TextAreaWriter(messagesTextArea));

        return scrollPane;
    }

    private JPanel createParametersPanel() {
        final JPanel panel = new JPanel();

        // JPanel chooseTypePanel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

        panel.setPreferredSize(new java.awt.Dimension(GUI.PARAMETERS_PANEL_WIDTH, 100));
        panel.setMaximumSize(new java.awt.Dimension(GUI.PARAMETERS_PANEL_WIDTH, 100));

        ComboBoxModel chooseTypeComboBoxModel = new DefaultComboBoxModel(NetworkType.values());

        JComboBox chooseTypeComboBox = new JComboBox();
        chooseTypeComboBox.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20));
        chooseTypeComboBox.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20));

        ItemListener listener = new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                networkChosen = (NetworkType) e.getItem();
                List<KeyMapping> keysToAssign = KeyMapping.getAllForNetwork(networkChosen);
                model.init(keysToAssign);
                model.fireTableDataChanged();
                panel.repaint();
                panel.revalidate();
                panel.validate();

            }
        };
        chooseTypeComboBox.addItemListener(listener);

        panel.add(chooseTypeComboBox);
        chooseTypeComboBox.setModel(chooseTypeComboBoxModel);

        panelTable = new JPanel();
        parametersTable(panelTable);
        panel.add(panelTable);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel outputFileChooserPanel = new JPanel();
        addOutputFileChooser(outputFileChooserPanel);
        panel.add(outputFileChooserPanel);

        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        seperatorTextField = new JTextField();
        seperatorTextField.setText("");
        seperatorTextField.setEditable(true);
        seperatorTextField.setPreferredSize(new Dimension(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20)));
        seperatorTextField.setMaximumSize(new Dimension(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20)));
        seperatorTextField.setHorizontalAlignment(JTextField.RIGHT);

        seperatorTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent event) {
                JTextField textField = (JTextField) event.getSource();
                String text = textField.getText();
                if (!text.startsWith("\"") || !text.endsWith("\"")) {
                    textField.setText("\"" + text + "\"");
                }
            }
        });
        seperatorTextField.addFocusListener(new FocusListener() {
            @Override
            public void focusLost(FocusEvent event) {
                JTextField textField = (JTextField) event.getSource();
                String text = textField.getText();
                if (!text.startsWith("\"") || !text.endsWith("\"")) {
                    textField.setText("\"" + text + "\"");
                }
            }

            @Override
            public void focusGained(FocusEvent arg0) {
            }
        });

        JLabel label = new JLabel("Output fields seperator");
        Font font = label.getFont();
        label.setFont(new Font(font.getFontName(), font.getStyle(), 9));

        JPanel labelPanel = new JPanel(new BorderLayout());
        labelPanel.setMinimumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 30));
        labelPanel.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 30));
        labelPanel.add(seperatorTextField, BorderLayout.NORTH);
        labelPanel.add(label, BorderLayout.EAST);

        panel.add(labelPanel);

        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JPanel outputPanel = new JPanel();
        outputTable(outputPanel);
        panel.add(outputPanel);

        panel.setPreferredSize(new Dimension(300, 600));

        Border loweredetched = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        TitledBorder title = BorderFactory.createTitledBorder(loweredetched, "Parameters");
        title.setTitleJustification(TitledBorder.RIGHT);
        panel.setBorder(title);
        return panel;
    }

    private void addOutputFileChooser(JPanel panel) {
        panel.setLayout(new BorderLayout());
        panel.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20));
        panel.setMinimumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 20));
        panel.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - GUI.PARAMETERS_PANEL_WIDTH_SPACE, 40));

        int buttonSize = 100;

        outputTextField = new JTextField();
        panel.add(outputTextField, BorderLayout.NORTH);
        outputTextField.setText("");
        outputTextField.setEditable(false);
        outputTextField.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - buttonSize - 5, 20));
        outputTextField.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE - buttonSize - 5, 20));

        JButton button = new JButton();
        button.setAlignmentX(RIGHT_ALIGNMENT);
        button.setText("Choose file");
        button.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent action) {
                generateButton.setEnabled(true);
                JFileChooser chooser = new JFileChooser(new File("."));
                int result = chooser.showSaveDialog(GUI.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    outputTextField.setText(chooser.getSelectedFile().getPath());
                }
            }
        });

        button.setPreferredSize(new Dimension(buttonSize, 20));
        button.setMaximumSize(new Dimension(buttonSize, 20));
        panel.add(button, BorderLayout.EAST);
    }

    private void parametersTable(JPanel panelTable) {

        // JPanel panel = new JPanel(new BorderLayout());

        List<KeyMapping> keysToAssign = KeyMapping.getAllForNetwork(networkChosen);

        model.init(keysToAssign);
        table.setModel(model);

        scrollPane = new JScrollPane(table);
        table.setFillsViewportHeight(true);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setColumnSelectionAllowed(true);

        TableColumn col = table.getColumnModel().getColumn(1);
        col.setPreferredWidth((int) (0.3 * table.getWidth()));

        panelTable.add(scrollPane);
        int tableHeight = table.getRowCount() * 16 + 54;
        scrollPane.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, tableHeight));
        // panelTable.setMinimumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
        // - GUI.PARAMETERS_PANEL_WIDTH_SPACE, tableHeight));
        // panelTable.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
        // - GUI.PARAMETERS_PANEL_WIDTH_SPACE, tableHeight));
        panelTable.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, tableHeight));
    }

    private void outputTable(JPanel panelTable) {

        List<OutputPrinter> outputList = Arrays.asList(new StandardOutputPrinter(),
                new AllLayersOutputPrinter(), new GmlOutputPrinter());
        OutputTableModel outputModel = new OutputTableModel(outputList);

        outputTable = new JTable(outputModel);

        JScrollPane scrollPane = new JScrollPane(outputTable);
        outputTable.setFillsViewportHeight(true);

        outputTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        outputTable.setColumnSelectionAllowed(true);

        TableColumn col = outputTable.getColumnModel().getColumn(1);
        col.setPreferredWidth((int) (0.3 * outputTable.getWidth()));

        panelTable.add(scrollPane);
        scrollPane.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, outputTable.getRowCount() * 16 + 22));
        panelTable.setMinimumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, outputTable.getRowCount() * 16 + 22));
        panelTable.setPreferredSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, outputTable.getRowCount() * 16 + 22));
        panelTable.setMaximumSize(new Dimension(GUI.PARAMETERS_PANEL_WIDTH
                - GUI.PARAMETERS_PANEL_WIDTH_SPACE, outputTable.getRowCount() * 16 + 22));
    }

    // private JMenuBar createMenu() {
    // JMenuBar menuBar = new JMenuBar();
    //
    // JMenu menuFile = new JMenu();
    // menuBar.add(menuFile);
    // menuFile.setText("File");
    //
    // JMenu menuHelp = new JMenu();
    // menuBar.add(menuHelp);
    // menuHelp.setText("Help");
    //
    // return menuBar;
    // }

    public static void main(final String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                for (String arg : args) {
                    if (arg.equals(RunMode.EXPERT_MODE)) {
                        runMode.setExpertMode(true);
                    }
                }
                GUI instance = new GUI();
                instance.setLocationRelativeTo(null);
                instance.setVisible(true);
            }
        });
    }

    private class GenerateActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent action) {
            messagesTextArea.setText("");
            generateButton.setEnabled(false);

            List<OutputPrinter> outputPrinters = ((OutputTableModel) outputTable.getModel())
                    .getEnabledOutputPrinters();
            outputPrinters.add(new CommunityOutpitPrinter());

            String outputDestination = outputTextField.getText();
            if (!isOutputParameterDefined(outputDestination, outputPrinters)) {
                return;
            }
            outputDestination = rectifyPath(outputDestination);

            Map<KeyMapping, String> parametersMap = model.getAsMap();

            String seperator = seperatorTextField.getText();
            if (seperator.equals("") || seperator.length() < 3) {
                seperator = " ";
            } else {
                seperator = seperator.substring(1, seperator.length() - 1);
            }
            Cursor hourglassCursor = new Cursor(Cursor.WAIT_CURSOR);
            setCursor(hourglassCursor);
            messagesTextArea.setCursor(hourglassCursor);

            Generator generator = new Generator(networkChosen, parametersMap, outputDestination,
                    outputPrinters, seperator);
            GeneratorTask generationTask = new GeneratorTask(generator);
            TaskAction onStart = new TaskAction() {
                @Override
                public void perform() {
                    setPerforming(true);
                }
            };

            TaskAction onEnd = new TaskAction() {
                @Override
                public void perform() {
                    setPerforming(false);
                }
            };
            generationTask.setOnStartAction(onStart);
            generationTask.setOnEndAction(onEnd);

            Thread generationThread = new Thread(generationTask);
            generationThread.start();
        }

        private String rectifyPath(String outputDestination) {
            File file = new File(outputDestination);
            if (file.isDirectory()) {
                return outputDestination = outputDestination + "\\" + "network"
                        + new Date().getTime();
            }
            return outputDestination;
        }

        private boolean isOutputParameterDefined(String outputDestination,
                List<OutputPrinter> outputPrinters) {
            if (outputDestination.equals("") || outputDestination == null) {
                messagesTextArea
                        .append(messages.getErrorMessage("MessageArea.NoOutputPathDefined"));
                return false;
            }
            if (outputPrinters.size() == 0) {
                messagesTextArea.append(messages
                        .getErrorMessage("MessageArea.NoOutputPrinterDefined"));
                return false;
            }
            return true;
        }
    }

    private void setPerforming(boolean performing) {
        Cursor cursor = performing ? new Cursor(Cursor.WAIT_CURSOR) : new Cursor(
                Cursor.DEFAULT_CURSOR);
        messagesTextArea.setCursor(cursor);
        setCursor(cursor);
        generateButton.setEnabled(!performing);
    }
}
