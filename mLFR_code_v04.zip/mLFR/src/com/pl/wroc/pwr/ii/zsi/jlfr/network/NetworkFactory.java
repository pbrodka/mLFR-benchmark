package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;

import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRWeightedNetworkParameters;

public class NetworkFactory {

    public static MultiLayeredNetwork<Network> createMultiLayeredNetwork(
            LFRNetworkParameters parameters) {
        MultiLayeredNetwork<Network> multiLayeredNetwork = new MultiLayeredNetwork<Network>(
                parameters.getNumberOfLayers());

        List<Network> layers = new ArrayList<Network>();
        for (int layerIndex = 0; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            Network network = new Network(parameters.getNumberOfNodes());
            network.onInit();
            layers.add(network);
        }
        multiLayeredNetwork.setLayers(layers);

        return multiLayeredNetwork;
    }

    public static MultiLayeredNetwork<WeightedNetwork> createMultiLayeredWeightedNetwork(
            LFRNetworkParameters parameters) {
        MultiLayeredNetwork<WeightedNetwork> multiLayeredNetwork = new MultiLayeredNetwork<WeightedNetwork>(
                parameters.getNumberOfLayers());

        List<WeightedNetwork> layers = new ArrayList<WeightedNetwork>();
        for (int layerIndex = 0; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            WeightedNetwork weightedNetwork = new WeightedNetwork(parameters.getNumberOfNodes());
            weightedNetwork.onInit();
            layers.add(weightedNetwork);
        }
        multiLayeredNetwork.setLayers(layers);

        return multiLayeredNetwork;
    }

    public static MultiLayeredNetwork<DirectedNetwork> createMultiLayeredDirectedNetwork(
            LFRNetworkParameters parameters) {
        MultiLayeredNetwork<DirectedNetwork> multiLayeredNetwork = new MultiLayeredNetwork<DirectedNetwork>(
                parameters.getNumberOfLayers());

        List<DirectedNetwork> layers = new ArrayList<DirectedNetwork>();
        for (int layerIndex = 0; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            DirectedNetwork directedNetwork = new DirectedNetwork(parameters.getNumberOfNodes());
            directedNetwork.onInit();
            layers.add(directedNetwork);
        }
        multiLayeredNetwork.setLayers(layers);

        return multiLayeredNetwork;
    }

    public static MultiLayeredNetwork<DirectedWeightedNetwork> createMultiLayeredDirectedWeightedNetwork(
            LFRWeightedNetworkParameters parameters) {
        MultiLayeredNetwork<DirectedWeightedNetwork> multiLayeredNetwork = new MultiLayeredNetwork<DirectedWeightedNetwork>(
                parameters.getNumberOfLayers());

        List<DirectedWeightedNetwork> layers = new ArrayList<DirectedWeightedNetwork>();
        for (int layerIndex = 0; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            DirectedWeightedNetwork directedWeightedNetwork = new DirectedWeightedNetwork(
                    parameters.getNumberOfNodes());
            directedWeightedNetwork.onInit();
            layers.add(directedWeightedNetwork);
        }
        multiLayeredNetwork.setLayers(layers);

        return multiLayeredNetwork;
    }
}
