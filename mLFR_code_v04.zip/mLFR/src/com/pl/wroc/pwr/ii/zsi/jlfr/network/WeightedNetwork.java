package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.IWeightedNetwork;

public class WeightedNetwork extends Network implements IWeightedNetwork {
    private final List<Map<Integer, Double>> weights;

    public WeightedNetwork(int numberOfNodes) {
        super(numberOfNodes);
        this.weights = new ArrayList<Map<Integer, Double>>();
    }

    @Override
    public void onInit() {
        for (int i = 0; i < numberOfNodes; i++) {
            adjacencyMatrix.add(new TreeSet<Integer>());
            weights.add(new TreeMap<Integer, Double>());
            memberList.add(new ArrayList<Integer>());
        }
    }

    @Override
    public List<Map<Integer, Double>> getWeights() {
        return weights;
    }
}
