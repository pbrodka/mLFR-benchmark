package com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel;

import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;

public class ParameterRow {

    private KeyMapping keyMapping;
    private Object value;

    public ParameterRow(KeyMapping mapping, Object defaultValue) {
        keyMapping = mapping;
        value = defaultValue;
    }

    public KeyMapping getKeyMapping() {
        return keyMapping;
    }

    public void setKeyMapping(KeyMapping keyMapping) {
        this.keyMapping = keyMapping;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

}
