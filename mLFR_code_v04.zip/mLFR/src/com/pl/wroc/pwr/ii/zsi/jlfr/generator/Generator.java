package com.pl.wroc.pwr.ii.zsi.jlfr.generator;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.pl.wroc.pwr.ii.zsi.jlfr.RunMode;
import com.pl.wroc.pwr.ii.zsi.jlfr.benchmark.Benchmark;
import com.pl.wroc.pwr.ii.zsi.jlfr.benchmark.BenchmarkFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputWithCustomizableSeperator;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.ParametersFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.ExpertUtils;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class Generator implements TaskAction {

    private static Writer writer = Writer.getInstance();
    private static RunMode runMode = RunMode.getInstance();
    private static Messages messages = Messages.getInstance();
    private final NetworkType type;
    private final Map<KeyMapping, String> parameterMap;
    private final String outputDestination;
    private final List<OutputPrinter> outputPrinters;
    private final String seperator;

    public Generator(NetworkType type, Map<KeyMapping, String> parameterMap,
            String outputDestination, List<OutputPrinter> outputPrinters, String seperator) {
        this.type = type;
        this.parameterMap = parameterMap;
        this.outputDestination = outputDestination;
        this.outputPrinters = outputPrinters;
        this.seperator = seperator;
    }

    @Override
    public void perform() {
        generate(type, parameterMap, outputDestination, outputPrinters, seperator);
    }

    private void generate(NetworkType type, Map<KeyMapping, String> parameterMap,
            String outputDestination, List<OutputPrinter> outputPrinters, String seperator) {

        if (runMode.isExpertMode()) {
            writer.println(messages.getMessage("Generator.ExpertMode"), true, true);
        }

        LFRNetworkParameters parameters = ParametersFactory.createParameters(type);
        ParametersFactory.extractParameters(type, parameters, parameterMap);

        ParametersFactory.setDistribution(parameters);

        // create appropriate Benchmark instance
        Benchmark<? extends INetwork> benchmark = BenchmarkFactory
                .createBenchmark(type, parameters);

        // validate parameters
        try {
            benchmark.validateParameters();

            // generate a network object
            Date beginTime = new Date();
            MultiLayeredNetwork<? extends INetwork> multiNetwork = benchmark.generate();
            Date endTime = new Date();
            writer.println(
                    messages.getMessage("Benchmark.EndGenerationPart1")
                            + ((double) (endTime.getTime() - beginTime.getTime()) / 1000)
                            + messages.getMessage("Benchmark.EndGenerationPart2"), true, true);

            if (runMode.isExpertMode()) {
                ExpertUtils.exportMode(parameters, multiNetwork.getLayers());
            }

            // print network
            for (OutputPrinter output : outputPrinters) {
                if (output instanceof OutputWithCustomizableSeperator) {
                    OutputWithCustomizableSeperator customizableOutput = (OutputWithCustomizableSeperator) output;
                    customizableOutput.setSeperator(seperator);
                }
                output.printNetwork(multiNetwork, parameters, outputDestination);
            }

        } catch (BenchmarkException e) {
            writer.println(e.getMessage(), true, true);

        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
}
