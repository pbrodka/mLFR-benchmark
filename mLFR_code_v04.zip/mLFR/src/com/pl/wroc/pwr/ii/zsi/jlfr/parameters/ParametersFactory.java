package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pl.wroc.pwr.ii.zsi.jlfr.distributions.PowerLaw;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class ParametersFactory {

    private static final Messages messages = Messages.getInstance();
    private static Writer writer = Writer.getInstance();

    private static Map<KeyMapping, Method> keyToMethodsMap;
    static {
        try {
            keyToMethodsMap = new HashMap<KeyMapping, Method>();
            keyToMethodsMap.put(KeyMapping.N,
                    LFRNetworkParameters.class.getMethod("setNumberOfNodes", Integer.class));
            keyToMethodsMap.put(KeyMapping.AVG,
                    LFRNetworkParameters.class.getMethod("setAverageDegree", Double.class));
            keyToMethodsMap.put(KeyMapping.MAX,
                    LFRNetworkParameters.class.getMethod("setMaxDegree", Integer.class));
            keyToMethodsMap.put(KeyMapping.TAU1,
                    LFRNetworkParameters.class.getMethod("setTau", Double.class));
            keyToMethodsMap.put(KeyMapping.TAU2,
                    LFRNetworkParameters.class.getMethod("setTau2", Double.class));
            keyToMethodsMap.put(KeyMapping.ON,
                    LFRNetworkParameters.class.getMethod("setOverlappingNodes", Integer.class));
            keyToMethodsMap
                    .put(KeyMapping.OM, LFRNetworkParameters.class.getMethod(
                            "setOverlappingMembership", Integer.class));
            keyToMethodsMap.put(KeyMapping.MINCOM,
                    LFRNetworkParameters.class.getMethod("setMinimalCommunity", Integer.class));
            keyToMethodsMap.put(KeyMapping.MAXCOM,
                    LFRNetworkParameters.class.getMethod("setMaximalCommunity", Integer.class));
            keyToMethodsMap.put(KeyMapping.L,
                    LFRNetworkParameters.class.getMethod("setNumberOfLayers", Integer.class));
            keyToMethodsMap.put(KeyMapping.DC,
                    LFRNetworkParameters.class.getMethod("setDegreeChangeChance", Double.class));
            keyToMethodsMap.put(KeyMapping.RC,
                    LFRNetworkParameters.class.getMethod("setRelocatingChance", Double.class));
            keyToMethodsMap
                    .put(KeyMapping.MPARAM1, LFRNetworkParameters.class.getMethod(
                            "setDistributionParameter1", Double.class));
            keyToMethodsMap.put(KeyMapping.MIX, LFRNetworkParameters.class.getMethod(
                    "setTopologyMixingParameter", Double.class));
            keyToMethodsMap.put(KeyMapping.TAU3, LFRWeightedNetworkParameters.class.getMethod(
                    "setWeightDistributionExponent", Double.class));
            keyToMethodsMap.put(KeyMapping.MIXW, LFRWeightedNetworkParameters.class.getMethod(
                    "setWeightsMixingParameter", Double.class));

        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            System.exit(-1);
        }
    }

    public static LFRNetworkParameters createParameters(NetworkType networkType) {

        switch (networkType) {
        case UU:
        case D:
            return new LFRNetworkParameters();
        case W:
        case DW:
            return new LFRWeightedNetworkParameters();
        }
        throw new IllegalArgumentException(
                "Unrecognized network type, please refer to readme file.");
    }

    public static void extractParameters(NetworkType type, NetworkParameters parameters,
            Map<KeyMapping, String> parametersMap) {
        writer.println(messages.getMessage("ParametersFactory.SetParameters"), true, true);

        try {
            for (KeyMapping key : KeyMapping.getAllForNetwork(type)) {

                if (parametersMap.containsKey(key)) {
                    InputType inputType = key.getInputType();

                    Object input = inputType.convertToType(parametersMap.get(key));

                    keyToMethodsMap.get(key).invoke(parameters, input);
                    writer.print("\t" + key + " set to: " + input, false, false);

                } else if (key.getDefaultValue() != null) {
                    keyToMethodsMap.get(key).invoke(parameters, key.getDefaultValue());
                    writer.print("\t" + key + " set to default value: " + key.getDefaultValue(),
                            false, false);

                } else if (key.isObligatory()) {
                    throw new IllegalArgumentException("Mandatory value for key: " + key
                            + " not specified.");
                }
            }

            writer.println("ParametersFactory.SetParametersSuccessful", true, true);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new IllegalArgumentException(
                    "Provided key not recognized or specified value for a key is not valid");
        }

    }

    public static void setDistribution(LFRNetworkParameters parameters) {
        List<Double> chances = Methods.powerlaw(parameters.getNumberOfLayers(), 1,
                parameters.getDistributionParameter1());
        parameters.setDistribution(new PowerLaw(chances));
    }

    public static Map<KeyMapping, String> getParametersAsAMapKeyValue(List<String> arguments) {
        Map<KeyMapping, String> parametersMap = new HashMap<KeyMapping, String>();

        for (int keyIndex = 1; keyIndex < arguments.size(); keyIndex += 2) {
            int valueIndex = keyIndex + 1;

            parametersMap.put(KeyMapping.valueOf(arguments.get(keyIndex).toUpperCase()),
                    arguments.get(valueIndex));

        }

        return parametersMap;
    }
}
