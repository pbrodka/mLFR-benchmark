package com.pl.wroc.pwr.ii.zsi.jlfr.network;

public class Network extends AbstractNetwork {

    public Network(int numberOfNodes) {
        super(numberOfNodes);
    }

}
