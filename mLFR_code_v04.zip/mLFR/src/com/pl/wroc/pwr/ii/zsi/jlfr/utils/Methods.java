package com.pl.wroc.pwr.ii.zsi.jlfr.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.DirectedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class Methods {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    public static void calculateMinimalDegree(LFRNetworkParameters p) throws BenchmarkException {
        p.setMinDegree((int) Methods.solveMinimalDegree(p));
        if (p.getMinDegree() == -1)
            throw new BenchmarkException("\n\nERROR\nMinimal degree could not be solved.");

        double media1 = Methods.integerAverage(p.getMaxDegree(), p.getMinDegree(), p.getTau());
        double media2 = Methods.integerAverage(p.getMaxDegree(), p.getMinDegree() + 1, p.getTau());

        if (Math.abs(media1 - p.getAverageDegree()) > Math.abs(media2 - p.getAverageDegree())) {
            p.setMinDegree(p.getMinDegree() + 1);
        }

    }

    public static double solveMinimalDegree(LFRNetworkParameters p) {
        double gamma = -p.getTau();
        double minDegreeLeft = 1;
        double minDegreeRight = p.getMaxDegree();
        double averageDegree1 = averageDegree(minDegreeRight, minDegreeLeft, gamma);
        double averageDegree2 = minDegreeRight;

        if ((averageDegree1 - p.getAverageDegree() > 0)
                || (averageDegree2 - p.getAverageDegree() < 0)) {

            writer.println(messages.getMessage("Methods.DegreeOutOfRange"), true, false);

            if (averageDegree1 - p.getAverageDegree() > 0) {
                writer.println("You should increase the average degree (bigger than "
                        + averageDegree1 + ") or decrease the maximum degree...", true, false);
            }
            if (averageDegree2 - p.getAverageDegree() < 0) {
                writer.println("You should decrease the average degree (smaller than "
                        + averageDegree2 + ") or increase the maximum degree...", true, false);
            }

            return -1;
        }

        while (Math.abs(averageDegree1 - p.getAverageDegree()) > 1e-7) {

            double temp = averageDegree(p.getMaxDegree(), ((minDegreeRight + minDegreeLeft) / 2.),
                    gamma);

            if ((temp - p.getAverageDegree()) * (averageDegree2 - p.getAverageDegree()) > 0) {

                averageDegree2 = temp;
                minDegreeRight = ((minDegreeRight + minDegreeLeft) / 2.);

            } else {

                averageDegree1 = temp;
                minDegreeLeft = ((minDegreeRight + minDegreeLeft) / 2.);

            }
        }

        return minDegreeLeft;
    }

    // it returns the average degree of a power law
    public static double averageDegree(double maxDegree, double dmin, double gamma) {
        return (1. / (integral(gamma, maxDegree) - integral(gamma, dmin)))
                * (integral(gamma + 1, maxDegree) - integral(gamma + 1, dmin));
    }

    // it computes the integral of a power law
    public static double integral(double a, double b) {

        if (Math.abs(a + 1.) > 1e-10) {
            return (1. / (a + 1.) * Math.pow(b, a + 1.));
        } else {
            return (Math.log(b));
        }
    }

    public static double integerAverage(int n, int min, double tau) {

        double a = 0;

        for (double h = min; h < n + 1; h++) {
            a += Math.pow((1. / h), tau);
        }
        double pf = 0;
        for (double i = min; i < n + 1; i++) {
            pf += 1 / a * Math.pow((1. / (i)), tau) * i;
        }
        return pf;

    }

    public static int lowerBound(List<? extends Number> array, Number value) {
        int first = 0;
        int last = array.size() - 1;
        int mid = (first + last) / 2;
        while (true) {
            if (array.get(mid).doubleValue() >= value.doubleValue()) {
                last = mid - 1;
                if (last < first) {
                    return mid;
                }
            } else {
                first = mid + 1;
                if (last < first) {
                    return mid < array.size() - 1 ? mid + 1 : -1;
                }
            }
            mid = (first + last) / 2;
        }
    }

    public static List<Double> powerlaw(int n, int min, double tau) {
        List<Double> result = new ArrayList<Double>();

        double a = 0;

        for (double h = min; h < n + 1; h++) {
            a += Math.pow((1. / h), tau);
        }
        Double pf = 0.0;
        for (double i = min; i < n + 1; i++) {

            pf += 1 / a * Math.pow((1. / (i)), tau);
            result.add(pf);

        }

        return result;
    }

    public static int degreeSum(List<Integer> list) {
        int sum = 0;
        for (int i : list) {
            sum += i;
        }
        return sum;
    }

    public static void computeInternalDegreePerNode(int d, int m, List<Integer> a) {
        // d is the internal degree
        // m is the number of membership

        a.clear();
        int d_i = d / m;
        for (int i = 0; i < m; i++) {
            a.add(d_i);
        }
        for (int i = 0; i < d % m; i++) {
            a.set(i, a.get(i) + 1);
        }
    }

    public static void changeCommunitySize(List<Integer> seq) throws BenchmarkException {
        if (seq.size() <= 2) {
            throw new BenchmarkException(
                    "\nERROR: this program needs more than one community to work fine");
        }
        int min1 = 0;
        int min2 = 0;

        for (int i = 0; i < seq.size(); i++) {
            if (seq.get(i) <= seq.get(min1)) {
                min1 = i;
            }
        }
        if (min1 == 0) {
            min2 = 1;
        }
        for (int i = 0; i < seq.size(); i++) {
            if (seq.get(i) <= seq.get(min2) && seq.get(i) > seq.get(min1)) {
                min2 = i;
            }
        }
        seq.set(min1, seq.get(min1) + seq.get(min2));

        int c = seq.get(0);
        seq.set(0, seq.get(min2));
        seq.set(min2, c);
        seq.remove(0);

    }

    public static boolean theyAreMate(int a, int b, List<List<Integer>> memberList) {
        for (int i = 0; i < memberList.get(a).size(); i++) {
            if (memberList.get(b).contains(memberList.get(a).get(i))) {
                return true;
            }
        }

        return false;

    }

    public static int shuffleS(List<Integer> sq) {
        int siz = sq.size();
        if (siz == 0) {
            return -1;
        }
        for (int i = 0; i < sq.size(); i++) {

            int randomPosition = (int) (Math.random() * siz);

            int randomCard = sq.get(randomPosition);

            sq.set(randomPosition, sq.get(siz - 1));
            sq.set(siz - 1, randomCard);
            siz--;
        }

        return 0;

    }

    public static int internalKin(List<Set<Integer>> E, List<List<Integer>> memberList, int i) {

        int varMate2 = 0;
        for (int itss : E.get(i)) {
            if (Methods.theyAreMate(i, itss, memberList)) {
                varMate2++;
            }
        }
        return varMate2;
    }

    public static int computeVarMate(List<TreeSet<Integer>> enIn, List<List<Integer>> memberList) {
        int varMate = 0;
        for (int i = 0; i < enIn.size(); i++) {
            for (int itss : enIn.get(i)) {
                if (Methods.theyAreMate(i, itss, memberList)) {
                    varMate++;
                }
            }
        }
        return varMate;
    }

    public static int neighboursCount(List<? extends INetwork> layers, int node, int nodeNeighbour) {
        int result = 0;
        for (int layer = 0; layer < layers.size(); layer++) {
            for (int neighbours : layers.get(layer).getAdjacencyMatrix().get(node)) {
                if (neighbours == nodeNeighbour) {
                    result++;
                    break;
                }
            }
        }
        return result;
    }

    public static int neighboursCountIn(List<? extends DirectedNetwork> layers, int node,
            int nodeNeighbour) {
        int result = 0;
        for (int layer = 0; layer < layers.size(); layer++) {
            for (int neighbours : layers.get(layer).getInAdjacencyMatrix().get(node)) {
                if (neighbours == nodeNeighbour) {
                    result++;
                    break;
                }
            }
        }
        return result;
    }
}