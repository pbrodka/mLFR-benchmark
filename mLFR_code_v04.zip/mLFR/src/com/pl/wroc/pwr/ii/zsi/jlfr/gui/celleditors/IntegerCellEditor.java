package com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors;

import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

public class IntegerCellEditor extends ParameterCellEditor {

    private JFormattedTextField field;
    private NumberFormat integerFormat;

    public IntegerCellEditor(JTable table) {
        this(table, null, null);
    }

    public IntegerCellEditor(JTable table, Integer min, Integer max) {
        super(table, new JFormattedTextField());
        field = (JFormattedTextField) getComponent();

        integerFormat = NumberFormat.getIntegerInstance(ParameterCellEditor.LOCALE);
        NumberFormatter formatter = new NumberFormatter(integerFormat);

        if (min != null) {
            formatter.setMinimum(min);
        }
        if (max != null) {
            formatter.setMaximum(max);
        }

        field.setFormatterFactory(new DefaultFormatterFactory(formatter));
    }

    public Object getCellEditorValue() {
        JFormattedTextField field = (JFormattedTextField) getComponent();
        Object o = field.getValue();
        if (o == null) {
            return null;
        }

        if (o instanceof Integer) {
            return o;
        } else if (o instanceof Number) {
            return new Integer(((Number) o).intValue());
        } else {

            try {
                return integerFormat.parseObject(o.toString());
            } catch (ParseException exc) {
                return null;
            }
        }
    }
}
