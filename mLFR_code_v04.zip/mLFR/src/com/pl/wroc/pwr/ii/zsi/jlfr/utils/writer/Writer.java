package com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Writer {

    public static final String NEW_LINE = System.getProperty("line.separator");
    private static final Writer instance = new Writer();
    private static final String MARKS = "***";
    private DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

    private Writer() {
        super();
    }

    public static Writer getInstance() {
        return instance;
    }

    List<IWriter> writers = new ArrayList<IWriter>();

    public void print(String message, boolean withMarks, boolean withDate) {
        println(message, withMarks, withDate, false);
    }

    public void println(String message, boolean withMarks, boolean withDate) {
        println(message, withMarks, withDate, true);
    }

    private void println(String message, boolean withMarks, boolean withDate, boolean newLine) {
        if (withDate) {
            message = dateFormat.format(new Date()) + " " + message;
        }

        if (withMarks) {
            message = MARKS + " " + message + " " + MARKS;
        }

        if (newLine) {
            message = NEW_LINE + message;
        }

        for (IWriter writer : writers) {
            writer.write(message);
        }

    }

    public void addWriter(IWriter writer) {
        writers.add(writer);
    }

    public void removeWriter(IWriter writer) {
        int indexToRemove = writers.indexOf(writer);
        if (indexToRemove >= 0) {
            writers.remove(indexToRemove);
        }
    }
}
