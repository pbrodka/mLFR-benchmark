package com.pl.wroc.pwr.ii.zsi.jlfr;

public class RunMode {

    public static final String EXPERT_MODE = "expert";
    public static final String GUI = "gui";

    private boolean expertMode = false;

    public static RunMode runMode = new RunMode();

    public static RunMode getInstance() {
        return runMode;
    }

    private RunMode() {
    }

    public boolean isExpertMode() {
        return expertMode;
    }

    public void setExpertMode(boolean expertMode) {
        this.expertMode = expertMode;
    }

}
