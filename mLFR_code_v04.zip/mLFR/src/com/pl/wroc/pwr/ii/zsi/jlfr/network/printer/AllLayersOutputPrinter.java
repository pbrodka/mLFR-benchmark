package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.IWeightedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;

public class AllLayersOutputPrinter extends OutputWithCustomizableSeperator {

    @Override
    public void printNetwork(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            LFRNetworkParameters parameters, String destination) {
        File file = new File(destination + "_all.txt");
        PrintWriter networkWriter = null;
        try {
            networkWriter = new PrintWriter(file);
            for (int layer = 0; layer < multiNetwork.getLayers().size(); layer++) {
                INetwork network = multiNetwork.getLayers().get(layer);
                if (network instanceof IWeightedNetwork) {
                    printWeightedNetwork((IWeightedNetwork) network, networkWriter, layer + 1);
                } else {
                    printNetwork(network, networkWriter, layer + 1);
                }
            }
        } catch (FileNotFoundException exception) {
        } finally {
            if (networkWriter != null) {
                networkWriter.flush();
                networkWriter.close();
            }
        }
    }

    public void printNetwork(INetwork network, PrintWriter networkWriter, int layerIndex) {
        for (int nodeIndex = 0; nodeIndex < network.getAdjacencyMatrix().size(); nodeIndex++) {
            for (int nodeNeighbour : network.getAdjacencyMatrix().get(nodeIndex)) {
                networkWriter.println(nodeIndex + 1 + seperator + (nodeNeighbour + 1) + seperator
                        + layerIndex);
            }
        }
    }

    public void printWeightedNetwork(IWeightedNetwork network, PrintWriter networkWriter,
            int layerIndex) {
        for (int nodeIndex = 0; nodeIndex < network.getAdjacencyMatrix().size(); nodeIndex++) {
            for (int nodeNeighbour : network.getAdjacencyMatrix().get(nodeIndex)) {
                networkWriter.println(nodeIndex + 1 + " " + (nodeNeighbour + 1) + seperator
                        + network.getWeights().get(nodeIndex).get(nodeNeighbour) + seperator
                        + layerIndex);
            }
        }
    }

}
