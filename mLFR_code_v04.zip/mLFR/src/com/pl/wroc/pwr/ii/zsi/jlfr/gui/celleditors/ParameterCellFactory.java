package com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors;

import javax.swing.JTable;

import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType;

public class ParameterCellFactory {

    public static ParameterCellEditor createParameterCellEditor(JTable table, InputType inputType,
            Object minimum, Object maximum) {
        switch (inputType) {
        case DoubleType:
        case PercentageType:
            Double minDouble = (Double) minimum;
            Double maxDouble = (Double) maximum;

            return new DoubleCellEditor(table, minDouble, maxDouble);
        case IntegerType:
            Integer minInt = (Integer) minimum;
            Integer maxInt = (Integer) maximum;
            return new IntegerCellEditor(table, minInt, maxInt);
        }
        throw new IllegalArgumentException();
    }
}
