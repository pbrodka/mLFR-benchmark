package com.pl.wroc.pwr.ii.zsi.jlfr.generator;

public class GeneratorTask implements Task {

    private TaskAction startAction;
    private TaskAction endAction;
    private TaskAction mainTask;

    public GeneratorTask(TaskAction mainTask) {
        this.mainTask = mainTask;
    }

    @Override
    public void run() {
        if (startAction != null) {
            startAction.perform();
        }
        mainTask.perform();
        if (endAction != null) {
            endAction.perform();
        }
    }

    @Override
    public void setOnStartAction(TaskAction task) {
        this.startAction = task;
    }

    @Override
    public void perform(TaskAction task) {
        this.mainTask = task;
    }

    @Override
    public void setOnEndAction(TaskAction task) {
        this.endAction = task;
    }
}
