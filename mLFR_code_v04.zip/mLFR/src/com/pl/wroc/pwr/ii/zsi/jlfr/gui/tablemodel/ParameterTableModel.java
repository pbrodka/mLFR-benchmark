package com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;

public class ParameterTableModel extends AbstractTableModel {

    private static final String KEY_COLUMN = "Key";
    private static final String VALUE_COLUMN = "Value";

    ArrayList<ParameterRow> allRows = new ArrayList<ParameterRow>();

    public ParameterTableModel() {
    }

    public void init(List<KeyMapping> keysToAssign) {
        allRows.clear();
        for (KeyMapping mapping : keysToAssign) {
            allRows.add(new ParameterRow(mapping, mapping.getDefaultValue()));
        }
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public int getRowCount() {
        return allRows.size();
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
        case 0:
            return getRow(rowIndex).getKeyMapping();
        case 1:
            return getRow(rowIndex).getValue();
        }
        throw new IllegalArgumentException();
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return col == 1 ? true : false;
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex == 1) {
            getRow(rowIndex).setValue(aValue);
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    public ParameterRow getRow(int rowIndex) {
        return allRows.get(rowIndex);
    }

    public Map<KeyMapping, String> getAsMap() {
        Map<KeyMapping, String> result = new HashMap<KeyMapping, String>();
        for (ParameterRow row : allRows) {
            result.put(row.getKeyMapping(), row.getValue().toString());
        }
        return result;
    }

    public String getColumnName(int columnIndex) {
        return columnIndex == 0 ? KEY_COLUMN : VALUE_COLUMN;
    }
}
