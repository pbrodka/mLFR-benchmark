package com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputPrinter;

public class OutputRow {
    private String name;
    private boolean enabled;
    private OutputPrinter outputer;

    public OutputRow(String name, OutputPrinter outputer) {
        this.name = name;
        this.outputer = outputer;
        enabled = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public OutputPrinter getOutputer() {
        return outputer;
    }

    public void setOutputer(OutputPrinter outputer) {
        this.outputer = outputer;
    }

}
