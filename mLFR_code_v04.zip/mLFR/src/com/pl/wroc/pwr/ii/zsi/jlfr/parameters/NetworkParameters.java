package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

public class NetworkParameters {
    // Storage class for parameters of generated network.
    public static final String NETWORK = "_net.txt";
    public static final String COMMUNITIES = "_com.txt";

    private String outputPath;

    public NetworkParameters() {
        super();
        outputPath = System.getProperty("user.dir") + "\\";
    }

    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }
}
