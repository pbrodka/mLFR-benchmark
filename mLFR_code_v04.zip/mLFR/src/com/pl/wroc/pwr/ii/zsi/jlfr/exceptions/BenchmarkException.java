package com.pl.wroc.pwr.ii.zsi.jlfr.exceptions;

public class BenchmarkException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = -8331950186424976806L;

	public BenchmarkException(String message) {
        super(message);
    }

    public BenchmarkException(Throwable cause) {
        super(cause);
    }

    public BenchmarkException(String message, Throwable cause) {
        super(message, cause);
    }

}
