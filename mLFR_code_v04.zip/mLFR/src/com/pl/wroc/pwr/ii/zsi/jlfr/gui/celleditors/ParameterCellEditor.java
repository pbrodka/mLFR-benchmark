package com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.util.Locale;

import javax.swing.AbstractAction;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.table.TableModel;

import com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel.ParameterTableModel;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public abstract class ParameterCellEditor extends DefaultCellEditor {

    public static final Messages messages = Messages.getInstance();
    public static final Writer writer = Writer.getInstance();
    public static final Locale LOCALE = Locale.ENGLISH;

    public ParameterCellEditor(final JTable table, final JFormattedTextField field) {
        super(field);

        field.setHorizontalAlignment(JTextField.TRAILING);
        field.setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);

        field.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "check");
        field.getActionMap().put("check", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                int col = table.getSelectedColumn();
                if (!field.isEditValid()) { // The text is invalid.
                    KeyMapping keyMapping = ((ParameterTableModel) table.getModel()).getRow(row)
                            .getKeyMapping();
                    String minimum = keyMapping.getMinimum().toString();
                    Object maximum = keyMapping.getMaximum();
                    if (maximum == null) {
                        maximum = "positive infinity";
                    }
                    writer.println(messages.getMessage(keyMapping)
                            + " value not proper. Please fill with " + " value. In range from "
                            + minimum + " to " + maximum + ".", false, false);
                    field.postActionEvent(); // inform the editor
                } else
                    try {
                        field.commitEdit();
                        field.postActionEvent();
                        TableModel tableModel = table.getModel();
                        if (row >= 0 && row < tableModel.getRowCount() && col >= 0
                                && col < tableModel.getColumnCount()) {
                            table.changeSelection(row + 1, col, false, false);
                        }
                    } catch (java.text.ParseException exc) {
                    }
            }
        });

        field.addFocusListener(new FocusListener() {

            @Override
            public void focusLost(FocusEvent event) {
                JFormattedTextField field = (JFormattedTextField) event.getSource();
                try {
                    field.commitEdit();
                    field.postActionEvent(); // stop editing
                } catch (ParseException e) {
                }
            }

            @Override
            public void focusGained(FocusEvent arg0) {
                field.requestFocus();
                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        field.selectAll();
                    }
                });
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
            int row, int column) {
        JFormattedTextField field = (JFormattedTextField) super.getTableCellEditorComponent(table,
                value, isSelected, row, column);
        field.setValue(value);
        return field;
    }

    public boolean stopCellEditing() {
        JFormattedTextField field = (JFormattedTextField) getComponent();
        if (field.isEditValid()) {
            try {
                field.commitEdit();
            } catch (ParseException exc) {
            }

        } else {
            field.selectAll();
            return false;
        }
        return super.stopCellEditing();
    }
}