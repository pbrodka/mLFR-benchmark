package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.IWeightedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;

public class StandardOutputPrinter extends OutputWithCustomizableSeperator {

    @Override
    public void printNetwork(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            LFRNetworkParameters parameters, String destination) {
        printNetworkResult(multiNetwork, destination);
    }

    private void printNetworkResult(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            String destination) {
        for (int i = 0; i < multiNetwork.getLayers().size(); i++) {
            String layerDestination = destination + "_Layer" + (i + 1) + "_Network.txt";
            INetwork layer = multiNetwork.getLayers().get(i);

            if (layer instanceof IWeightedNetwork) {
                printWeightedNetwork((IWeightedNetwork) layer, layerDestination);
            } else {
                printNetwork(layer, layerDestination);
            }
        }
    }

    public void printNetwork(INetwork network, String destination) {
        File file = new File(destination);
        PrintWriter networkWriter = null;
        try {
            networkWriter = new PrintWriter(file);

            for (int nodeIndex = 0; nodeIndex < network.getAdjacencyMatrix().size(); nodeIndex++) {

                for (int nodeNeighbour : network.getAdjacencyMatrix().get(nodeIndex)) {
                    networkWriter.println(nodeIndex + 1 + seperator + (nodeNeighbour + 1));
                }
            }
        } catch (FileNotFoundException exception) {
        } finally {
            if (networkWriter != null) {
                networkWriter.flush();
                networkWriter.close();
            }
        }
    }

    public void printWeightedNetwork(IWeightedNetwork network, String destination) {
        File file = new File(destination);
        PrintWriter networkWriter = null;
        try {
            networkWriter = new PrintWriter(file);

            for (int nodeIndex = 0; nodeIndex < network.getAdjacencyMatrix().size(); nodeIndex++) {
                for (int nodeNeighbour : network.getAdjacencyMatrix().get(nodeIndex)) {
                    networkWriter.println(nodeIndex + 1 + seperator + (nodeNeighbour + 1)
                            + seperator + network.getWeights().get(nodeIndex).get(nodeNeighbour));
                }
            }
        } catch (FileNotFoundException exception) {
        } finally {
            if (networkWriter != null) {
                networkWriter.flush();
                networkWriter.close();
            }
        }
    }
}
