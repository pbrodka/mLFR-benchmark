package com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer;

public class ConsoleWriter implements IWriter {

    @Override
    public void write(String message) {
        System.out.println(message);
    }

}
