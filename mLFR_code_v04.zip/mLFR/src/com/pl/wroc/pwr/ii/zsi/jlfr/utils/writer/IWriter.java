package com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer;

public interface IWriter {
    void write(String message);
}
