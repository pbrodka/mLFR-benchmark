package com.pl.wroc.pwr.ii.zsi.jlfr.distributions;

import java.util.List;

import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.Distribution;

public class PowerLaw implements Distribution {

    private List<Double> cumulative;

    public PowerLaw(List<Double> cumulative) {
        this.cumulative = cumulative;
    }

    @Override
    public double cumulativeProbability(double index) throws MathException {
        if (index == 0)
            return 0;
        double intIndex = Math.round(index - 1);
        return cumulative.get((int) intIndex);
    }

    @Override
    public double cumulativeProbability(double arg0, double arg1) throws MathException {
        throw new UnsupportedOperationException(
                "Not implented. Use cumulativeProbability(double) instead.");
    }
}
