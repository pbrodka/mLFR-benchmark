package com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces;

import java.util.List;
import java.util.Map;

public interface IWeightedNetwork extends INetwork {
    List<Map<Integer, Double>> getWeights();
}
