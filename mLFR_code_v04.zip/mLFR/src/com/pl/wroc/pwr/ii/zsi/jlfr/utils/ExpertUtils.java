package com.pl.wroc.pwr.ii.zsi.jlfr.utils;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class ExpertUtils {

    private static final Messages messages = Messages.getInstance();

    private static final Writer writer = Writer.getInstance();

    public static void exportMode(LFRNetworkParameters parameters, List<? extends INetwork> layers) {
        writer.println(messages.getMessage("ExpertUtils.SumOfNeighbours"), false, true);
        Map<Integer, Integer> numberOfLayersNumberOfNeighbours = new TreeMap<Integer, Integer>();
        for (int i = 0; i < parameters.getNumberOfLayers(); i++) {
            numberOfLayersNumberOfNeighbours.put(i + 1, 0);
        }

        for (int node = 0; node < layers.get(0).getAdjacencyMatrix().size(); node++) {
            LinkedHashSet<Integer> listOfNeighbours = new LinkedHashSet<Integer>();
            for (int layer = 0; layer < layers.size(); layer++) {
                listOfNeighbours.addAll(layers.get(layer).getAdjacencyMatrix().get(node));
            }
            for (int neighbour : listOfNeighbours) {
                int count = Methods.neighboursCount(layers, node, neighbour);
                numberOfLayersNumberOfNeighbours.put(count,
                        numberOfLayersNumberOfNeighbours.get(count) + 1);
            }
        }
        writer.println(numberOfLayersNumberOfNeighbours.toString(), false, false);
    }
}
