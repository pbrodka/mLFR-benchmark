package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;

public interface Benchmark<N extends INetwork> {

    public MultiLayeredNetwork<N> generate() throws BenchmarkException;

    public boolean validateParameters() throws BenchmarkException;
}
