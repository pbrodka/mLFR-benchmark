package com.pl.wroc.pwr.ii.zsi.jlfr.model;

import java.util.AbstractMap;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.google.common.base.Supplier;
import com.google.common.collect.Iterators;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import com.google.common.collect.Multiset;
import com.google.common.collect.Ordering;

public class MultiMap<K extends Comparable<K>, V extends Object> implements
		Multimap<K, V> {

	private final ListMultimap<K, V> map;

	public MultiMap() {
		Map<K, Collection<V>> keyMap = Maps.newTreeMap();
		this.map = Multimaps.newListMultimap(keyMap, new Supplier<List<V>>() {
			public List<V> get() {
				return Lists.newArrayList();
			}
		});
	}

	@SuppressWarnings("rawtypes")
	public MultiMap(Ordering<Comparable> ordering) {
		Map<K, Collection<V>> keyMap = Maps.newTreeMap(ordering);
		this.map = Multimaps.newListMultimap(keyMap, new Supplier<List<V>>() {
			public List<V> get() {
				return Lists.newArrayList();
			}
		});
	}

	public Iterator<Entry<K, V>> descendingValuesIterator() {
		return descendingValuesIterator(0);
	}

	public Iterator<Entry<K, V>> descendingValuesIterator(int position) {
		Iterator<Entry<K, V>> iterator = Iterators.emptyIterator();
		for (K key : keySet()) {

			List<Entry<K, V>> list = Lists.newArrayList();

			List<V> mapList = (List<V>) map.get(key);
			ListIterator<V> listIterator = mapList.listIterator(mapList.size());
			while (listIterator.hasPrevious()) {
				list.add(new AbstractMap.SimpleEntry<K, V>(key,
						(V) listIterator.previous()));
			}
			iterator = Iterators.concat(iterator, list.iterator());
		}
		for (int i = 0; i < position; i++) {
			if (iterator.hasNext()) {
				iterator.next();
			}
		}
		return iterator;
	}

	@Override
	public Map<K, Collection<V>> asMap() {
		return map.asMap();
	}

	@Override
	public void clear() {
		map.clear();
	}

	@Override
	public boolean containsEntry(Object arg0, Object arg1) {
		return map.containsEntry(arg0, arg1);
	}

	@Override
	public boolean containsKey(Object arg0) {
		return map.containsKey(arg0);
	}

	@Override
	public boolean containsValue(Object arg0) {
		return map.containsValue(arg0);
	}

	@Override
	public Collection<Entry<K, V>> entries() {
		return map.entries();
	}

	@Override
	public Collection<V> get(K arg0) {
		return map.get(arg0);
	}

	@Override
	public boolean isEmpty() {
		return map.isEmpty();
	}

	@Override
	public Set<K> keySet() {
		return map.keySet();
	}

	@Override
	public Multiset<K> keys() {
		return map.keys();
	}

	@Override
	public boolean put(K key, V value) {
		return this.map.put(key, value);
	}

	@Override
	public boolean putAll(Multimap<? extends K, ? extends V> map) {
		return this.map.putAll(map);
	}

	@Override
	public boolean putAll(K arg0, Iterable<? extends V> arg1) {
		return map.putAll(arg0, arg1);
	}

	@Override
	public boolean remove(Object key, Object value) {
		return map.remove(key, value);
	}

	@Override
	public Collection<V> removeAll(Object arg0) {
		return map.removeAll(arg0);
	}

	@Override
	public Collection<V> replaceValues(K arg0, Iterable<? extends V> arg1) {
		return map.replaceValues(arg0, arg1);
	}

	@Override
	public int size() {
		return map.size();
	}

	@Override
	public Collection<V> values() {
		return map.values();
	}

	@Override
	public String toString() {
		return map.toString();
	}
}
