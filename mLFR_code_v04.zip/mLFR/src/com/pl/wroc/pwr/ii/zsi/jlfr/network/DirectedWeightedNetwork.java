package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.IWeightedNetwork;

public class DirectedWeightedNetwork extends DirectedNetwork implements IWeightedNetwork {

    private final List<Map<Integer, Double>> weightsIn;
    private final List<Map<Integer, Double>> weightsOut;

    public DirectedWeightedNetwork(int numberOfNodes) {
        super(numberOfNodes);

        weightsIn = new ArrayList<Map<Integer, Double>>();
        weightsOut = new ArrayList<Map<Integer, Double>>();
    }

    @Override
    public void onInit() {
        for (int i = 0; i < numberOfNodes; i++) {
            adjacencyMatrix.add(new TreeSet<Integer>());
            inAdjacencyMatrix.add(new TreeSet<Integer>());
            weightsIn.add(new TreeMap<Integer, Double>());
            weightsOut.add(new TreeMap<Integer, Double>());
            memberList.add(new ArrayList<Integer>());
        }
    }

    @Override
    public List<Map<Integer, Double>> getWeights() {
        return weightsOut;
    }

    public List<Map<Integer, Double>> getWeightsIn() {
        return weightsIn;
    }

    public List<Map<Integer, Double>> getWeightsOut() {
        return weightsOut;
    }
}
