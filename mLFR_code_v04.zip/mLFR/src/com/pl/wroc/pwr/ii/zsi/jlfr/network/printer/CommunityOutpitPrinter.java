package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;

public class CommunityOutpitPrinter extends OutputWithCustomizableSeperator {

    @Override
    public void printNetwork(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            LFRNetworkParameters parameters, String destination) {
        printCommunity(multiNetwork, parameters, destination);
    }

    private void printCommunity(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            LFRNetworkParameters parameters, String destination) {
        try {
            File file;
            PrintWriter communityWriter;
            if (parameters.getRelocatingChance() == 0) {
                file = new File(destination + "_Community.txt");
                communityWriter = new PrintWriter(file);
                printLayer(multiNetwork, 0, communityWriter);
                communityWriter.flush();
                communityWriter.close();
            } else {
                for (int layerIndex = 0; layerIndex < multiNetwork.getLayers().size(); layerIndex++) {
                    file = new File(destination + "_Layer" + (layerIndex + 1) + "_Community.txt");
                    communityWriter = new PrintWriter(file);
                    printLayer(multiNetwork, layerIndex, communityWriter);
                    communityWriter.flush();
                    communityWriter.close();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void printLayer(MultiLayeredNetwork<? extends INetwork> multiNetwork, int layerIndex,
            PrintWriter communityWriter) {
        INetwork layer = multiNetwork.getLayers().get(layerIndex);

        for (int groupIndex = 0; groupIndex < layer.getMemberList().size(); groupIndex++) {
            communityWriter.print((groupIndex + 1));

            for (int j = 0; j < layer.getMemberList().get(groupIndex).size(); j++) {
                communityWriter.print(seperator
                        + (layer.getMemberList().get(groupIndex).get(j) + 1));
            }
            communityWriter.println();

        }
    }

}
