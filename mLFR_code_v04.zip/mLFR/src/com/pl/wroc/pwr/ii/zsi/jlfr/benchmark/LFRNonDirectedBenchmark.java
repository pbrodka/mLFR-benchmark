package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.math.MathException;

import com.google.common.collect.Ordering;
import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.MultiMap;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.Pair;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.Network;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public abstract class LFRNonDirectedBenchmark<T extends Network> extends LFRBenchmark<T> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();
    private final LFRNetworkParameters parameters;

    protected LFRNonDirectedBenchmark(LFRNetworkParameters parameters) {
        super(parameters);
        this.parameters = parameters;
    }

    protected void internalDegreeAndMembership(List<List<Integer>> memberMatrix,
            List<Integer> degreeSequence, List<Integer> numSeq, List<Integer> internalDegreeSeq)
            throws BenchmarkException {

        /*
         * Funkcja mo�e by� wywo�ana ponownie, dlatego clear. Dzieje si� tak,
         * gdy nie uda si� znale�� w�z�owi grupy, w kt�rej by si� mie�ci�.
         */
        memberMatrix.clear();
        internalDegreeSeq.clear();

        List<Double> cumulative = Methods.powerlaw(parameters.getMaximalCommunity(),
                parameters.getMinimalCommunity(), parameters.getTau2());

        int actualMaxDegree = 0;

        actualMaxDegree = setInternalDegreeSequence(degreeSequence, internalDegreeSeq,
                parameters.getTopologyMixingParameter());

        if (numSeq.isEmpty()) {
            int sumOfCommunitiesSizes = 0;

            /*
             * Gdy nie ustawimy fixed wielko�ci grup, jedna b�dzie mia�a
             * wielko�� o 1 wi�ksz� od max degree
             */
            if (!parameters.isFixedRange()
                    && (actualMaxDegree + 1) > parameters.getMinimalCommunity()) {

                sumOfCommunitiesSizes = actualMaxDegree + 1;
                // this helps the assignment of the
                // memberships (it assures that at
                // least one module is big enough to
                // host each node)
                numSeq.add(sumOfCommunitiesSizes);
            }

            /*
             * nn przechowuje wybrana z power law dystrybucji wielkosc
             * spo�eczno�ci nn + _num_ aktualnie wylosowany + suma wszystkich
             * druga strona to suma wszystkich degree (bior�c pod uwag�
             * overlapping)
             */

            int maximalSumOfCommunities = parameters.getNumberOfNodes()
                    + parameters.getOverlappingNodes()
                    * (parameters.getOverlappingMembership() - 1);

            int communitySizeProposition = Methods.lowerBound(cumulative, Math.random())
                    + parameters.getMinimalCommunity();

            while (communitySizeProposition + sumOfCommunitiesSizes <= maximalSumOfCommunities) {
                numSeq.add(communitySizeProposition);
                sumOfCommunitiesSizes += communitySizeProposition;

                communitySizeProposition = Methods.lowerBound(cumulative, Math.random())
                        + parameters.getMinimalCommunity();
            }

            /*
             * minimalnemu elementowi zostaje ustawione dope�nienie do sumy
             * degree
             */
            int indexOfMinimalCommunity = numSeq.indexOf(Collections.min(numSeq));
            numSeq.set(
                    indexOfMinimalCommunity,
                    numSeq.get(indexOfMinimalCommunity) + parameters.getNumberOfNodes()
                            + parameters.getOverlappingNodes()
                            * (parameters.getOverlappingMembership() - 1) - sumOfCommunitiesSizes);
        }

        /*
         * memberNumbers - liczba cz�onkowst ka�dego w�z�a
         */
        List<Integer> memberNumbers = new ArrayList<Integer>(degreeSequence.size());
        for (int i = 0; i < parameters.getOverlappingNodes(); i++) {
            memberNumbers.add(parameters.getOverlappingMembership());
        }
        for (int i = parameters.getOverlappingNodes(); i < degreeSequence.size(); i++) {
            memberNumbers.add(1);
        }

        buildBipartiteNetwork(memberMatrix, memberNumbers, numSeq);

        /*
         * available ka�demu w�z�owi (odpowiednia pozycja indeksu) przypisuje
         * wielko�� jego grupy - 1. Tak by potem nie przypisa� mu internal
         * degree wi�kszego ni� jego grupa.
         */
        List<Integer> available = new ArrayList<Integer>(parameters.getNumberOfNodes());
        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            available.add(0);
        }

        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                available.set(memberMatrix.get(i).get(j), available.get(memberMatrix.get(i).get(j))
                        + memberMatrix.get(i).size() - 1);
            }
        }

        /*
         * Prosta lista w�z��w kt�re nie maj� przypisanego internal degree
         */
        List<Integer> availableNodes = new ArrayList<Integer>(parameters.getNumberOfNodes());
        for (int i = 0; i < parameters.getNumberOfNodes(); i++)
            availableNodes.add(i);

        List<Integer> mapNodes = new ArrayList<Integer>(parameters.getNumberOfNodes());
        // in the position i there is the new name of the node i

        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            mapNodes.add(0);
        }

        /*
         * Przypisanie internal degree
         */

        for (int i = degreeSequence.size() - 1; i >= 0; i--) {
            int tryThis = (int) (Math.random() * availableNodes.size());

            int kr = 0;

            while ((int) (internalDegreeSeq.get(i) * LFRNetworkParameters.SPACING) > available
                    .get(availableNodes.get(tryThis))) {
                kr++;

                tryThis = (int) (Math.random() * availableNodes.size());

                if (kr == 3 * parameters.getNumberOfNodes()) {
                    Methods.changeCommunitySize(numSeq);// , ((int)
                                                        // (internalDegreeSeq.get(i)
                                                        // *
                                                        // LFRParameters.SPACING)));
                    writer.println(messages.getMessage("Benchmark.TooSmallCommunities"), true, true);

                    internalDegreeAndMembership(memberMatrix, degreeSequence, numSeq,
                            internalDegreeSeq);
                    return;
                }

            }

            mapNodes.set(availableNodes.get(tryThis), i);
            availableNodes.set(tryThis, availableNodes.get(availableNodes.size() - 1));
            availableNodes.remove(availableNodes.size() - 1);
        }

        /*
         * Poprawa po�o�enia w�z��w wzgl�dem mapNodes
         */
        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                memberMatrix.get(i).set(j, mapNodes.get(memberMatrix.get(i).get(j)));
            }
        }

        for (int i = 0; i < memberMatrix.size(); i++) {
            Collections.sort(memberMatrix.get(i));
        }
    }

    protected void buildSubgraphs(T network, List<List<Integer>> memberMatrix,
            List<List<Integer>> memberList, List<List<Integer>> linkList,
            List<Integer> internalDegreeSeq, List<Integer> degreeSeq) throws BenchmarkException {

        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                memberList.get(memberMatrix.get(i).get(j)).add(i);
            }
        }

        for (int i = 0; i < memberList.size(); i++) {

            List<Integer> liin = new ArrayList<Integer>();
            for (int j = 0; j < memberList.get(i).size(); j++) {
                Methods.computeInternalDegreePerNode(internalDegreeSeq.get(i), memberList.get(i)
                        .size(), liin);
                liin.add(degreeSeq.get(i) - internalDegreeSeq.get(i));

            }

            linkList.add(liin);

        }

        // now there is the check for the even node (it means that the internal
        // degree of each group has to be even and we want to assure that,
        // otherwise the degree_seq has to change) ----------------------------

        // ------------------------ this is done to check if the sum of the
        // internal degree is an even number. if not, the program will change it
        // in such a way to assure that.

        for (int i = 0; i < memberMatrix.size(); i++) {
            int internalCluster = 0;

            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                int rightIndex = Methods.lowerBound(memberList.get(memberMatrix.get(i).get(j)), i);

                internalCluster += linkList.get(memberMatrix.get(i).get(j)).get(rightIndex);
            }

            if (internalCluster % 2 != 0) {

                boolean defaultFlag = false;

                if (Math.random() > 0.5) {
                    defaultFlag = true;
                }

                if (defaultFlag) {

                    // if this does not work in a reasonable time the degree
                    // sequence will be changed

                    for (int j = 0; j < memberMatrix.get(i).size(); j++) {

                        int randomMate = memberMatrix.get(i).get(
                                (int) (Math.random() * memberMatrix.get(i).size()));

                        int rightIndex = Methods.lowerBound(memberList.get(randomMate), i);

                        if ((linkList.get(randomMate).get(rightIndex) < memberMatrix.get(i).size() - 1)
                                && (linkList.get(randomMate).get(
                                        linkList.get(randomMate).size() - 1) > 0)) {
                            linkList.get(randomMate).set(rightIndex,
                                    linkList.get(randomMate).get(rightIndex) + 1);
                            linkList.get(randomMate).set(
                                    linkList.get(randomMate).size() - 1,
                                    linkList.get(randomMate).get(
                                            linkList.get(randomMate).size() - 1) - 1);

                            break;
                        }
                    }
                }

                else {
                    for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                        int randomMate = memberMatrix.get(i).get(
                                (int) (Math.random() * memberMatrix.get(i).size()));

                        int rightIndex = Methods.lowerBound(memberList.get(randomMate), i);

                        if (linkList.get(randomMate).get(rightIndex) > 0) {
                            linkList.get(randomMate).set(rightIndex,
                                    linkList.get(randomMate).get(rightIndex) - 1);
                            linkList.get(randomMate).set(
                                    linkList.get(randomMate).size() - 1,
                                    linkList.get(randomMate).get(
                                            linkList.get(randomMate).size() - 1) + 1);

                            break;
                        }
                    }
                }
            }
        }

        // ------------------------ this is done to check if the sum of the
        // internal degree is an even number. if not, the program will change it
        // in such a way to assure that.

        for (int i = 0; i < memberMatrix.size(); i++) {

            List<Integer> internalDegreeI = new ArrayList<Integer>();
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                int rightIndex = Methods.lowerBound(memberList.get(memberMatrix.get(i).get(j)), i);//

                internalDegreeI.add(linkList.get(memberMatrix.get(i).get(j)).get(rightIndex));
            }

            buildSubgraph(network.getAdjacencyMatrix(), memberMatrix.get(i), internalDegreeI);

        }
    }

    protected void buildSubgraph(List<Set<Integer>> adjacencyMatrix, List<Integer> nodes,
            List<Integer> degrees) throws BenchmarkException {

        if (degrees.size() < 3) {
            throw new BenchmarkException(messages.getErrorMessage("Exception.ToSmallCommunities"));
        }

        // this function is to build a network with the labels stored in nodes
        // and the degree seq in degrees (correspondence is based on the
        // vectorial index)
        // the only complication is that you don't want the nodes to have
        // neighbors they already have

        // labels will be placed in the end
        List<TreeSet<Integer>> en = new ArrayList<TreeSet<Integer>>(nodes.size()); // this
                                                                                   // is
        for (int i = 0; i < nodes.size(); i++) {
            en.add(new TreeSet<Integer>());
        }

        MultiMap<Integer, Integer> degreeNode = new MultiMap<Integer, Integer>(Ordering.natural()
                .reverse());

        for (int i = 0; i < degrees.size(); i++) {
            degreeNode.put(degrees.get(i), i);
        }

        int var = 0;

        while (degreeNode.size() > 0) {

            Iterator<Entry<Integer, Integer>> iteratorFromLast = degreeNode
                    .descendingValuesIterator();
            Entry<Integer, Integer> lastPair = iteratorFromLast.next();

            Iterator<Entry<Integer, Integer>> iteratorForIterator = degreeNode
                    .descendingValuesIterator(1);

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            int numberOfInserted = 0;

            for (int i = 0; i < lastPair.getKey(); i++) {

                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    en.get(lastPair.getValue()).add(iteratedPair.getValue());
                    en.get(iteratedPair.getValue()).add(lastPair.getValue());

                    numberOfInserted++;

                    toErase.add(iteratedPair);
                }

                else {
                    break;
                }
            }

            for (int i = 0; i < toErase.size(); i++) {

                if (toErase.get(i).getKey() > 1)
                    degreeNode.put(toErase.get(i).getKey() - 1, toErase.get(i).getValue());

                degreeNode.remove(toErase.get(i).getKey(), toErase.get(i).getValue());
            }

            var += lastPair.getKey() - numberOfInserted;
            degreeNode.remove(lastPair.getKey(), lastPair.getValue());
        }

        // this is to randomize the subgraph
        // -------------------------------------------------------------------

        for (int nodeA = 0; nodeA < degrees.size(); nodeA++)
            for (int krm = 0; krm < en.get(nodeA).size(); krm++) {
                int randomMate = (int) (Math.random() * degrees.size());
                while (randomMate == nodeA)
                    randomMate = (int) (Math.random() * degrees.size());

                if (en.get(nodeA).add(randomMate)) {

                    List<Integer> outNodes = new ArrayList<Integer>();
                    for (int itEst : en.get(nodeA)) {
                        if (itEst != randomMate) {
                            outNodes.add(itEst);
                        }
                    }

                    int oldNode = outNodes.get((int) (Math.random() * outNodes.size()));

                    en.get(nodeA).remove(oldNode);
                    en.get(randomMate).add(nodeA);
                    en.get(oldNode).remove(nodeA);

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : en.get(randomMate)) {
                        if ((oldNode != itEst) && (!en.get(oldNode).contains(itEst))) {
                            notCommon.add(itEst);
                        }
                    }

                    int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                    en.get(randomMate).remove(nodeH);
                    en.get(nodeH).remove(randomMate);
                    en.get(nodeH).add(oldNode);
                    en.get(oldNode).add(nodeH);
                }
            }

        // now I try to insert the new links into the already done network. If
        // some multiple links come out, I try to rewire them
        List<Pair> multipleEdge = new ArrayList<Pair>();
        for (int i = 0; i < en.size(); i++) {
            for (int its : en.get(i))
                if (i < its) {

                    boolean already = !(adjacencyMatrix.get(nodes.get(i)).add(nodes.get(its)));
                    if (already)
                        multipleEdge.add(new Pair(nodes.get(i), nodes.get(its)));
                    else
                        adjacencyMatrix.get(nodes.get(its)).add(nodes.get(i));
                }
        }

        for (int i = 0; i < multipleEdge.size(); i++) {

            int a = multipleEdge.get(i).getFirst();
            int b = multipleEdge.get(i).getSecond();

            // now, I'll try to rewire this multiple link among the nodes stored
            // in nodes.
            int stopperMl = 0;

            while (true) {

                stopperMl++;

                int randomMate = nodes.get((int) (Math.random() * degrees.size()));
                while (randomMate == a || randomMate == b) {
                    randomMate = nodes.get((int) (Math.random() * degrees.size()));
                }
                if (!adjacencyMatrix.get(a).contains(randomMate)) {
                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : adjacencyMatrix.get(randomMate)) {
                        if (b != itEst && !adjacencyMatrix.get(b).contains(itEst)
                                && nodes.contains(itEst)) {
                            notCommon.add(itEst);
                        }
                    }
                    if (notCommon.size() > 0) {

                        int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                        adjacencyMatrix.get(randomMate).add(a);
                        adjacencyMatrix.get(randomMate).remove(nodeH);

                        adjacencyMatrix.get(nodeH).remove(randomMate);
                        adjacencyMatrix.get(nodeH).add(b);

                        adjacencyMatrix.get(b).add(nodeH);
                        adjacencyMatrix.get(a).add(randomMate);

                        break;

                    }
                }

                if (stopperMl == 2 * adjacencyMatrix.size()) {
                    writer.println(messages.getErrorMessage("Exception.OneLessLink"), true, true);
                    break;
                }
            }
        }
    }

    protected void initializeLayers(Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML) {
        List<List<Integer>> baseMemberList = memberListML.get(0);
        List<List<Integer>> baseLinkList = linkListML.get(0);
        List<List<Integer>> baseMemberMatrix = memberMatrixML.get(0);

        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            List<List<Integer>> memberListLayer = memberListML.get(layer);
            List<List<Integer>> linkListLayer = linkListML.get(layer);
            for (int i = 0; i < baseMemberList.size(); i++) {
                memberListLayer.set(i, new ArrayList<Integer>(baseMemberList.get(i)));
                linkListLayer.add(new ArrayList<Integer>(baseLinkList.get(i)));
            }

            List<List<Integer>> memberMatrixLayer = memberMatrixML.get(layer);
            for (int i = 0; i < baseMemberMatrix.size(); i++)
                memberMatrixLayer.add(new ArrayList<Integer>(baseMemberMatrix.get(i)));
        }
    }

    protected void buildLayers(List<T> layers, Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML) throws BenchmarkException {

        for (int group = 0; group < memberMatrixML.get(0).size(); group++) {

            /*
             * groupMembershipOnLayers zawiera cz�onkowstwo danej grupy na
             * wszystkich warstwach
             */
            Map<Integer, List<Integer>> groupMembershipOnLayers = new HashMap<Integer, List<Integer>>();

            for (int layerIndex = 0; layerIndex < layers.size(); layerIndex++) {
                groupMembershipOnLayers.put(layerIndex, memberMatrixML.get(layerIndex).get(group));
            }

            buildSubgraphLayer(layers, groupMembershipOnLayers, memberListML, linkListML, group);
        }
    }

    protected void buildSubgraphLayer(List<T> layers,
            Map<Integer, List<Integer>> groupMembershipOnLayers,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML, int group) throws BenchmarkException {

        Map<Integer, MultiMap<Integer, Integer>> mapDegreeNode = new HashMap<Integer, MultiMap<Integer, Integer>>();

        /*
         * Tworzy dla ka�dej warstwy kolekcj� jaka zosta�a do rozdania.
         * 
         * The collection is populated by pairs of key delineating a number of
         * edges left to distribute for a vertex x (initially internal degree
         * k_x^((in)) of vertex x for considered group) and identifier of a
         * vertex x.
         */
        for (int layerIndex = 1; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            mapDegreeNode.put(layerIndex, new MultiMap<Integer, Integer>(Ordering.natural()
                    .reverse()));

            /*
             * Ka�demu w�z�owi z danej grupy, pobiera rightIndex (w�a�ciwy
             * indeks do pobrania z linkList opisuj�cy internalDegree w
             * rozwa�anej grupie, nast�pnie uzupe�nia multimap� numere node'a i
             * jego internal degree
             */
            for (int node : groupMembershipOnLayers.get(layerIndex)) {

                int rightIndex = Methods.lowerBound(memberListML.get(layerIndex).get(node), group);

                int internalDegree = linkListML.get(layerIndex).get(node).get(rightIndex);

                mapDegreeNode.get(layerIndex).put(internalDegree, node);
            }
        }

        List<Integer> layersToDo = new ArrayList<Integer>(parameters.getNumberOfLayers());

        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            layersToDo.add(layer);
        }

        /*
         * G��wna p�tla, wykonywana dop�ki cho� jedna warstwa nie ma pustej
         * multimapy
         */
        while (layersToDo.size() != 0) {
            int layerIndex = (int) (Math.random() * layersToDo.size());

            int layer = layersToDo.get(layerIndex);

            List<Set<Integer>> baseLayerAdjacencyMatrix = layers.get(0).getAdjacencyMatrix();
            List<Set<Integer>> adjacencyMatrix = layers.get(layer).getAdjacencyMatrix();

            // FIRST ROUND
            /*
             * Wybierz ostatni� par� internal degree i indeks w�z�a z kolekcji,
             * dla danej warstwy. Teraz ten w�ze� b�dzie rozwa�any.
             */
            Iterator<Entry<Integer, Integer>> iteratorFromLast = mapDegreeNode.get(layer)
                    .descendingValuesIterator();

            Entry<Integer, Integer> lastPair = iteratorFromLast.next();

            int insertedInFirstRound = 0;

            /*
             * Sprawdza czy dany w�ze� nale�y do tej samej grupy na obu
             * warstwach (bazowej i rozwa�anej). Je�eli nie, nie ma co si�
             * posi�kowa� podobie�stwem na obu warswach.
             */
            if (memberListML.get(0).get(lastPair.getValue()).contains(group)) {
                // The list of all possible neighbour propositions
                List<Integer> nodeNeighbours = new LinkedList<Integer>();
                List<Integer> insertedNodeNeighbours = new LinkedList<Integer>();

                for (int nodeNeighbour : baseLayerAdjacencyMatrix.get(lastPair.getValue())) {
                    /*
                     * Je�eli:
                     * 
                     * Vertex x does not already have vertex y as a adjacent
                     * vertex,
                     * 
                     * Rozwa�ane w�z�y nie s� tym samym w�z�em,
                     * 
                     * Vertex y can have another neighbour,i.e aktualne internal
                     * degree nie osi�gn�o maksymalnego
                     * 
                     * Vertex x is in the same group as vertex y
                     * 
                     * x != y (possible when vertices have more than one
                     * membership in common)
                     */
                    if (!adjacencyMatrix.get(lastPair.getValue()).contains(nodeNeighbour)
                            && nodeNeighbour != lastPair.getValue()
                            && memberListML.get(layer).get(nodeNeighbour).contains(group)
                            && linkListML
                                    .get(layer)
                                    .get(nodeNeighbour)
                                    .get(Methods.lowerBound(
                                            memberListML.get(layer).get(nodeNeighbour), group)) != adjacencyMatrix
                                    .get(nodeNeighbour).size())

                        nodeNeighbours.add(nodeNeighbour);
                }

                int rightIndex = Methods.lowerBound(memberListML.get(layer)
                        .get(lastPair.getValue()), group);

                /*
                 * Maksymalna ilo�� s�siad�w jak� mo�e doda� to wynikowa
                 * maksymalnej liczby - liczby ju� dodanych wcze�niej
                 */
                int maxNeighbours = linkListML.get(layer).get(lastPair.getValue()).get(rightIndex)
                        - adjacencyMatrix.get(lastPair.getValue()).size();

                /*
                 * Dop�ki s� propozycje i nie doda� ju� do maksa
                 */
                while (nodeNeighbours.size() > 0 && insertedInFirstRound < maxNeighbours) {

                    int neighbourPropositionIndex = (int) (Math.random() * nodeNeighbours.size());

                    int neighbourProposition = nodeNeighbours.get(neighbourPropositionIndex);

                    /*
                     * Zlicza na ilu warstwach s� ju� s�siadami
                     */
                    int count = Methods.neighboursCount(layers, lastPair.getValue(),
                            neighbourProposition);

                    /*
                     * Algorithm before inserting an edge joining vertex x and
                     * vertex y on a layer l, checks how many connections exist
                     * between vertices x and y on all layers. Then for given
                     * number of connections asks for a value of cumulative
                     * distribution function tuned to return 0 for no edges
                     * existing and 1 for connection on all layers. The new
                     * connection is accepted only if the randomly chosen value
                     * from 0 to 1, inclusively, obtained from
                     * java.lang.Math.random() function is equal or greater than
                     * the value from cumulative distribution function.
                     */
                    try {
                        if (Math.random() >= parameters.getDistribution().cumulativeProbability(
                                count)) {

                            if (adjacencyMatrix.get(lastPair.getValue()).add(neighbourProposition)) {

                                adjacencyMatrix.get(neighbourProposition).add(lastPair.getValue());

                                insertedNodeNeighbours.add(neighbourProposition);

                                insertedInFirstRound++;
                            }
                        }
                    } catch (MathException me) {
                        throw new BenchmarkException("Distribution library internal error.");
                    }

                    nodeNeighbours.remove(neighbourPropositionIndex);
                }
                // W�a�nie zaproponowali�my wszystkich s�siad�w z listy
                // wzorcowej

                /*
                 * Poprawia multimap�, by uwzgl�dnia�a zmiany kt�re zasz�y.
                 */
                for (int i = 0; i < insertedNodeNeighbours.size(); i++) {

                    int toRemove = insertedNodeNeighbours.get(i);
                    int rightLinkListIndex = Methods.lowerBound(
                            memberListML.get(layer).get(lastPair.getValue()), group);

                    int first = linkListML.get(layer).get(toRemove).get(rightLinkListIndex)
                            - (adjacencyMatrix.get(toRemove).size() - 1);

                    mapDegreeNode.get(layer).remove(first, toRemove);

                    if (first > 1)
                        mapDegreeNode.get(layer).put(first - 1, toRemove);
                }
            }

            // SECOND PART

            /*
             * Create iterator it pointing before the element containing
             * information about vertex x
             */
            Iterator<Entry<Integer, Integer>> iteratorForIterator = mapDegreeNode.get(layer)
                    .descendingValuesIterator(1);

            /*
             * Create list of elements to erase
             */
            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            Iterator<Entry<Integer, Integer>> fastCalculate = mapDegreeNode.get(layer)
                    .descendingValuesIterator();
            fastCalculate.next();

            int sum = 0;

            while (fastCalculate.hasNext()) {
                Entry<Integer, Integer> fastPair = fastCalculate.next();
                if (adjacencyMatrix.get(lastPair.getValue()).contains(fastPair.getValue()))
                    sum++;
            }
            /*
             * Calculate jumper, as a number of possible skips of elements by
             * the iterator it.
             */
            int jumpNumber = (mapDegreeNode.get(layer).size() - 1) - lastPair.getKey() - sum
                    + insertedInFirstRound;

            /*
             * For considered vertex internal degree minus inserted so far
             * neighbours
             */
            for (int i = 0; i < lastPair.getKey() - insertedInFirstRound; i++) {
                if (iteratorForIterator.hasNext()) {
                    /*
                     * Take the element before iterator it describing vertex y
                     */
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    try {
                        int count = Methods.neighboursCount(layers, lastPair.getValue(),
                                iteratedPair.getValue());
                        double random = Math.random();
                        double treshold = parameters.getDistribution().cumulativeProbability(count);

                        boolean contains = adjacencyMatrix.get(lastPair.getValue()).contains(
                                iteratedPair.getValue());

                        /*
                         * While vertex x and y are neighbours or (if connecting
                         * the vertices would skew the distribution and the jump
                         * is possible). Move iterator it and consider previous
                         * element on the list
                         */
                        while ((contains || (random < treshold && jumpNumber > 0))
                                && iteratorForIterator.hasNext()) {
                            boolean toContinue = contains;
                            iteratedPair = iteratorForIterator.next();
                            contains = adjacencyMatrix.get(lastPair.getValue()).contains(
                                    iteratedPair.getValue());

                            count = Methods.neighboursCount(layers, lastPair.getValue(),
                                    iteratedPair.getValue());
                            random = Math.random();
                            treshold = parameters.getDistribution().cumulativeProbability(count);

                            if (toContinue)
                                continue;
                            else
                                jumpNumber--;

                        }
                        if (adjacencyMatrix.get(lastPair.getValue()).contains(
                                iteratedPair.getValue())
                                || (random < treshold && jumpNumber > 0))
                            break;

                    } catch (MathException me) {

                    }

                    if (adjacencyMatrix.get(lastPair.getValue()).add(iteratedPair.getValue())) {
                        adjacencyMatrix.get(iteratedPair.getValue()).add(lastPair.getValue());
                        toErase.add(iteratedPair);
                    }
                } else {

                    break;
                }
            }

            /*
             * Naprawa multimapy
             */
            for (int i = 0; i < toErase.size(); i++) {
                if (toErase.get(i).getKey() > 1)
                    mapDegreeNode.get(layer).put(toErase.get(i).getKey() - 1,
                            toErase.get(i).getValue());

                mapDegreeNode.get(layer).remove(toErase.get(i).getKey(), toErase.get(i).getValue());
            }

            /*
             * Usu� rozwa�any w�ze� z multilisty (rozdali�my jego wszystkie
             * s�siedztwa, przejd� do nast�pnego
             */
            mapDegreeNode.get(layer).remove(lastPair.getKey(), lastPair.getValue());

            /*
             * Je�eli uda�o nam si� usunn�� wszystkie elementy z multimapy dla
             * danej warstwy, rozdali�my wszystkie po��czenia. Nale�y usun��
             * warstw� z listy warstw do zrobienia
             */
            if (mapDegreeNode.get(layer).size() == 0)
                layersToDo.remove(layerIndex);

        }
    }

    protected List<Integer> getDegreeSequence() {
        List<Integer> degreeSequence = new ArrayList<Integer>();

        List<Double> cumulative = Methods.powerlaw(parameters.getMaxDegree(),
                parameters.getMinDegree(), parameters.getTau());

        /*
         * Cumulative ma warto�ci od 0 do 1 (patrz Methods.powerlaw), funkcja
         * lowerBound w spos�b losowy przydziela jej warto�ci indeksu +
         * minDegree, co daje proponowan� dystrybucj� pot�gow�.
         */
        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            int nn = Methods.lowerBound(cumulative, Math.random()) + parameters.getMinDegree();
            degreeSequence.add(nn);
        }

        Collections.sort(degreeSequence);

        /*
         * Zapewnienie parzysto�ci sumy stopni w�z��w
         */
        int degreeSum = Methods.degreeSum(degreeSequence);

        if (degreeSum % 2 != 0) {
            int index = Methods.lowerBound(degreeSequence,
                    degreeSequence.get(degreeSequence.size() - 1));
            degreeSequence.set(index, degreeSequence.get(index) - 1);
        }
        return degreeSequence;
    }

}
