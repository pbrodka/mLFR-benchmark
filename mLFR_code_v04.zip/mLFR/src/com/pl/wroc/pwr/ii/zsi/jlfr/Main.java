package com.pl.wroc.pwr.ii.zsi.jlfr;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.pl.wroc.pwr.ii.zsi.jlfr.generator.Generator;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.GUI;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.CommunityOutpitPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.OutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.printer.StandardOutputPrinter;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.ParametersFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.ConsoleWriter;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class Main {
    private static Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    private final static RunMode runMode = RunMode.getInstance();

    public static void main(String[] args) {
        writer.addWriter(new ConsoleWriter());
        if (args.length == 0) {
            writer.println(messages.getMessage("Main.Start"), true, false);
            return;
        }

        List<String> arguments = new ArrayList<String>(Arrays.asList(args));

        if (arguments.contains(RunMode.EXPERT_MODE)) {
            runMode.setExpertMode(true);
            arguments = new ArrayList<String>(arguments);
            arguments.remove(RunMode.EXPERT_MODE);
        }

        if (arguments.contains(RunMode.GUI)) {
            arguments.remove(RunMode.GUI);
            GUI.main(args);
        } else {
            List<OutputPrinter> outputPrinters = new ArrayList<OutputPrinter>();
            outputPrinters.add(new StandardOutputPrinter());
            outputPrinters.add(new CommunityOutpitPrinter());

            NetworkType networkChosen = NetworkType.valueOf(arguments.get(0).toUpperCase());

            Map<KeyMapping, String> parametersMap = ParametersFactory
                    .getParametersAsAMapKeyValue(arguments);

            Date actualTime = new Date();

            Generator generator = new Generator(networkChosen, parametersMap,
                    String.valueOf(actualTime.getTime()), outputPrinters, " ");
            generator.perform();
        }
    }

}
