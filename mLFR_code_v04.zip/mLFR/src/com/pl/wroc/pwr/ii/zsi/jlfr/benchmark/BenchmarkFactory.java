package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkType;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRWeightedNetworkParameters;

public class BenchmarkFactory {
    public static Benchmark<? extends INetwork> createBenchmark(NetworkType type,
            LFRNetworkParameters parameters) {
        switch (type) {
        case UU:
            return new UUBenchmark(parameters);
        case D:
            return new DBenchmark(parameters);
        case W:
            return new WBenchmark((LFRWeightedNetworkParameters) parameters);
        case DW:
            return new DWBenchmark((LFRWeightedNetworkParameters) parameters);
        }
        throw new IllegalArgumentException("Unknown type.");
    }
}
