package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.Network;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class UUBenchmark extends LFRNonDirectedBenchmark<Network> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    private final LFRNetworkParameters parameters;

    public UUBenchmark(LFRNetworkParameters parameters) {
        super(parameters);
        this.parameters = parameters;
    }

    @Override
    public MultiLayeredNetwork<Network> generate() throws BenchmarkException {
        MultiLayeredNetwork<Network> network = NetworkFactory.createMultiLayeredNetwork(parameters);

        writer.println(messages.getMessage("Benchmark.StartGeneration"), true, true);

        List<Integer> degreeSequence = getDegreeSequence();

        /*
         * numSeq - zawiera liczebno�ci grup, np. dwa elementy, jeden o warto�ci
         * 4, drugi o warto�ci 6 symbolizuj�ce istnienie dw�ch grup, jedna o 4
         * w�z�ach, druga o 6
         */
        List<Integer> numSeq = new ArrayList<Integer>();

        /*
         * internalDegreeSeq - lista stopni wewn�trznych, i.e. stopie� w�z�a
         * licz�c po��czenia tylko w grupie indeksy odpowiadaj� indeksom z
         * degreeSequence, i.e. element pod indeksem 0 na obu listach, to ten
         * sam w�ze� lista przedstawia sum� internalDegree, i.e. w przypadku
         * overlapping jest to suma po wszystkich grupach, do kt�rej dany w�ze�
         * nale�y
         */
        List<Integer> internalDegreeSeq = new ArrayList<Integer>();

        /*
         * Disclaimer: ML to skr�t od Multi Layered, tak s� oznaczone mapy,
         * gdzie klucz to warstwa, a warto�� to jaka� kolekcja, b�d� opisywa�
         * g��wnie o co chodzi z warto�ciami
         * 
         * Warto�� to lista o liczebno�ci r�wnej liczbie grup, gdzie pod
         * poszczeg�lnymi indeksami znajduj� si� listy, zawieraj�ce indeksy
         * wszystkich w�z��w nale��cych do danej grupy.
         */
        Map<Integer, List<List<Integer>>> memberMatrixML = new HashMap<Integer, List<List<Integer>>>();
        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberMatrixML.put(layer, new ArrayList<List<Integer>>());
        }

        /*
         * Magia, patrz do �rodka
         */
        internalDegreeAndMembership(memberMatrixML.get(0), degreeSequence, numSeq,
                internalDegreeSeq);

        List<Network> layers = network.getLayers();

        /*
         * LinkListML dla ka�dej warstwy zawiera list� po��cze� danego w�z�a
         * (opisywanego przez indeks). Ostatni element listy dla konkretnego
         * w�z�a opisuje liczb� po��cze� external, pozosta�e internal, i.e. (5,
         * 5, 2) m�wi, �e w�ze� jest overlapping, w pierwszej grupie ma 5
         * s�siad�w, w drugiej 5 oraz 2 s�siad�w nienale��cych do �adnej z jego
         * grup (pomi�dzy spo�eczno�ciami). Powy�szy opis nie m�wi konkretnie o
         * jakich grupach mowa, te informacje mo�na wydoby� w po��czeniu z
         * opisem w memberListML.
         */
        Map<Integer, List<List<Integer>>> linkListML = new HashMap<Integer, List<List<Integer>>>();

        /*
         * memberListML dla ka�dej warsty zawiera informacj� o grupach do jakich
         * dany w�ze� nale�y.
         */
        Map<Integer, List<List<Integer>>> memberListML = new HashMap<Integer, List<List<Integer>>>();

        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberListML.put(layer, layers.get(layer).getMemberList());
            linkListML.put(layer, new ArrayList<List<Integer>>());
        }

        /*
         * Wywo�ywana tylko dla warstwy bazowej
         */
        buildSubgraphs(layers.get(0), memberMatrixML.get(0), memberListML.get(0),
                linkListML.get(0), internalDegreeSeq, degreeSequence);

        for (int i = 0; i < layers.get(0).getAdjacencyMatrix().size(); i++) {
            if (layers.get(0).getAdjacencyMatrix().get(i).size() != linkListML.get(0).get(i).get(0)) {
                linkListML.get(0).get(i).set(0, layers.get(0).getAdjacencyMatrix().get(i).size());
            }
        }

        /*
         * Inicjalizacja kolekcji opisuj�cych warstwy. Pocz�tkowo wszystkie
         * warstwy s� kopi� bazowej.
         */
        initializeLayers(memberMatrixML, memberListML, linkListML);

        /*
         * Funkcja zmieniaj�ca degree w�z��w w obr�bie grupy
         */
        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListML);
        }

        /*
         * Funkcja mieszaj�ca cz�onkowstwo w�z��w
         */
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListML);
        }

        /*
             * 
             */
        buildLayers(layers, memberMatrixML, memberListML, linkListML);

        writer.println(messages.getMessage("Benchmark.ConnectingCommunities"), true, true);
        connectAllTheParts(layers, memberListML, linkListML);

        return network;

    }
}
