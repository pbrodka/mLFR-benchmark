package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;

public enum NetworkType {
    UU, D, W, DW;

    private static final Messages messages = Messages.getInstance();

    @Override
    public String toString() {
        return messages.getMessage(this);
    }
}
