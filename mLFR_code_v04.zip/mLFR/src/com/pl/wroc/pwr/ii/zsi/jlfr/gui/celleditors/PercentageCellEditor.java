package com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors;

import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

public class PercentageCellEditor extends ParameterCellEditor {

    private JFormattedTextField field;
    private NumberFormat percentageFormat;

    public PercentageCellEditor(JTable table) {
        super(table, new JFormattedTextField());
        field = (JFormattedTextField) getComponent();

        percentageFormat = NumberFormat.getNumberInstance(ParameterCellEditor.LOCALE);
        NumberFormatter formatter = new NumberFormatter(percentageFormat);
        formatter.setMinimum(0d);
        formatter.setMaximum(1d);

        field.setFormatterFactory(new DefaultFormatterFactory(formatter));
    }

    public Object getCellEditorValue() {
        JFormattedTextField field = (JFormattedTextField) getComponent();
        Object o = field.getValue();
        if (o == null) {
            return null;
        }

        if (o instanceof Double) {
            return o;
        } else if (o instanceof Number) {
            return new Double(((Number) o).doubleValue());
        } else {

            try {
                return percentageFormat.parseObject(o.toString());
            } catch (ParseException exc) {
                return null;
            }
        }
    }
}
