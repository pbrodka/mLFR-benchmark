package com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer;

import javax.swing.JTextArea;

public class TextAreaWriter implements IWriter {

    private final JTextArea textArea;

    public TextAreaWriter(JTextArea textArea) {
        super();
        this.textArea = textArea;
    }

    @Override
    public void write(String message) {
        textArea.append(message + "\n");
    }

}
