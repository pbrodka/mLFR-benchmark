package com.pl.wroc.pwr.ii.zsi.jlfr.network.printer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;

public class GmlOutputPrinter implements OutputPrinter {

    @Override
    public void printNetwork(MultiLayeredNetwork<? extends INetwork> multiNetwork,
            LFRNetworkParameters parameters, String destination) {
        try {
            for (int i = 0; i < multiNetwork.getLayers().size(); i++) {
                File file = new File(destination + "_Layer" + (i + 1) + "_Network.gml");

                INetwork network = multiNetwork.getLayers().get(i);
                PrintWriter networkWriter = new PrintWriter(file);

                networkWriter.print("graph\n[\n");

                for (int nodeIndex = 0; nodeIndex < network.getAdjacencyMatrix().size(); nodeIndex++) {
                    networkWriter.print("  node\n  [\n    id " + (nodeIndex + 1) + "\n  ]\n");
                }
                for (int sourceNode = 0; sourceNode < network.getAdjacencyMatrix().size(); sourceNode++) {
                    for (int targetNode : network.getAdjacencyMatrix().get(sourceNode)) {
                        networkWriter.print("  edge\n  [\n    source " + (sourceNode + 1)
                                + "\n    target " + (targetNode + 1) + "\n    value 1\n  ]\n");
                    }
                }
                networkWriter.println("]");
                networkWriter.flush();
                networkWriter.close();

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
