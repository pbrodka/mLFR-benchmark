package com.pl.wroc.pwr.ii.zsi.jlfr.parameters;

import org.apache.commons.math.distribution.Distribution;

public class LFRNetworkParameters extends NetworkParameters {

    public static final Double SPACING = 1.1;

    private Integer numberOfNodes; // num_nodes;
    private Double averageDegree; // average_k
    private Integer minDegree; // min_degree (estimated based on given
                               // parameters
    private Integer maxDegree; // max_degree
    private Double tau; // minus exponent for the degree sequence
    private Double tau2; // minus exponent for the community size distribution
    private Integer overlappingNodes; // number of overlapping nodes
    private Integer overlappingMembership; // number of memberships of the
                                           // overlapping nodes
    private Integer minimalCommunity; // minimum for the community sizes
    private Integer maximalCommunity; // maximum for the community sizes
    private Boolean fixedRange; // true, if two above set by user

    private double topologyMixingParameter;

    private Distribution distribution;
    private Double distributionParameter1;
    private Double distributionParameter2;
    private Integer numberOfLayers;
    private Double degreeChangeChance;
    private Double relocatingChance;

    public Integer getNumberOfNodes() {
        return numberOfNodes;
    }

    public void setNumberOfNodes(Integer numberOfNodes) {
        this.numberOfNodes = numberOfNodes;
    }

    public Double getAverageDegree() {
        return averageDegree;
    }

    public void setAverageDegree(Double averageDegree) {
        this.averageDegree = averageDegree;
    }

    public Integer getMinDegree() {
        return minDegree;
    }

    public void setMinDegree(Integer minDegree) {
        this.minDegree = minDegree;
    }

    public Integer getMaxDegree() {
        return maxDegree;
    }

    public void setMaxDegree(Integer maxDegree) {
        this.maxDegree = maxDegree;
    }

    public Double getTau() {
        return tau;
    }

    public void setTau(Double tau) {
        this.tau = tau;
    }

    public Double getTau2() {
        return tau2;
    }

    public void setTau2(Double tau2) {
        this.tau2 = tau2;
    }

    public Integer getOverlappingNodes() {
        return overlappingNodes;
    }

    public void setOverlappingNodes(Integer overlappingNodes) {
        this.overlappingNodes = overlappingNodes;
    }

    public Integer getOverlappingMembership() {
        return overlappingMembership;
    }

    public void setOverlappingMembership(Integer overlappingMembership) {
        this.overlappingMembership = overlappingMembership;
    }

    public Integer getMinimalCommunity() {
        return minimalCommunity;
    }

    public void setMinimalCommunity(Integer minimalCommunity) {
        this.minimalCommunity = minimalCommunity;
    }

    public Integer getMaximalCommunity() {
        return maximalCommunity;
    }

    public void setMaximalCommunity(Integer maximalCommunity) {
        this.maximalCommunity = maximalCommunity;
    }

    public Boolean isFixedRange() {
        return fixedRange;
    }

    public void setFixedRange(Boolean fixedRange) {
        this.fixedRange = fixedRange;
    }

    public Distribution getDistribution() {
        return distribution;
    }

    public void setDistribution(Distribution distribution) {
        this.distribution = distribution;
    }

    public Double getDistributionParameter1() {
        return distributionParameter1;
    }

    public void setDistributionParameter1(Double distributionParameter1) {
        this.distributionParameter1 = distributionParameter1;
    }

    public Double getDistributionParameter2() {
        return distributionParameter2;
    }

    public void setDistributionParameter2(Double distributionParameter2) {
        this.distributionParameter2 = distributionParameter2;
    }

    public Integer getNumberOfLayers() {
        return numberOfLayers;
    }

    public void setNumberOfLayers(Integer numberOfLayers) {
        this.numberOfLayers = numberOfLayers;
    }

    public Double getDegreeChangeChance() {
        return degreeChangeChance;
    }

    public void setDegreeChangeChance(Double degreeChangeChance) {
        this.degreeChangeChance = degreeChangeChance;
    }

    public Double getRelocatingChance() {
        return relocatingChance;
    }

    public void setRelocatingChance(Double relocatingChance) {
        this.relocatingChance = relocatingChance;
    }

    public Boolean getFixedRange() {
        return fixedRange;
    }

    public void setTopologyMixingParameter(Double topologyMixingParameter) {
        this.topologyMixingParameter = topologyMixingParameter;
    }

    public double getTopologyMixingParameter() {
        return topologyMixingParameter;
    }
}
