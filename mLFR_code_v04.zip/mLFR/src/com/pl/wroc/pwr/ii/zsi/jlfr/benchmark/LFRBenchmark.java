package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.math.MathException;

import com.google.common.collect.Ordering;
import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.MultiMap;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.Pair;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.Network;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public abstract class LFRBenchmark<N extends INetwork> implements Benchmark<N> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    protected final LFRNetworkParameters parameters;

    protected LFRBenchmark(LFRNetworkParameters parameters) {
        this.parameters = parameters;
    }

    @Override
    public boolean validateParameters() throws BenchmarkException {
        writer.println(messages.getMessage("Benchmark.Validation.Start"), true, true);
        Methods.calculateMinimalDegree(parameters);
        writer.print(
                messages.getMessage("Benchmark.Validation.MinimalDegreeSet")
                        + parameters.getMinDegree(), true, true);

        // Range for the community sizes
        if (parameters.getMinimalCommunity() == 0 || parameters.getMaximalCommunity() == 0) {
            parameters.setFixedRange(false);
            parameters.setMinimalCommunity(parameters.getMinDegree());
            parameters
                    .setMaximalCommunity((int) (parameters.getMaxDegree() * LFRNetworkParameters.SPACING));
            writer.print(
                    messages.getMessage("Benchmark.Validation.CommunitySizeSet")
                            + +parameters.getMinimalCommunity() + ", "
                            + parameters.getMaximalCommunity() + "]", true, true);
        } else {
            parameters.setFixedRange(true);
        }

        if (parameters.getNumberOfNodes() < parameters.getOverlappingNodes()) {
            throw new BenchmarkException(
                    "\nERROR:\nThere are more overlapping nodes than nodes in the whole network! Please, decrease the former ones or increase the latter ones");
        }

        writer.println(messages.getMessage("Benchmark.Validation.Success"), true, true);
        return true;
    }

    public void buildBipartiteNetwork(List<List<Integer>> memberMatrix,
            List<Integer> memberNumbers, List<Integer> numSeq) throws BenchmarkException {
        // this function builds a bipartite network with num_seq and
        // member_numbers which are the degree sequences. in member matrix links
        // of the communities are stored
        // this means member_matrix has num_seq.size() rows and each row has
        // num_seq[i] elements

        List<TreeSet<Integer>> enIn = new ArrayList<TreeSet<Integer>>();
        // this is the Ein of the subgraph
        List<TreeSet<Integer>> enOut = new ArrayList<TreeSet<Integer>>();
        // this is the Eout of the subgraph

        for (int i = 0; i < memberNumbers.size(); i++) {
            enIn.add(new TreeSet<Integer>());
        }

        for (int i = 0; i < numSeq.size(); i++) {
            enOut.add(new TreeSet<Integer>());
        }

        MultiMap<Integer, Integer> degreeNodeOut = new MultiMap<Integer, Integer>(Ordering
                .natural().reverse());

        ArrayList<Pair> degreeNodeIn = new ArrayList<Pair>();

        for (int i = 0; i < numSeq.size(); i++) {
            degreeNodeOut.put(numSeq.get(i), i);
        }

        for (int i = 0; i < memberNumbers.size(); i++) {
            degreeNodeIn.add(new Pair(memberNumbers.get(i), i));
        }

        Collections.sort(degreeNodeIn);

        ListIterator<Pair> itlast = degreeNodeIn.listIterator(degreeNodeIn.size());

        while (itlast.hasPrevious()) {
            Pair itLastPair = itlast.previous();

            Iterator<Entry<Integer, Integer>> iteratorForIterator = degreeNodeOut
                    .descendingValuesIterator();

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            for (int i = 0; i < itLastPair.getFirst(); i++) {
                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    enIn.get(itLastPair.getSecond()).add(iteratedPair.getValue());
                    enOut.get(iteratedPair.getValue()).add(itLastPair.getSecond());

                    toErase.add(iteratedPair);
                }

                else {
                    throw new BenchmarkException(
                            "it seems that the overlapping nodes need more communities that those I provided. Please increase the number of communities or decrease the number of overlapping nodes");
                }

            }

            for (int i = 0; i < toErase.size(); i++) {

                if (toErase.get(i).getKey() > 1) {
                    degreeNodeOut.put(toErase.get(i).getKey() - 1, toErase.get(i).getValue());
                }

                degreeNodeOut.remove(toErase.get(i).getKey(), toErase.get(i).getValue());

            }

        }

        // this is to randomize the subgraph
        // -------------------------------------------------------------------
        for (int nodeA = 0; nodeA < numSeq.size(); nodeA++)
            for (int krm = 0; krm < enOut.get(nodeA).size(); krm++) {
                int randomMate = (int) (Math.random() * memberNumbers.size());

                if (!enOut.get(nodeA).contains(randomMate)) {

                    List<Integer> externalNodes = new ArrayList<Integer>();

                    for (int itEst : enOut.get(nodeA)) {
                        externalNodes.add(itEst);
                    }

                    int oldNode = externalNodes.get((int) (Math.random() * externalNodes.size()));

                    List<Integer> notCommon = new ArrayList<Integer>();

                    for (int itEst : enIn.get(randomMate)) {
                        if (!enIn.get(oldNode).contains(itEst))
                            notCommon.add(itEst);
                    }

                    if (notCommon.isEmpty()) {
                        break;
                    }

                    int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                    enOut.get(nodeA).add(randomMate);
                    enOut.get(nodeA).remove(oldNode);

                    enIn.get(oldNode).add(nodeH);
                    enIn.get(oldNode).remove(nodeA);

                    enIn.get(randomMate).add(nodeA);
                    enIn.get(randomMate).remove(nodeH);

                    enOut.get(nodeH).remove(randomMate);
                    enOut.get(nodeH).add(oldNode);

                }

            }

        for (int i = 0; i < enOut.size(); i++) {
            memberMatrix.add(new ArrayList<Integer>());
            for (int setValue : enOut.get(i)) {
                memberMatrix.get(i).add(setValue);
            }
        }

    }

    public int connectAllTheParts(List<N> layers, Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML) throws BenchmarkException {
        List<List<Integer>> linkList = linkListML.get(0);
        List<List<Integer>> memberList = memberListML.get(0);

        List<Integer> degrees = new ArrayList<Integer>(linkList.size());
        for (int i = 0; i < linkList.size(); i++) {
            degrees.add(linkList.get(i).get(linkList.get(i).size() - 1));
        }

        List<INetwork> layersInWork = new ArrayList<INetwork>();
        for (int i = 0; i < parameters.getNumberOfLayers(); i++) {
            Network network = new Network(parameters.getNumberOfNodes());
            network.onInit();
            layersInWork.add(network);
        }

        INetwork baseLayer = layersInWork.get(0);

        List<Set<Integer>> en = baseLayer.getAdjacencyMatrix();
        MultiMap<Integer, Integer> degreeNode = new MultiMap<Integer, Integer>(Ordering.natural()
                .reverse());

        for (int i = 0; i < degrees.size(); i++) {
            degreeNode.put(degrees.get(i), i);
        }

        int var = 0;

        while (degreeNode.size() > 0) {

            Iterator<Entry<Integer, Integer>> iteratorFromLast = degreeNode
                    .descendingValuesIterator();
            Entry<Integer, Integer> lastPair = iteratorFromLast.next();

            Iterator<Entry<Integer, Integer>> iteratorForIterator = degreeNode
                    .descendingValuesIterator(1);

            List<Entry<Integer, Integer>> toErase = new ArrayList<Map.Entry<Integer, Integer>>();

            int numberOfInserted = 0;

            for (int i = 0; i < lastPair.getKey(); i++) {

                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    en.get(lastPair.getValue()).add(iteratedPair.getValue());
                    en.get(iteratedPair.getValue()).add(lastPair.getValue());
                    numberOfInserted++;

                    toErase.add(iteratedPair);
                }

                else {
                    break;
                }
            }

            for (int i = 0; i < toErase.size(); i++) {

                if (toErase.get(i).getKey() > 1)
                    degreeNode.put(toErase.get(i).getKey() - 1, toErase.get(i).getValue());

                degreeNode.remove(toErase.get(i).getKey(), toErase.get(i).getValue());
            }

            var += lastPair.getKey() - numberOfInserted;
            degreeNode.remove(lastPair.getKey(), lastPair.getValue());

        }

        // this is to randomize the subgraph
        // -------------------------------------------------------------------

        for (int nodeA = 0; nodeA < degrees.size(); nodeA++)
            for (int krm = 0; krm < en.get(nodeA).size(); krm++) {

                int randomMate = (int) (Math.random() * degrees.size());
                while (randomMate == nodeA)
                    randomMate = (int) (Math.random() * degrees.size());

                if (en.get(nodeA).add(randomMate)) {

                    List<Integer> outNodes = new ArrayList<Integer>();
                    for (int itEst : en.get(nodeA)) {
                        if (itEst != randomMate) {
                            outNodes.add(itEst);
                        }
                    }

                    int oldNode = outNodes.get((int) (Math.random() * outNodes.size()));

                    en.get(nodeA).remove(oldNode);
                    en.get(randomMate).add(nodeA);
                    en.get(oldNode).remove(nodeA);

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : en.get(randomMate)) {
                        if (oldNode != itEst && !en.get(oldNode).contains(itEst)) {
                            notCommon.add(itEst);
                        }
                    }

                    int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                    en.get(randomMate).remove(nodeH);
                    en.get(nodeH).remove(randomMate);
                    en.get(nodeH).add(oldNode);
                    en.get(oldNode).add(nodeH);
                }
            }

        // now there is a rewiring process to avoid "mate nodes" (nodes with al
        // least one membership in common) to link each other

        int varMate = 0;
        for (int i = 0; i < degrees.size(); i++)
            for (int itss : en.get(i))
                if (Methods.theyAreMate(i, itss, memberList)) {
                    varMate++;
                }

        int stopperMate = 0;
        int mateTrooper = 10;

        while (varMate > 0) {

            int bestVarMate = varMate;

            // ************************************************ rewiring

            for (int a = 0; a < degrees.size(); a++)
                for (int its : en.get(a))
                    if (Methods.theyAreMate(a, its, memberList)) {
                        int b = its;
                        int stopperM = 0;

                        while (true) {
                            stopperM++;

                            int randomMate = (int) (Math.random() * degrees.size());
                            while (randomMate == a || randomMate == b)
                                randomMate = (int) (Math.random() * degrees.size());

                            if (!(Methods.theyAreMate(a, randomMate, memberList))
                                    && !en.get(a).contains(randomMate)) {

                                List<Integer> notCommon = new ArrayList<Integer>();
                                for (int itEst : en.get(randomMate))
                                    if ((b != itEst) && !en.get(b).contains(itEst))
                                        notCommon.add(itEst);

                                if (notCommon.size() > 0) {
                                    int nodeH = notCommon.get((int) (Math.random() * notCommon
                                            .size()));

                                    en.get(randomMate).remove(nodeH);
                                    en.get(randomMate).add(a);

                                    en.get(nodeH).remove(randomMate);
                                    en.get(nodeH).add(b);

                                    en.get(b).remove(a);
                                    en.get(b).add(nodeH);

                                    en.get(a).add(randomMate);
                                    en.get(a).remove(b);

                                    if (!Methods.theyAreMate(b, nodeH, memberList))
                                        varMate -= 2;

                                    if (Methods.theyAreMate(randomMate, nodeH, memberList))
                                        varMate -= 2;

                                    break;
                                }
                            }

                            if (stopperM == en.get(a).size())
                                break;

                        }

                        break; // this break is done because if you erased some
                               // link you have to stop this loop (en[i]
                               // changed)

                    }

            // ************************************************ rewiring

            if (varMate == bestVarMate) {

                stopperMate++;

                if (stopperMate == mateTrooper)
                    break;

            } else
                stopperMate = 0;

        }

        Map<Integer, MultiMap<Integer, Integer>> mapDegreeNode = new HashMap<Integer, MultiMap<Integer, Integer>>();
        for (int layerIndex = 1; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {

            mapDegreeNode.put(layerIndex, new MultiMap<Integer, Integer>());

            for (int node = 0; node < linkListML.get(layerIndex).size(); node++) {
                int externalDegree = linkListML.get(layerIndex).get(node)
                        .get(linkListML.get(layerIndex).get(node).size() - 1);
                if (externalDegree > 0)
                    mapDegreeNode.get(layerIndex).put(externalDegree, node);
            }
        }

        List<Integer> layersToDo = new ArrayList<Integer>(layers.size());
        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            layersToDo.add(layer);
        }

        while (layersToDo.size() != 0) {
            int layerIndex = (int) (Math.random() * layersToDo.size());

            int layer = layersToDo.get(layerIndex);

            Iterator<Entry<Integer, Integer>> iteratorFromLast = mapDegreeNode.get(layer)
                    .descendingValuesIterator();

            Entry<Integer, Integer> lastPair = null;
            if (iteratorFromLast.hasNext())
                lastPair = iteratorFromLast.next();

            boolean commonGroup = false;

            checkForCommonGroup: for (int nodeGroups : memberListML.get(layer).get(
                    lastPair.getValue())) {
                for (int baseLayerGroup : memberListML.get(0).get(lastPair.getValue())) {
                    if (nodeGroups == baseLayerGroup)

                    {
                        commonGroup = true;
                        break checkForCommonGroup;
                    }
                }
            }

            int insertedInFirstRound = 0;
            if (commonGroup) {

                List<Integer> insertedNodeNeighbours = new LinkedList<Integer>();
                List<Integer> nodeNeighbours = new LinkedList<Integer>();

                for (int nodeNeighbour : en.get(lastPair.getValue())) {
                    if (!layersInWork.get(layer).getAdjacencyMatrix().get(lastPair.getValue())
                            .contains(nodeNeighbour)
                            && nodeNeighbour != lastPair.getValue()
                            && linkListML.get(layer).get(nodeNeighbour)
                                    .get(linkListML.get(layer).get(nodeNeighbour).size() - 1) != layersInWork
                                    .get(layer).getAdjacencyMatrix().get(nodeNeighbour).size())
                        nodeNeighbours.add(nodeNeighbour);
                }

                int maxNeighbours = linkListML.get(layer).get(lastPair.getValue())
                        .get(linkListML.get(layer).get(lastPair.getValue()).size() - 1)
                        - layersInWork.get(layer).getAdjacencyMatrix().get(lastPair.getValue())
                                .size();
                while (nodeNeighbours.size() > 0 && insertedInFirstRound < maxNeighbours) {
                    int neighbourPropositionIndex = (int) (Math.random() * nodeNeighbours.size());
                    int neighbourProposition = nodeNeighbours.get(neighbourPropositionIndex);

                    int count = Methods.neighboursCount(layersInWork, lastPair.getValue(),
                            neighbourProposition);

                    try {

                        if (Math.random() >= parameters.getDistribution().cumulativeProbability(
                                count)) {
                            if (layersInWork.get(layer).getAdjacencyMatrix()
                                    .get(lastPair.getValue()).add(neighbourProposition)) {
                                layersInWork.get(layer).getAdjacencyMatrix()
                                        .get(neighbourProposition).add(lastPair.getValue());
                                insertedNodeNeighbours.add(neighbourProposition);
                                insertedInFirstRound++;
                            }
                        }
                    } catch (MathException me) {
                        throw new BenchmarkException("Distribution library internal error.");
                    }
                    nodeNeighbours.remove(neighbourPropositionIndex);
                }

                for (int i = 0; i < insertedNodeNeighbours.size(); i++) {
                    int toRemove = insertedNodeNeighbours.get(i);
                    int first = linkListML.get(layer).get(toRemove)
                            .get(linkListML.get(layer).get(toRemove).size() - 1)
                            - (layersInWork.get(layer).getAdjacencyMatrix().get(toRemove).size() - 1);

                    mapDegreeNode.get(layer).remove(first, toRemove);

                    if (first > 1)
                        mapDegreeNode.get(layer).put(first - 1, toRemove);
                }

            }
            // od indeksu?
            Iterator<Entry<Integer, Integer>> iteratorForIterator = mapDegreeNode.get(layer)
                    .descendingValuesIterator(1);

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            int numberOfInserted = 0;

            for (int i = 0; i < lastPair.getKey() - insertedInFirstRound; i++) {

                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    boolean commonMembership = false;

                    checkForCommonMembership: for (int nodeGroups : memberListML.get(layer).get(
                            lastPair.getValue())) {
                        for (int ititGroup : memberListML.get(layer).get(iteratedPair.getValue())) {
                            if (nodeGroups == ititGroup)

                            {
                                commonMembership = true;
                                break checkForCommonMembership;
                            }
                        }
                    }

                    while ((layersInWork.get(layer).getAdjacencyMatrix().get(lastPair.getValue())
                            .contains(iteratedPair.getValue()) || commonMembership)
                            && iteratorForIterator.hasNext()) {
                        iteratedPair = iteratorForIterator.next();

                        commonMembership = false;
                        checkForCommonMembership: for (int nodeGroups : memberListML.get(layer)
                                .get(lastPair.getValue())) {
                            for (int ititGroup : memberListML.get(layer).get(
                                    iteratedPair.getValue())) {
                                if (nodeGroups == ititGroup)

                                {
                                    commonMembership = true;
                                    break checkForCommonMembership;
                                }
                            }
                        }

                    }

                    if ((layersInWork.get(layer).getAdjacencyMatrix().get(lastPair.getValue())
                            .contains(iteratedPair.getValue()) || commonMembership))
                        break;

                    layersInWork.get(layer).getAdjacencyMatrix().get(lastPair.getValue())
                            .add(iteratedPair.getValue());
                    layersInWork.get(layer).getAdjacencyMatrix().get(iteratedPair.getValue())
                            .add(lastPair.getValue());
                    numberOfInserted++;

                    toErase.add(iteratedPair);
                }

                else
                    break;

            }

            for (int i = 0; i < toErase.size(); i++) {
                if (toErase.get(i).getKey() > 1)
                    mapDegreeNode.get(layer).put(toErase.get(i).getKey() - 1,
                            toErase.get(i).getValue());

                mapDegreeNode.get(layer).remove(toErase.get(i).getKey(), toErase.get(i).getValue());
            }

            mapDegreeNode.get(layer).remove(lastPair.getKey(), lastPair.getValue());

            if (mapDegreeNode.get(layer).size() == 0)
                layersToDo.remove(layerIndex);

        }

        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++)
            for (int i = 0; i < layersInWork.get(layer).getAdjacencyMatrix().size(); i++)
                for (int its : layersInWork.get(layer).getAdjacencyMatrix().get(i))
                    if (i < its) {
                        layers.get(layer).getAdjacencyMatrix().get(i).add(its);
                        layers.get(layer).getAdjacencyMatrix().get(its).add(i);
                    }

        return 0;

    }

    protected int setInternalDegreeSequence(List<Integer> degreeSequence,
            List<Integer> internalDegreeSeq, double mixingParameter) {
        int actualMaxDegree = 0;
        for (int i = 0; i < degreeSequence.size(); i++) {
            double interno = (1 - mixingParameter) * degreeSequence.get(i);
            int internoInt = (int) interno;

            if (Math.random() < interno - internoInt) {
                internoInt++;
            }

            internalDegreeSeq.add(internoInt);

            if ((int) (internoInt * LFRNetworkParameters.SPACING) > actualMaxDegree) {
                actualMaxDegree = (int) (internoInt * LFRNetworkParameters.SPACING);
            }
        }
        return actualMaxDegree;
    }

    protected void changeDegree(Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML) {
        List<List<Integer>> memberMatrixLayer;
        List<List<Integer>> memberListLayer;
        List<List<Integer>> linkListLayer;

        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            memberListLayer = memberListML.get(layer);
            memberMatrixLayer = memberMatrixML.get(layer);
            linkListLayer = linkListML.get(layer);

            for (int group = 0; group < memberMatrixLayer.size(); group++) {
                node: for (int nodeIndex = 0; nodeIndex < memberMatrixLayer.get(group).size(); nodeIndex++) {
                    int node = memberMatrixLayer.get(group).get(nodeIndex);
                    if (Math.random() <= parameters.getDegreeChangeChance()
                            && memberListLayer.get(node).size() == 1) {
                        int swapNodeIndex = (int) (Math.random() * memberMatrixLayer.get(group)
                                .size());
                        int swapNode = memberMatrixLayer.get(group).get(swapNodeIndex);

                        int inNodeDegree = linkListLayer.get(node).get(0);
                        int inSwapDegree = linkListLayer.get(swapNode).get(0);

                        int outSwapDegree = linkListLayer.get(node).get(1);
                        int outNodeDegree = linkListLayer.get(swapNode).get(1);

                        // Warunki:
                        // nie mog� by� to te same indexy
                        // nie mo�e �aden by� overlapping
                        // outDegree �adnego nei mo�e przekracza� podmienianego
                        // inDegree

                        HashSet<Integer> checkedNodes = new HashSet<Integer>();
                        while (checkedNodes.contains(swapNode) || nodeIndex == swapNodeIndex
                                || memberListLayer.get(swapNode).size() != 1
                                || outSwapDegree >= inNodeDegree || outNodeDegree >= inSwapDegree) {
                            checkedNodes.add(swapNode);
                            if (checkedNodes.size() == memberMatrixLayer.get(group).size()) {
                                break node;
                            }

                            swapNodeIndex = (int) (Math.random() * memberMatrixLayer.get(group)
                                    .size());
                            swapNode = memberMatrixLayer.get(group).get(swapNodeIndex);

                            inNodeDegree = linkListLayer.get(node).get(0);
                            inSwapDegree = linkListLayer.get(swapNode).get(0);

                            outSwapDegree = linkListLayer.get(node).get(1);
                            outNodeDegree = linkListLayer.get(swapNode).get(1);

                        }

                        linkListLayer.get(node).set(0, inSwapDegree);
                        linkListLayer.get(swapNode).set(0, inNodeDegree);
                        // oba nie s� overlapping wi�c mo�na sobie pozwoli� na
                        // ca�o�ciow� zamian�

                    }
                }
            }
        }
    }

    protected void swapMembers(Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListML) {
        List<List<Integer>> memberList = memberListML.get(0);
        // List<List<Integer>> memberMatrix = memberMatrixML.get(0);

        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            List<List<Integer>> memberListLayer = memberListML.get(layer);
            List<List<Integer>> memberMatrixLayer = memberMatrixML.get(layer);
            List<List<Integer>> linkListLayer = linkListML.get(layer);

            nextNode: for (int node = 0; node < memberList.size(); node++) {
                if (Math.random() <= parameters.getRelocatingChance()) {
                    int newGroup = -1;
                    {
                        List<Integer> groupsAvailableForNode = new ArrayList<Integer>();
                        for (int groupProposal = 0; groupProposal < memberMatrixLayer.size(); groupProposal++) {
                            if (!memberListLayer.get(node).contains(groupProposal)) {// rozwa�amy
                                                                                     // aktualny
                                groupsAvailableForNode.add(groupProposal);
                            }
                        }
                        // jakie warunki na dost�pne grupy? musi by� r�na i nie
                        // powinien do niej nale�e�

                        if (groupsAvailableForNode.size() == 0) {
                            continue nextNode;
                        }

                        newGroup = groupsAvailableForNode
                                .get((int) (Math.random() * groupsAvailableForNode.size()));
                    }

                    int swapNodeIndex = (int) (Math.random() * memberMatrixLayer.get(newGroup)
                            .size());
                    int swapNode = memberMatrixLayer.get(newGroup).get(swapNodeIndex);

                    List<Integer> tempLinkList = linkListLayer.set(swapNode,
                            linkListLayer.get(node));
                    linkListLayer.set(node, tempLinkList);

                    for (int groupNode : memberListLayer.get(node)) {
                        memberMatrixLayer.get(groupNode).remove(
                                memberMatrixLayer.get(groupNode).indexOf(node));
                        memberMatrixLayer.get(groupNode).add(swapNode);
                    }
                    for (int groupSwapNode : memberListLayer.get(swapNode)) {
                        memberMatrixLayer.get(groupSwapNode).remove(
                                memberMatrixLayer.get(groupSwapNode).indexOf(swapNode));
                        memberMatrixLayer.get(groupSwapNode).add(node);
                    }

                    List<Integer> tempMemberList = memberListLayer.set(swapNode,
                            memberListLayer.get(node));
                    memberListLayer.set(node, tempMemberList);

                }

            }

            for (int i = 0; i < memberMatrixLayer.size(); i++)
                Collections.sort(memberMatrixLayer.get(i));
        }
    }

}
