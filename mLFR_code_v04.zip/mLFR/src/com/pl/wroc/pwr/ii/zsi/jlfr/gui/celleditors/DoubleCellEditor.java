package com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors;

import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JFormattedTextField;
import javax.swing.JTable;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.NumberFormatter;

public class DoubleCellEditor extends ParameterCellEditor {

    private JFormattedTextField field;
    private NumberFormat doubleFormat;

    public DoubleCellEditor(JTable table) {
        this(table, null, null);
    }

    public DoubleCellEditor(JTable table, Double minimum, Double maximum) {
        super(table, new JFormattedTextField());

        field = (JFormattedTextField) getComponent();

        doubleFormat = NumberFormat.getNumberInstance(ParameterCellEditor.LOCALE);
        NumberFormatter formatter = new NumberFormatter(doubleFormat);

        if (minimum != null) {
            formatter.setMinimum(minimum);
        }
        if (minimum != null) {
            formatter.setMaximum(maximum);
        }
        field.setFormatterFactory(new DefaultFormatterFactory(formatter));

    }

    public Object getCellEditorValue() {
        JFormattedTextField field = (JFormattedTextField) getComponent();
        Object o = field.getValue();
        if (o == null) {
            return null;
        }

        if (o instanceof Double) {
            return o;
        } else if (o instanceof Number) {
            return new Double(((Number) o).doubleValue());
        } else {

            try {
                return doubleFormat.parseObject(o.toString());
            } catch (ParseException exc) {
                return null;
            }
        }
    }
}
