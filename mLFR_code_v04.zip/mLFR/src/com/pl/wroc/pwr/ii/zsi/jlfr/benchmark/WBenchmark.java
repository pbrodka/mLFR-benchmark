package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.MultiLayeredNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.NetworkFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.WeightedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRWeightedNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public class WBenchmark extends LFRNonDirectedBenchmark<WeightedNetwork> {

    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    private final LFRWeightedNetworkParameters parameters;

    public WBenchmark(LFRWeightedNetworkParameters parameters) {
        super(parameters);
        this.parameters = parameters;
    }

    @Override
    public MultiLayeredNetwork<WeightedNetwork> generate() throws BenchmarkException {
        MultiLayeredNetwork<WeightedNetwork> network = NetworkFactory
                .createMultiLayeredWeightedNetwork(parameters);

        writer.println(messages.getMessage("Benchmark.StartGeneration"), true, true);
        List<Integer> degreeSequence = getDegreeSequence();

        /*
         * numSeq - zawiera liczebno�ci grup, np. dwa elementy, jeden o warto�ci
         * 4, drugi o warto�ci 6 symbolizuj�ce istnienie dw�ch grup, jedna o 4
         * w�z�ach, druga o 6
         */
        List<Integer> numSeq = new ArrayList<Integer>();

        /*
         * internalDegreeSeq - lista stopni wewn�trznych, i.e. stopie� w�z�a
         * licz�c po��czenia tylko w grupie indeksy odpowiadaj� indeksom z
         * degreeSequence, i.e. element pod indeksem 0 na obu listach, to ten
         * sam w�ze� lista przedstawia sum� internalDegree, i.e. w przypadku
         * overlapping jest to suma po wszystkich grupach, do kt�rej dany w�ze�
         * nale�y
         */
        List<Integer> internalDegreeSeq = new ArrayList<Integer>();

        /*
         * Disclaimer: ML to skr�t od Multi Layered, tak s� oznaczone mapy,
         * gdzie klucz to warstwa, a warto�� to jaka� kolekcja, b�d� opisywa�
         * g��wnie o co chodzi z warto�ciami
         * 
         * Warto�� to lista o liczebno�ci r�wnej liczbie grup, gdzie pod
         * poszczeg�lnymi indeksami znajduj� si� listy, zawieraj�ce indeksy
         * wszystkich w�z��w nale��cych do danej grupy.
         */
        Map<Integer, List<List<Integer>>> memberMatrixML = new HashMap<Integer, List<List<Integer>>>();
        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberMatrixML.put(layer, new ArrayList<List<Integer>>());
        }

        /*
         * Magia, patrz do �rodka
         */
        internalDegreeAndMembership(memberMatrixML.get(0), degreeSequence, numSeq,
                internalDegreeSeq);

        List<WeightedNetwork> layers = network.getLayers();

        /*
         * LinkListML dla ka�dej warstwy zawiera list� po��cze� danego w�z�a
         * (opisywanego przez indeks). Ostatni element listy dla konkretnego
         * w�z�a opisuje liczb� po��cze� external, pozosta�e internal, i.e. (5,
         * 5, 2) m�wi, �e w�ze� jest overlapping, w pierwszej grupie ma 5
         * s�siad�w, w drugiej 5 oraz 2 s�siad�w nienale��cych do �adnej z jego
         * grup (pomi�dzy spo�eczno�ciami). Powy�szy opis nie m�wi konkretnie o
         * jakich grupach mowa, te informacje mo�na wydoby� w po��czeniu z
         * opisem w memberListML.
         */
        Map<Integer, List<List<Integer>>> linkListML = new HashMap<Integer, List<List<Integer>>>();

        /*
         * memberListML dla ka�dej warsty zawiera informacj� o grupach do jakich
         * dany w�ze� nale�y.
         */
        Map<Integer, List<List<Integer>>> memberListML = new HashMap<Integer, List<List<Integer>>>();

        for (int layer = 0; layer < parameters.getNumberOfLayers(); layer++) {
            memberListML.put(layer, layers.get(layer).getMemberList());
            linkListML.put(layer, new ArrayList<List<Integer>>());
        }

        /*
         * Wywo�ywana tylko dla warstwy bazowej
         */
        buildSubgraphs(layers.get(0), memberMatrixML.get(0), memberListML.get(0),
                linkListML.get(0), internalDegreeSeq, degreeSequence);

        for (int i = 0; i < layers.get(0).getAdjacencyMatrix().size(); i++) {
            if (layers.get(0).getAdjacencyMatrix().get(i).size() != linkListML.get(0).get(i).get(0)) {
                linkListML.get(0).get(i).set(0, layers.get(0).getAdjacencyMatrix().get(i).size());
            }
        }

        /*
         * Inicjalizacja kolekcji opisuj�cych warstwy. Pocz�tkowo wszystkie
         * warstwy s� kopi� bazowej.
         */
        initializeLayers(memberMatrixML, memberListML, linkListML);

        /*
         * Funkcja zmieniaj�ca degree w�z��w w obr�bie grupy
         */
        if (parameters.getDegreeChangeChance() > 0) {
            changeDegree(memberMatrixML, memberListML, linkListML);
        }

        /*
         * Funkcja mieszaj�ca cz�onkowstwo w�z��w
         */
        if (parameters.getRelocatingChance() > 0) {
            swapMembers(memberMatrixML, memberListML, linkListML);
        }

        /*
             * 
             */
        buildLayers(layers, memberMatrixML, memberListML, linkListML);

        writer.println(messages.getMessage("Benchmark.ConnectingCommunities"), true, true);
        connectAllTheParts(layers, memberListML, linkListML);

        writer.println(messages.getMessage("Benchmark.IntroducingWeights"), true, true);
        for (int layer = 0; layer < layers.size(); layer++) {
            WeightedNetwork directedWeightedNetwork = layers.get(layer);
            weights(directedWeightedNetwork.getAdjacencyMatrix(), memberListML.get(layer),
                    directedWeightedNetwork.getWeights());
        }

        return network;
    }

    private void weights(List<Set<Integer>> en, List<List<Integer>> memberList,
            List<Map<Integer, Double>> neighboursWeights) {
        double tStrength = 0;

        for (int i = 0; i < en.size(); i++) {
            tStrength += Math.pow(en.get(i).size(), parameters.getWeightDistributionExponent());
        }

        Double strs[] = new Double[en.size()]; // strength of the nodes
        // build a matrix like this: deque < map <int, double > > each row
        // corresponds to link - weights

        for (int i = 0; i < en.size(); i++) {

            for (int its : en.get(i)) {
                neighboursWeights.get(i).put(its, 0.);
            }
            // TODO sprawdz z neigh_weigh[i].insert(make_pair(*its, 0.));
            // sortowanie po kluczach i 0.

            strs[i] = Math.pow(en.get(i).size(), parameters.getWeightDistributionExponent());

        }

        List<Double> sInOutIdRow = new ArrayList<Double>(3);
        sInOutIdRow.add(0.0);
        sInOutIdRow.add(0.0);
        sInOutIdRow.add(0.0);

        List<List<Double>> wished = new ArrayList<List<Double>>(en.size());
        // 3
        // numbers
        // for
        // each
        // node:
        // internal,
        // idle
        // and
        // extra
        // strength.
        // the
        // sum
        // of
        // the
        // three
        // is
        // strs[i].
        // wished
        // is
        // the
        // theoretical,
        // factual
        // the
        // factual
        // one.
        List<List<Double>> factual = new ArrayList<List<Double>>(en.size());

        for (int i = 0; i < en.size(); i++) {
            wished.add(new ArrayList<Double>(sInOutIdRow));
            factual.add(new ArrayList<Double>(sInOutIdRow));
        }

        double totVar = 0;

        for (int i = 0; i < en.size(); i++) {
            List<Double> wishedI = wished.get(i);

            wishedI.set(0, (1. - parameters.getWeightsMixingParameter()) * strs[i]);
            wishedI.set(1, parameters.getWeightsMixingParameter() * strs[i]);

            factual.get(i).set(2, strs[i]);

            totVar += wishedI.get(0) * wishedI.get(0) + wishedI.get(1) * wishedI.get(1) + strs[i]
                    * strs[i];
        }

        List<Integer> internalKinTop = new ArrayList<Integer>(en.size());
        for (int i = 0; i < en.size(); i++) {
            internalKinTop.add(Methods.internalKin(en, memberList, i));
        }

        double precision = 1e-9;
        double precision2 = 1e-2;
        double notBetterThan = Math.pow(tStrength, 2) * precision;

        int step = 0;

        while (true) {

            double preVar = totVar;

            for (int i = 0; i < en.size(); i++) {
                propagate(neighboursWeights, memberList, wished, factual, i, totVar, internalKinTop);
            }
            // check_weights(neigh_weigh, member_list, wished, factual, tot_var,
            // strs);

            // TODO sprawdz dzialanie
            double relativeImprovement = (double) (preVar - totVar) / preVar;
            // cout<<"tot_var "<<tot_var<<"\trelative improvement: "<<relative_improvement<<endl;

            if (totVar < notBetterThan) {
                break;
            }

            if (relativeImprovement < precision2) {
                break;
            }
            step++;

        }

    }

    private void propagate(List<Map<Integer, Double>> neighboursWeights,
            List<List<Integer>> memberList, List<List<Double>> wished, List<List<Double>> factual,
            int i, double totVar, List<Integer> internalKinTop) {
        { // in this case I rewire the idle strength

            double change = factual.get(i).get(2) / neighboursWeights.get(i).size();

            double oldPartVar = 0;

            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet())
                if (itm.getValue() + change > 0) {
                    for (int bw = 0; bw < 3; bw++) {
                        oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                .get(bw))
                                * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                        .get(bw));
                    }
                }
            for (int bw = 0; bw < 3; bw++) {
                oldPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }

            double newPartVar = 0;

            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {
                if (Methods.theyAreMate(i, itm.getKey(), memberList)) {
                    factual.get(itm.getKey()).set(0, factual.get(itm.getKey()).get(0) + change);
                    factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                    factual.get(i).set(0, factual.get(i).get(0) + change);
                    factual.get(i).set(2, factual.get(i).get(2) - change);

                } else {

                    factual.get(itm.getKey()).set(1, factual.get(itm.getKey()).get(1) + change);
                    factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                    factual.get(i).set(1, factual.get(i).get(1) + change);
                    factual.get(i).set(2, factual.get(i).get(2) - change);

                }

                for (int bw = 0; bw < 3; bw++) {
                    newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                            .get(bw))
                            * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey()).get(bw));
                }

                itm.setValue(itm.getValue() + change);
                neighboursWeights.get(itm.getKey()).put(i,
                        neighboursWeights.get(itm.getKey()).get(i) + change);
                // neigh_weigh[itm->first][i]+=change;
            }

            for (int bw = 0; bw < 3; bw++) {
                newPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }

            totVar += newPartVar - oldPartVar;

        }

        int internalNeighbour = internalKinTop.get(i);

        if (internalNeighbour != 0) {
            // in this case I rewire the difference strength

            double changeNN = (factual.get(i).get(0) - wished.get(i).get(0));

            double oldPartVar = 0;
            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {
                if (Methods.theyAreMate(i, itm.getKey(), memberList)) {

                    double change = changeNN / internalNeighbour;

                    if (itm.getValue() - change > 0) {
                        for (int bw = 0; bw < 3; bw++) {
                            oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }
                    }
                } else {

                    double change = changeNN
                            / (neighboursWeights.get(i).size() - internalNeighbour);

                    if (itm.getValue() + change > 0) {
                        for (int bw = 0; bw < 3; bw++) {
                            oldPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }
                    }
                }
            }

            for (int bw = 0; bw < 3; bw++) {
                oldPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }
            double newPartVar = 0;

            for (Map.Entry<Integer, Double> itm : neighboursWeights.get(i).entrySet()) {

                if (Methods.theyAreMate(i, itm.getKey(), memberList)) {
                    double change = changeNN / internalNeighbour;

                    if (itm.getValue() - change > 0) {
                        factual.get(itm.getKey()).set(0, factual.get(itm.getKey()).get(0) - change);
                        factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) + change);

                        factual.get(i).set(0, factual.get(i).get(0) - change);
                        factual.get(i).set(2, factual.get(i).get(2) + change);

                        for (int bw = 0; bw < 3; bw++) {
                            newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }

                        itm.setValue(itm.getValue() - change);
                        neighboursWeights.get(itm.getKey()).put(i,
                                neighboursWeights.get(itm.getKey()).get(i) - change);

                    }
                } else {
                    double change = changeNN
                            / (neighboursWeights.get(i).size() - internalNeighbour);

                    if (itm.getValue() + change > 0) {
                        factual.get(itm.getKey()).set(1, factual.get(itm.getKey()).get(1) + change);
                        factual.get(itm.getKey()).set(2, factual.get(itm.getKey()).get(2) - change);

                        factual.get(i).set(1, factual.get(i).get(1) + change);
                        factual.get(i).set(2, factual.get(i).get(2) - change);

                        for (int bw = 0; bw < 3; bw++) {
                            newPartVar += (factual.get(itm.getKey()).get(bw) - wished.get(
                                    itm.getKey()).get(bw))
                                    * (factual.get(itm.getKey()).get(bw) - wished.get(itm.getKey())
                                            .get(bw));
                        }

                        itm.setValue(itm.getValue() + change);
                        neighboursWeights.get(itm.getKey()).put(i,
                                neighboursWeights.get(itm.getKey()).get(i) + change);

                    }
                }
            }

            for (int bw = 0; bw < 3; bw++) {
                newPartVar += (factual.get(i).get(bw) - wished.get(i).get(bw))
                        * (factual.get(i).get(bw) - wished.get(i).get(bw));
            }

            totVar += newPartVar - oldPartVar;
        }
    }
}
