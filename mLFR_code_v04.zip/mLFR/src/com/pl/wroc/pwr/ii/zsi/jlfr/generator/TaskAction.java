package com.pl.wroc.pwr.ii.zsi.jlfr.generator;

public interface TaskAction {
    public void perform();
}
