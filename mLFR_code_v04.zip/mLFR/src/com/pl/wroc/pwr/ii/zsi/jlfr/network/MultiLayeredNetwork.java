package com.pl.wroc.pwr.ii.zsi.jlfr.network;

import java.util.ArrayList;
import java.util.List;

import com.pl.wroc.pwr.ii.zsi.jlfr.network.interfaces.INetwork;

public class MultiLayeredNetwork<T extends INetwork> {
    public MultiLayeredNetwork(Integer numberOfLayers) {
        this.layers = new ArrayList<T>();
    }

    private List<T> layers;

    public List<T> getLayers() {
        return layers;
    }

    public void setLayers(List<T> layers) {
        this.layers = layers;
    }

    public int getNumberOfLayers() {
        return layers.size();
    }
}
