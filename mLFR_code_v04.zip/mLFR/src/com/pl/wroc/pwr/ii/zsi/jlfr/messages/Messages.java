package com.pl.wroc.pwr.ii.zsi.jlfr.messages;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Messages {

    public static Messages messages = new Messages();
    private static Properties properties;

    public static Messages getInstance() {
        return messages;
    }

    private Messages() {
        try {
            properties = new Properties();
            InputStream in = getClass().getResourceAsStream("messages.properties");
            properties.load(in);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String getMessage(String property) {
        if (!properties.containsKey(property)) {
            throw new IllegalArgumentException("Properties: not found " + property);
        }
        return (String) properties.getProperty(property);
    }

    public String getMessage(Object property) {
        String propertyMapping = property.getClass().getName();
        if (!properties.containsKey(propertyMapping)) {
            throw new IllegalArgumentException("Properties: not found " + property);
        }
        return (String) properties.getProperty(propertyMapping);
    }

    public String getMessage(Enum<?> property) {
        String propertyMapping = property.getClass().getName() + "." + property.name();
        if (!properties.containsKey(propertyMapping)) {
            throw new IllegalArgumentException("Properties: not found " + property);
        }
        return (String) properties.getProperty(propertyMapping);
    }

    public String getErrorMessage(String property) {
        return "*** " + getMessage(property) + " ***";
    }
}
