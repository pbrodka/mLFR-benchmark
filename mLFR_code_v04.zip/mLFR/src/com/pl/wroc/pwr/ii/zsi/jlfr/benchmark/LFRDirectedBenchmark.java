package com.pl.wroc.pwr.ii.zsi.jlfr.benchmark;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.math.MathException;

import com.google.common.collect.Lists;
import com.google.common.collect.Ordering;
import com.pl.wroc.pwr.ii.zsi.jlfr.exceptions.BenchmarkException;
import com.pl.wroc.pwr.ii.zsi.jlfr.messages.Messages;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.MultiMap;
import com.pl.wroc.pwr.ii.zsi.jlfr.model.Pair;
import com.pl.wroc.pwr.ii.zsi.jlfr.network.DirectedNetwork;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.LFRNetworkParameters;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.Methods;
import com.pl.wroc.pwr.ii.zsi.jlfr.utils.writer.Writer;

public abstract class LFRDirectedBenchmark<T extends DirectedNetwork> extends LFRBenchmark<T> {
    private static final Writer writer = Writer.getInstance();
    private static final Messages messages = Messages.getInstance();

    protected LFRDirectedBenchmark(LFRNetworkParameters parameters) {
        super(parameters);
    }

    protected void internalDegreeAndMembership(List<List<Integer>> memberMatrix,
            List<Integer> inDegreeSequence, List<Integer> outDegreeSequence, List<Integer> numSeq,
            List<Integer> inInternalDegreeSeq, List<Integer> outInternalDegreeSeq)
            throws BenchmarkException {

        memberMatrix.clear();
        inInternalDegreeSeq.clear();

        List<Double> cumulative = Methods.powerlaw(parameters.getMaximalCommunity(),
                parameters.getMinimalCommunity(), parameters.getTau2());

        int actualMaxDegree = setInternalDegreeSequence(inDegreeSequence, inInternalDegreeSeq,
                parameters.getTopologyMixingParameter());

        setInternalDegreeSequence(outDegreeSequence, outInternalDegreeSeq,
                parameters.getTopologyMixingParameter());

        // TODO sporo do uwsp�lnienia w metodach
        if (numSeq.isEmpty()) {
            int sumOfCommunitiesSizes = 0;
            if (!parameters.isFixedRange()
                    && (actualMaxDegree + 1) > parameters.getMinimalCommunity()) {

                sumOfCommunitiesSizes = actualMaxDegree + 1;
                numSeq.add(sumOfCommunitiesSizes);
            }

            int maximalSumOfCommunities = parameters.getNumberOfNodes()
                    + parameters.getOverlappingNodes()
                    * (parameters.getOverlappingMembership() - 1);

            int communitySizeProposition = Methods.lowerBound(cumulative, Math.random())
                    + parameters.getMinimalCommunity();

            while (communitySizeProposition + sumOfCommunitiesSizes <= maximalSumOfCommunities) {
                numSeq.add(communitySizeProposition);
                sumOfCommunitiesSizes += communitySizeProposition;

                communitySizeProposition = Methods.lowerBound(cumulative, Math.random())
                        + parameters.getMinimalCommunity();
            }

            int indexOfMinimal = numSeq.indexOf(Collections.min(numSeq));
            numSeq.set(indexOfMinimal, numSeq.get(indexOfMinimal) + parameters.getNumberOfNodes()
                    + parameters.getOverlappingNodes()
                    * (parameters.getOverlappingMembership() - 1) - sumOfCommunitiesSizes);

        }

        List<Integer> memberNumbers = new ArrayList<Integer>(inDegreeSequence.size());
        for (int i = 0; i < parameters.getOverlappingNodes(); i++)
            memberNumbers.add(parameters.getOverlappingMembership());

        for (int i = parameters.getOverlappingNodes(); i < inDegreeSequence.size(); i++)
            memberNumbers.add(1);

        buildBipartiteNetwork(memberMatrix, memberNumbers, numSeq);

        List<Integer> available = new ArrayList<Integer>(parameters.getNumberOfNodes());
        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            available.add(0);
        }

        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                available.set(memberMatrix.get(i).get(j), available.get(memberMatrix.get(i).get(j))
                        + memberMatrix.get(i).size() - 1);
            }
        }

        List<Integer> availableNodes = new ArrayList<Integer>(parameters.getNumberOfNodes());
        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            availableNodes.add(i);
        }

        List<Integer> mapNodes = new ArrayList<Integer>(parameters.getNumberOfNodes()); // in

        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            mapNodes.add(0);
        }

        for (int i = inDegreeSequence.size() - 1; i >= 0; i--) {
            int tryThis = (int) (Math.random() * availableNodes.size());

            int kr = 0;

            while ((int) (inInternalDegreeSeq.get(i) * LFRNetworkParameters.SPACING) > available
                    .get(availableNodes.get(tryThis))) {
                kr++;

                tryThis = (int) (Math.random() * availableNodes.size());

                if (kr == 3 * parameters.getNumberOfNodes()) {
                    Methods.changeCommunitySize(numSeq);

                    writer.println(messages.getMessage("Benchmark.TooSmallCommunities"), true, true);

                    internalDegreeAndMembership(memberMatrix, inDegreeSequence, outDegreeSequence,
                            numSeq, inInternalDegreeSeq, outInternalDegreeSeq);
                    return;
                }
            }

            mapNodes.set(availableNodes.get(tryThis), i);

            availableNodes.set(tryThis, availableNodes.get(availableNodes.size() - 1));
            availableNodes.remove(availableNodes.size() - 1);

        }

        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                memberMatrix.get(i).set(j, mapNodes.get(memberMatrix.get(i).get(j)));
            }
        }

        for (int i = 0; i < memberMatrix.size(); i++) {
            Collections.sort(memberMatrix.get(i));
        }
    }

    protected void buildSubgraphs(T layer, List<List<Integer>> memberMatrix,
            List<List<Integer>> memberList, List<List<Integer>> linkListIn,
            List<List<Integer>> linkListOut, List<Integer> inInternalDegreeSeq,
            List<Integer> inDegreeSeq, List<Integer> outInternalDegreeSeq,
            List<Integer> outDegreeSeq) throws BenchmarkException {

        for (int i = 0; i < memberMatrix.size(); i++) {
            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                memberList.get(memberMatrix.get(i).get(j)).add(i);
            }
        }

        for (int i = 0; i < memberList.size(); i++) {

            List<Integer> liin = new ArrayList<Integer>();
            List<Integer> liout = new ArrayList<Integer>();

            for (int j = 0; j < memberList.get(i).size(); j++) {
                Methods.computeInternalDegreePerNode(inInternalDegreeSeq.get(i), memberList.get(i)
                        .size(), liin);
                liin.add(inDegreeSeq.get(i) - inInternalDegreeSeq.get(i));

                Methods.computeInternalDegreePerNode(outInternalDegreeSeq.get(i), memberList.get(i)
                        .size(), liout);
                liout.add(outDegreeSeq.get(i) - outInternalDegreeSeq.get(i));
            }

            linkListIn.add(liin);
            linkListOut.add(liout);
        }

        // now there is the check for the even node (it means that the internal
        // degree of each group has to be even and we want to assure that,
        // otherwise the degree_seq has to change) ----------------------------

        // ------------------------ this is done to check if the sum of the
        // internal degree is an even number. if not, the program will change it
        // in such a way to assure that.

        for (int i = 0; i < memberMatrix.size(); i++) {
            int internalClusterIn = 0;
            int internalClusterOut = 0;

            for (int j = 0; j < memberMatrix.get(i).size(); j++) {

                int rightIndex = Methods.lowerBound(memberList.get(memberMatrix.get(i).get(j)), i);

                internalClusterIn += linkListIn.get(memberMatrix.get(i).get(j)).get(rightIndex);
                internalClusterOut += linkListOut.get(memberMatrix.get(i).get(j)).get(rightIndex);
            }

            int initialDiff = Math.abs(internalClusterIn - internalClusterOut);

            for (int diffLoop = 0; diffLoop < 3 * initialDiff; diffLoop++) {

                if ((internalClusterIn - internalClusterOut) == 0) {
                    break;
                }

                // if this does not work in a reasonable time the degree
                // sequence will be changed

                for (int j = 0; j < memberMatrix.get(i).size(); j++) {

                    int randomMate = memberMatrix.get(i).get(
                            (int) (Math.random() * memberMatrix.get(i).size()));
                    int rightIndex = Methods.lowerBound(memberList.get(randomMate), i);

                    if (internalClusterIn > internalClusterOut) {

                        if ((linkListOut.get(randomMate).get(rightIndex) < memberMatrix.get(i)
                                .size() - 1)
                                && (linkListOut.get(randomMate).get(
                                        linkListOut.get(randomMate).size() - 1) > 0)) {
                            linkListOut.get(randomMate).set(rightIndex,
                                    linkListOut.get(randomMate).get(rightIndex) + 1);
                            linkListOut.get(randomMate).set(
                                    linkListOut.get(randomMate).size() - 1,
                                    linkListOut.get(randomMate).get(
                                            linkListOut.get(randomMate).size() - 1) - 1);
                            internalClusterOut++;

                            break;
                        }
                    } else if (linkListOut.get(randomMate).get(rightIndex) > 0) {
                        linkListOut.get(randomMate).set(rightIndex,
                                linkListOut.get(randomMate).get(rightIndex) - 1);
                        linkListOut.get(randomMate).set(
                                linkListOut.get(randomMate).size() - 1,
                                linkListOut.get(randomMate).get(
                                        linkListOut.get(randomMate).size() - 1) + 1);
                        internalClusterOut--;

                        break;

                    }

                }

            }

            for (int diffLoop = 0; diffLoop < 3 * initialDiff; diffLoop++) {
                if ((internalClusterIn - internalClusterOut) == 0) {
                    break;
                }

                for (int j = 0; j < memberMatrix.get(i).size(); j++) {

                    int randomMate = memberMatrix.get(i).get(
                            (int) (Math.random() * memberMatrix.size()));
                    int rightIndex = Methods.lowerBound(memberList.get(randomMate), i);

                    if (internalClusterIn > internalClusterOut) {
                        if ((linkListOut.get(randomMate).get(rightIndex) < memberMatrix.get(i)
                                .size() - 1)) {
                            linkListOut.get(randomMate).set(rightIndex,
                                    linkListOut.get(randomMate).get(rightIndex) + 1);
                            internalClusterOut++;

                            break;
                        }
                    }

                    else {

                        linkListOut.get(randomMate).set(rightIndex,
                                linkListOut.get(randomMate).get(rightIndex) - 1);
                        internalClusterOut--;

                        break;

                    }

                }

            }

        }

        // ------------------------ this is done to check if the sums of the
        // internal degrees (in and out) are equal. if not, the program will
        // change it in such a way to assure that.

        for (int i = 0; i < memberMatrix.size(); i++) {
            List<Integer> internalDegreeIn = new ArrayList<Integer>();
            List<Integer> internalDegreeOut = new ArrayList<Integer>();

            for (int j = 0; j < memberMatrix.get(i).size(); j++) {
                int rightIndex = Methods.lowerBound(memberList.get(memberMatrix.get(i).get(j)), i);
                internalDegreeIn.add(linkListIn.get(memberMatrix.get(i).get(j)).get(rightIndex));
                internalDegreeOut.add(linkListOut.get(memberMatrix.get(i).get(j)).get(rightIndex));

            }

            buildSubgraph(layer.getInAdjacencyMatrix(), layer.getOutAdjacencyMatrix(),
                    memberMatrix.get(i), internalDegreeIn, internalDegreeOut);
        }
    }

    protected void buildSubgraph(List<Set<Integer>> adjacencyMatrixIn,
            List<Set<Integer>> adjacencyMatrixOut, List<Integer> nodes,
            List<Integer> internalDegreeIn, List<Integer> internalDegreeOut)
            throws BenchmarkException {
        if (internalDegreeIn.size() < 3) {
            throw new BenchmarkException(messages.getErrorMessage("Exception.ToSmallCommunities"));
        }

        // this function is to build a network with the labels stored in nodes
        // and the degree seq in degrees (correspondence is based on the
        // vectorial index)
        // the only complication is that you don't want the nodes to have
        // neighbors they already have

        // labels will be placed in the end
        List<TreeSet<Integer>> enIn = new ArrayList<TreeSet<Integer>>(nodes.size()); // this
        List<TreeSet<Integer>> enOut = new ArrayList<TreeSet<Integer>>(nodes.size()); // this
                                                                                      // is
        for (int i = 0; i < nodes.size(); i++) {
            enIn.add(new TreeSet<Integer>());
            enOut.add(new TreeSet<Integer>());
        }

        // multimap
        MultiMap<Integer, Integer> degreeNodeOut = new MultiMap<Integer, Integer>(Ordering
                .natural().reverse());
        for (int i = 0; i < internalDegreeOut.size(); i++) {
            degreeNodeOut.put(internalDegreeOut.get(i), i);
        }

        List<Integer> fakes = new ArrayList<Integer>();
        for (int i = 0; i < internalDegreeIn.size(); i++) {
            fakes.add(i);
        }

        Methods.shuffleS(fakes);

        List<Integer> antifakes = new ArrayList<Integer>(fakes.size());
        for (int i = 0; i < fakes.size(); i++) {
            antifakes.add(0);
        }

        for (int i = 0; i < internalDegreeIn.size(); i++) {
            antifakes.set(fakes.get(i), i);
        }

        List<Pair> degreeNodeIn = new ArrayList<Pair>();
        for (int i = 0; i < internalDegreeIn.size(); i++) {
            degreeNodeIn.add(new Pair(internalDegreeIn.get(i), fakes.get(i)));
        }
        Collections.sort(degreeNodeIn);
        degreeNodeIn = Lists.reverse(degreeNodeIn);

        for (int i = 0; i < internalDegreeIn.size(); i++) {
            degreeNodeIn.get(i).setSecond(antifakes.get(degreeNodeIn.get(i).getSecond()));
        }

        List<Integer> selfLoop = new ArrayList<Integer>();

        int numberOfInserted = 0;

        Iterator<Pair> iteratorFromLast = degreeNodeIn.iterator();

        // TODO CHECK!
        while (iteratorFromLast.hasNext()) {
            Pair lastPair = iteratorFromLast.next();

            Iterator<Entry<Integer, Integer>> iteratorForIterator = degreeNodeOut
                    .descendingValuesIterator();

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            for (int i = 0; i < lastPair.getFirst(); i++) {

                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    if (iteratedPair.getValue() != lastPair.getSecond()) {
                        enIn.get(lastPair.getSecond()).add(iteratedPair.getValue());
                        enOut.get(iteratedPair.getValue()).add(lastPair.getSecond());
                        numberOfInserted++;

                    } else {
                        selfLoop.add(lastPair.getSecond());
                    }

                    toErase.add(iteratedPair);
                }

                else {
                    break;
                }
            }

            for (int i = 0; i < toErase.size(); i++) {

                if (toErase.get(i).getKey() > 1) {
                    degreeNodeOut.put(toErase.get(i).getKey() - 1, toErase.get(i).getValue());
                }

                degreeNodeOut.remove(toErase.get(i).getKey(), toErase.get(i).getValue());
            }
        }

        int notDone = 0;

        for (int i = 0; i < selfLoop.size(); i++) {

            int node = selfLoop.get(i);

            int stopper = internalDegreeIn.size() * internalDegreeIn.size();
            int stop = 0;

            boolean breaker = false;

            while (stop++ < stopper) {

                while (true) {

                    int randomMate = (int) (Math.random() * internalDegreeIn.size());
                    if (randomMate == node || enIn.get(node).contains(randomMate)) {
                        break;
                    }

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : enOut.get(randomMate)) {
                        if (!enOut.get(node).contains(itEst)) {
                            notCommon.add(itEst);
                        }
                    }

                    if (notCommon.isEmpty()) {
                        break;
                    }

                    int randomNeighbour = notCommon.get((int) (Math.random() * notCommon.size()));

                    enOut.get(node).add(randomNeighbour);
                    enIn.get(node).add(randomMate);

                    enIn.get(randomNeighbour).add(node);
                    enIn.get(randomMate).remove(randomMate);

                    enOut.get(randomMate).add(node);
                    enOut.get(randomMate).remove(randomNeighbour);

                    breaker = true;
                    break;
                }

                if (breaker)
                    break;

            }

            if (!breaker)
                notDone++;

        }

        // this is to randomize the subgraph
        // -------------------------------------------------------------------

        for (int nodeA = 0; nodeA < internalDegreeIn.size(); nodeA++)
            for (int krm = 0; krm < enOut.get(nodeA).size(); krm++) {

                int randomMate = (int) (Math.random() * internalDegreeIn.size());
                while (randomMate == nodeA)
                    randomMate = (int) (Math.random() * internalDegreeIn.size());

                if (!enOut.get(nodeA).contains(randomMate)) {

                    List<Integer> externalNodes = new ArrayList<Integer>();
                    for (int itEst : enOut.get(nodeA)) {
                        externalNodes.add(itEst);
                    }

                    int oldNode = externalNodes.get((int) (Math.random() * externalNodes.size()));

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : enIn.get(randomMate)) {
                        if ((oldNode != itEst) && (!enIn.get(oldNode).contains(itEst))) {
                            notCommon.add(itEst);
                        }
                    }

                    if (notCommon.isEmpty()) {
                        break;
                    }

                    int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                    enOut.get(nodeA).add(randomMate);
                    enOut.get(nodeA).remove(oldNode);

                    enIn.get(oldNode).add(nodeH);
                    enIn.get(oldNode).remove(nodeA);

                    enIn.get(randomMate).add(nodeA);
                    enIn.get(randomMate).remove(nodeH);

                    enOut.get(nodeH).remove(randomMate);
                    enOut.get(nodeH).add(oldNode);

                }

            }

        // now I try to insert the new links into the already done network. If
        // some multiple links come out, I try to rewire them

        List<Pair> multipleEdge = new ArrayList<Pair>();
        for (int i = 0; i < enIn.size(); i++) {
            for (int its : enIn.get(i)) {

                boolean already = !(adjacencyMatrixIn.get(nodes.get(i)).add(nodes.get(its)));

                if (already)
                    multipleEdge.add(new Pair(nodes.get(i), nodes.get(its)));
                else
                    adjacencyMatrixOut.get(nodes.get(its)).add(nodes.get(i));
            }
        }

        for (int i = 0; i < multipleEdge.size(); i++) {

            int a = multipleEdge.get(i).getFirst();
            int b = multipleEdge.get(i).getSecond();

            // now, I'll try to rewire this multiple link among the nodes stored
            // in nodes.
            int stopperMl = 0;

            while (true) {

                stopperMl++;

                int randomMate = nodes.get((int) (Math.random() * internalDegreeIn.size()));
                while (randomMate == a || randomMate == b) {
                    randomMate = nodes.get((int) (Math.random() * internalDegreeIn.size()));
                }
                if (!adjacencyMatrixIn.get(a).contains(randomMate)) {

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : adjacencyMatrixOut.get(randomMate)) {
                        if ((b != itEst) && (!adjacencyMatrixOut.get(b).contains(itEst))
                                && nodes.contains(itEst)) {
                            notCommon.add(itEst);
                        }
                    }
                    if (notCommon.size() > 0) {

                        int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                        adjacencyMatrixOut.get(randomMate).add(a);
                        adjacencyMatrixOut.get(randomMate).remove(nodeH);

                        adjacencyMatrixIn.get(nodeH).remove(randomMate);
                        adjacencyMatrixIn.get(randomMate).add(b);

                        adjacencyMatrixOut.get(b).add(nodeH);
                        adjacencyMatrixIn.get(a).add(randomMate);

                        break;

                    }

                }

                if (stopperMl == 2 * adjacencyMatrixIn.size()) {
                    writer.println(messages.getErrorMessage("Exception.OneLessLink"), true, true);
                    break;
                }
            }
        }
    }

    protected void connectAllTheParts(List<Set<Integer>> inAdjacencyMatrix,
            List<Set<Integer>> outAdjacencyMatrix, List<List<Integer>> memberList,
            List<List<Integer>> linkListIn, List<List<Integer>> linkListOut) {

        List<Integer> degreesIn = new ArrayList<Integer>(linkListIn.size());
        for (int i = 0; i < linkListIn.size(); i++) {
            degreesIn.add(linkListIn.get(i).get(linkListIn.get(i).size() - 1));
        }

        List<Integer> degreesOut = new ArrayList<Integer>(linkListOut.size());
        for (int i = 0; i < linkListOut.size(); i++) {
            degreesOut.add(linkListOut.get(i).get(linkListOut.get(i).size() - 1));
        }

        List<TreeSet<Integer>> enIn = new ArrayList<TreeSet<Integer>>(memberList.size());
        List<TreeSet<Integer>> enOut = new ArrayList<TreeSet<Integer>>(memberList.size());

        for (int i = 0; i < memberList.size(); i++) {
            enIn.add(new TreeSet<Integer>());
            enOut.add(new TreeSet<Integer>());
        }

        // multimap

        MultiMap<Integer, Integer> degreeNodeOut = new MultiMap<Integer, Integer>();
        List<Pair> degreeNodeIn = new ArrayList<Pair>();

        for (int i = 0; i < degreesOut.size(); i++) {
            degreeNodeOut.put(degreesOut.get(i), i);
        }

        List<Integer> fakes = new ArrayList<Integer>(degreesIn);
        for (int i = 0; i < degreesIn.size(); i++) {
            fakes.add(i);
        }

        Methods.shuffleS(fakes);

        List<Integer> antifakes = new ArrayList<Integer>(fakes.size());
        for (int i = 0; i < fakes.size(); i++) {
            antifakes.add(0);
        }

        for (int i = 0; i < degreesIn.size(); i++) {
            antifakes.set(fakes.get(i), i);
        }

        for (int i = 0; i < degreesIn.size(); i++) {
            degreeNodeIn.add(new Pair(degreesIn.get(i), fakes.get(i)));
        }

        Collections.sort(degreeNodeIn);
        degreeNodeIn = Lists.reverse(degreeNodeIn);

        for (int i = 0; i < degreesIn.size(); i++) {
            degreeNodeIn.get(i).setSecond(antifakes.get(degreeNodeIn.get(i).getSecond()));
        }

        Iterator<Pair> iteratorFrom = degreeNodeIn.iterator();

        List<Integer> selfLoop = new ArrayList<Integer>();

        while (iteratorFrom.hasNext()) {
            Pair lastPair = iteratorFrom.next();

            Iterator<Entry<Integer, Integer>> iteratorForIterator = degreeNodeOut
                    .descendingValuesIterator();

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            for (int i = 0; i < lastPair.getFirst(); i++) {
                if (iteratorForIterator.hasNext()) {

                    Entry<Integer, Integer> iteratedPair = iteratorForIterator.next();

                    if (iteratedPair.getValue() != lastPair.getSecond()) {

                        enIn.get(lastPair.getSecond()).add(iteratedPair.getValue());
                        enOut.get(iteratedPair.getValue()).add(lastPair.getSecond());

                    } else {
                        selfLoop.add(lastPair.getSecond());
                    }

                    toErase.add(iteratedPair);
                }

                else {
                    break;
                }
            }

            for (int i = 0; i < toErase.size(); i++) {
                if (toErase.get(i).getKey() > 1) {
                    degreeNodeOut.put(toErase.get(i).getKey() - 1, toErase.get(i).getValue());
                }

                degreeNodeOut.remove(toErase.get(i).getKey(), toErase.get(i).getValue());

            }

        }

        for (int i = 0; i < selfLoop.size(); i++) {

            int node = selfLoop.get(i);

            int stopper = degreesIn.size() * degreesIn.size();
            int stop = 0;

            boolean breaker = false;

            while (stop++ < stopper) {

                while (true) {

                    int randomMate = (int) (Math.random() * degreesIn.size());
                    if (randomMate == node || enIn.get(node).contains(randomMate)) {
                        break;
                    }

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : enOut.get(randomMate)) {
                        if (!enOut.get(node).contains(itEst)) {
                            notCommon.add(itEst);
                        }
                    }

                    if (notCommon.isEmpty()) {
                        break;
                    }

                    int randomNeighbour = notCommon.get((int) (Math.random() * notCommon.size()));

                    enOut.get(node).add(randomNeighbour);
                    enIn.get(node).add(randomMate);

                    enIn.get(randomNeighbour).add(node);
                    enIn.get(randomMate).remove(randomMate);

                    enOut.get(randomMate).add(node);
                    enOut.get(randomMate).remove(randomNeighbour);

                    breaker = true;
                    break;

                }

                if (breaker) {
                    break;
                }
            }
        }

        // this is to randomize the subgraph
        // -------------------------------------------------------------------

        // this is to randomize the subgraph
        // -------------------------------------------------------------------

        for (int nodeA = 0; nodeA < degreesIn.size(); nodeA++) {
            for (int krm = 0; krm < enOut.get(nodeA).size(); krm++) {

                int randomMate = (int) (Math.random() * degreesIn.size());
                while (randomMate == nodeA) {
                    randomMate = (int) (Math.random() * degreesIn.size());
                }

                if (!enOut.get(nodeA).contains(randomMate)) {

                    List<Integer> externalNodes = new ArrayList<Integer>();
                    for (int itEst : enOut.get(nodeA)) {
                        externalNodes.add(itEst);
                    }
                    int oldNode = externalNodes.get((int) (Math.random() * externalNodes.size()));

                    List<Integer> notCommon = new ArrayList<Integer>();
                    for (int itEst : enIn.get(randomMate)) {
                        if ((oldNode != itEst) && (!enIn.get(oldNode).contains(itEst))) {
                            notCommon.add(itEst);
                        }
                    }
                    if (notCommon.isEmpty()) {
                        break;
                    }

                    int nodeH = notCommon.get((int) (Math.random() * notCommon.size()));

                    enOut.get(nodeA).add(randomMate);
                    enOut.get(nodeA).remove(oldNode);

                    enIn.get(oldNode).add(nodeH);
                    enIn.get(oldNode).remove(nodeA);

                    enIn.get(randomMate).add(nodeA);
                    enIn.get(randomMate).remove(nodeH);

                    enOut.get(nodeH).remove(randomMate);
                    enOut.get(nodeH).add(oldNode);

                }
            }
        }

        // now there is a rewiring process to avoid "mate nodes" (nodes with al
        // least one membership in common) to link each other

        int varMate = Methods.computeVarMate(enIn, memberList);

        int stopperMate = 0;
        int mateTrooper = 10;

        while (varMate > 0) {
            int bestVarMate = varMate;

            // ************************************************ rewiring

            for (int a = 0; a < degreeNodeIn.size(); a++) {
                for (int its : enIn.get(a)) {
                    if (Methods.theyAreMate(a, its, memberList)) {
                        int b = its;
                        int stopperM = 0;

                        while (true) {
                            stopperM++;

                            int randomMate = (int) (Math.random() * degreesIn.size());
                            while (randomMate == a || randomMate == b) {
                                randomMate = (int) (Math.random() * degreesIn.size());
                            }

                            if (!(Methods.theyAreMate(a, randomMate, memberList))
                                    && (!enIn.get(a).contains(randomMate))) {
                                List<Integer> notCommon = new ArrayList<Integer>();
                                for (int itEst : enOut.get(randomMate)) {
                                    if ((b != itEst) && (!enOut.get(b).contains(itEst))) {
                                        notCommon.add(itEst);
                                    }
                                }

                                if (notCommon.size() > 0) {
                                    int nodeH = notCommon.get((int) (Math.random() * notCommon
                                            .size()));

                                    enOut.get(randomMate).remove(nodeH);
                                    enOut.get(randomMate).add(a);

                                    enIn.get(nodeH).remove(randomMate);
                                    enIn.get(nodeH).add(b);

                                    enOut.get(b).remove(a);
                                    enOut.get(b).add(nodeH);

                                    enIn.get(a).add(randomMate);
                                    enIn.get(a).remove(b);

                                    if (!Methods.theyAreMate(b, nodeH, memberList)) {
                                        varMate--;
                                    }

                                    if (Methods.theyAreMate(randomMate, nodeH, memberList))
                                        varMate--;

                                    break;

                                }

                            }

                            if (stopperM == enIn.get(a).size())
                                break;

                        }

                        break; // this break is done because if you erased some
                               // link you have to stop this loop (en[i]
                               // changed)

                    }
                }
            }

            // ************************************************ rewiring

            if (varMate == bestVarMate) {
                stopperMate++;

                if (stopperMate == mateTrooper) {
                    break;
                }

            } else {
                stopperMate = 0;
            }
        }

        for (int i = 0; i < enIn.size(); i++) {

            for (int its : enIn.get(i)) {
                inAdjacencyMatrix.get(i).add(its);
                outAdjacencyMatrix.get(its).add(i);
            }

        }

    }

    protected void initializeLayers(Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListInML,
            Map<Integer, List<List<Integer>>> linkListOutML) {
        List<List<Integer>> baseMemberList = memberListML.get(0);
        List<List<Integer>> baseLinkListIn = linkListInML.get(0);
        List<List<Integer>> baseLinkListOut = linkListOutML.get(0);
        List<List<Integer>> baseMemberMatrix = memberMatrixML.get(0);

        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            List<List<Integer>> memberListLayer = memberListML.get(layer);
            List<List<Integer>> linkListInLayer = linkListInML.get(layer);
            List<List<Integer>> linkListOutLayer = linkListOutML.get(layer);
            for (int i = 0; i < baseMemberList.size(); i++) {
                memberListLayer.add(new ArrayList<Integer>(baseMemberList.get(i)));
                linkListInLayer.add(new ArrayList<Integer>(baseLinkListIn.get(i)));
                linkListOutLayer.add(new ArrayList<Integer>(baseLinkListOut.get(i)));
            }

            List<List<Integer>> memberMatrixLayer = memberMatrixML.get(layer);
            for (int i = 0; i < baseMemberMatrix.size(); i++)
                memberMatrixLayer.add(new ArrayList<Integer>(baseMemberMatrix.get(i)));
        }
    }

    protected void buildLayers(List<T> layers, Map<Integer, List<List<Integer>>> memberMatrixML,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListInML,
            Map<Integer, List<List<Integer>>> linkListOutML) throws BenchmarkException {
        for (int group = 0; group < memberMatrixML.get(0).size(); group++) {
            Map<Integer, List<Integer>> fs = new HashMap<Integer, List<Integer>>();
            for (int layer = 0; layer < layers.size(); layer++) {
                fs.put(layer, memberMatrixML.get(layer).get(group));
            }
            buildSubgraphLayer(layers, fs, memberListML, linkListInML, linkListOutML, group);
        }
    }

    protected void buildSubgraphLayer(List<T> layers, Map<Integer, List<Integer>> fs,
            Map<Integer, List<List<Integer>>> memberListML,
            Map<Integer, List<List<Integer>>> linkListInML,
            Map<Integer, List<List<Integer>>> linkListOutML, int group) throws BenchmarkException {

        Map<Integer, MultiMap<Integer, Integer>> mapDegreeNodeOut = new HashMap<Integer, MultiMap<Integer, Integer>>();
        Map<Integer, List<Pair>> mapDegreeNodeIn = new HashMap<Integer, List<Pair>>();
        Map<Integer, List<Integer>> selfLoop = new HashMap<Integer, List<Integer>>();

        for (int layerIndex = 1; layerIndex < parameters.getNumberOfLayers(); layerIndex++) {
            selfLoop.put(layerIndex, new ArrayList<Integer>());
            mapDegreeNodeOut.put(layerIndex, new MultiMap<Integer, Integer>());
            for (int node : fs.get(layerIndex)) {
                int rightIndex = Methods.lowerBound(memberListML.get(layerIndex).get(node), group);
                int internalDegree = linkListOutML.get(layerIndex).get(node).get(rightIndex);
                mapDegreeNodeOut.get(layerIndex).put(internalDegree, node);
            }

            mapDegreeNodeIn.put(layerIndex, new ArrayList<Pair>());
            for (int node : fs.get(layerIndex)) {
                int rightIndex = Methods.lowerBound(memberListML.get(layerIndex).get(node), group);
                int internalDegree = linkListInML.get(layerIndex).get(node).get(rightIndex);
                mapDegreeNodeIn.get(layerIndex).add(new Pair(internalDegree, node));
            }
            Collections.sort(mapDegreeNodeIn.get(layerIndex));
        }

        List<Integer> layersToDo = new ArrayList<Integer>(parameters.getNumberOfLayers());
        for (int layer = 1; layer < parameters.getNumberOfLayers(); layer++) {
            layersToDo.add(layer);
        }

        while (layersToDo.size() != 0) {
            int layerIndex = (int) (Math.random() * layersToDo.size());
            int layer = layersToDo.get(layerIndex);

            DirectedNetwork baseLayer = layers.get(0);
            DirectedNetwork currentLayer = layers.get(layer);

            // FIRST ROUND
            ListIterator<Pair> itlast = mapDegreeNodeIn.get(layer).listIterator(
                    mapDegreeNodeIn.get(layer).size());
            Pair lastPair = itlast.previous();
            int insertedInFirstRound = 0;

            if (memberListML.get(0).get(lastPair.getSecond()).contains(group)) {
                // The list of all possible neighbour propositions
                List<Integer> nodeNeighbours = new LinkedList<Integer>();
                List<Integer> insertedNodeNeighbours = new LinkedList<Integer>();

                for (int nodeNeighbour : baseLayer.getInAdjacencyMatrix().get(lastPair.getSecond())) {

                    if (!currentLayer.getInAdjacencyMatrix().get(lastPair.getSecond())
                            .contains(nodeNeighbour)
                            && nodeNeighbour != lastPair.getSecond()
                            && memberListML.get(layer).get(nodeNeighbour).contains(group)
                            && linkListOutML
                                    .get(layer)
                                    .get(nodeNeighbour)
                                    .get(Methods.lowerBound(
                                            memberListML.get(layer).get(nodeNeighbour), group)) != currentLayer
                                    .getOutAdjacencyMatrix().get(nodeNeighbour).size())
                        nodeNeighbours.add(nodeNeighbour);
                }

                int rightIndex = Methods.lowerBound(
                        memberListML.get(layer).get(lastPair.getSecond()), group);
                int maxNeighbours = linkListInML.get(layer).get(lastPair.getSecond())
                        .get(rightIndex)
                        - currentLayer.getInAdjacencyMatrix().get(lastPair.getSecond()).size(); // �le

                while (nodeNeighbours.size() > 0 && insertedInFirstRound < maxNeighbours) {
                    int neighbourPropositionIndex = (int) (Math.random() * nodeNeighbours.size());
                    int neighbourProposition = nodeNeighbours.get(neighbourPropositionIndex);

                    int count = Methods.neighboursCountIn(layers, lastPair.getSecond(),
                            neighbourProposition);

                    try {
                        if (Math.random() >= parameters.getDistribution().cumulativeProbability(
                                count)) {
                            // na odwr�t eIn i eOut?
                            if (currentLayer.getInAdjacencyMatrix().get(lastPair.getSecond())
                                    .add(neighbourProposition)) {
                                currentLayer.getOutAdjacencyMatrix().get(neighbourProposition)
                                        .add(lastPair.getSecond());
                                insertedNodeNeighbours.add(neighbourProposition);
                                insertedInFirstRound++;
                            }
                        }
                    } catch (MathException me) {
                        throw new BenchmarkException("Distribution library internal error.");
                    }

                    nodeNeighbours.remove(neighbourPropositionIndex);
                }
                // W�a�nie zaproponowali�my wszystkich s�siad�w z listy
                // wzorcowej

                for (int i = 0; i < insertedNodeNeighbours.size(); i++) {
                    int toRemove = insertedNodeNeighbours.get(i);
                    int rightLinkListIndex = Methods.lowerBound(
                            memberListML.get(layer).get(lastPair.getSecond()), group);
                    int first = linkListOutML.get(layer).get(toRemove).get(rightLinkListIndex)
                            - (currentLayer.getOutAdjacencyMatrix().get(toRemove).size() - 1);

                    mapDegreeNodeOut.get(layer).remove(first, toRemove);

                    if (first > 1) {
                        mapDegreeNodeOut.get(layer).put(first - 1, toRemove);
                    }
                }
            }

            Iterator<Entry<Integer, Integer>> iteratorForIterator = mapDegreeNodeOut.get(layer)
                    .descendingValuesIterator();

            List<Entry<Integer, Integer>> toErase = new ArrayList<Entry<Integer, Integer>>();

            // powinno sie zaczynac od ostatniego
            Iterator<Entry<Integer, Integer>> fastCalculate = mapDegreeNodeOut.get(layer)
                    .descendingValuesIterator();

            int sum = 0;
            while (fastCalculate.hasNext()) {
                Entry<Integer, Integer> fastPair = fastCalculate.next();
                if (currentLayer.getOutAdjacencyMatrix().get(fastPair.getValue())
                        .contains(lastPair.getSecond()))
                    sum++;
            }

            int jumpNumber = mapDegreeNodeOut.get(layer).size() - lastPair.getFirst() - sum
                    + insertedInFirstRound;

            for (int i = 0; i < lastPair.getFirst() - insertedInFirstRound; i++) {
                if (iteratorForIterator.hasNext()) {
                    Entry<Integer, Integer> ititPair = iteratorForIterator.next();

                    try {
                        // dasdsadsada to samo :/
                        int count = Methods.neighboursCount(layers, lastPair.getSecond(),
                                ititPair.getValue());
                        double random = Math.random();
                        double treshold = parameters.getDistribution().cumulativeProbability(count);

                        // docelowy? Ein
                        boolean contains = currentLayer.getInAdjacencyMatrix()
                                .get(lastPair.getSecond()).contains(ititPair.getValue());
                        while ((contains || (random < treshold && jumpNumber > 0))
                                && iteratorForIterator.hasNext()) {
                            boolean toContinue = contains;
                            ititPair = iteratorForIterator.next();
                            contains = currentLayer.getInAdjacencyMatrix()
                                    .get(lastPair.getSecond()).contains(ititPair.getValue());

                            count = Methods.neighboursCount(layers, lastPair.getSecond(),
                                    ititPair.getValue());
                            random = Math.random();
                            treshold = parameters.getDistribution().cumulativeProbability(count);

                            if (toContinue) {
                                continue;
                            } else {
                                jumpNumber--;
                            }
                        }

                        if (currentLayer.getInAdjacencyMatrix().get(lastPair.getSecond())
                                .contains(ititPair.getValue())
                                || (random < treshold && jumpNumber > 0)) {
                            break;
                        }
                    } catch (MathException me) {

                    }

                    if (currentLayer.getInAdjacencyMatrix().get(lastPair.getSecond())
                            .add(ititPair.getValue())) {
                        currentLayer.getOutAdjacencyMatrix().get(ititPair.getValue())
                                .add(lastPair.getSecond());
                        toErase.add(ititPair);

                        if (lastPair.getSecond() == ititPair.getValue()) {
                            selfLoop.get(layer).add(lastPair.getSecond());
                        }
                    }
                } else {

                    break;
                }
            }

            for (int i = 0; i < toErase.size(); i++) {
                if (toErase.get(i).getKey() > 1)
                    mapDegreeNodeOut.get(layer).put(toErase.get(i).getKey() - 1,
                            toErase.get(i).getValue());

                mapDegreeNodeOut.get(layer).remove(toErase.get(i).getKey(),
                        toErase.get(i).getValue());
            }
            mapDegreeNodeIn.get(layer).remove(mapDegreeNodeIn.get(layer).size() - 1);

            if (mapDegreeNodeIn.get(layer).size() == 0) {
                layersToDo.remove(layerIndex);
            }
        }

        for (Map.Entry<Integer, List<Integer>> entry : selfLoop.entrySet()) {
            for (int i = 0; i < entry.getValue().size(); i++) {
                int node = entry.getValue().get(i);

                int stopper = fs.get(entry.getKey()).size() * fs.get(entry.getKey()).size();
                int stop = 0;

                boolean breaker = false;

                List<Set<Integer>> inAdjacencyMatrix = layers.get(entry.getKey())
                        .getInAdjacencyMatrix();
                List<Set<Integer>> outAdjacencyMatrix = layers.get(entry.getKey())
                        .getOutAdjacencyMatrix();

                while (stop++ < stopper) {

                    while (true) {
                        int randomIndex = (int) (Math.random() * fs.get(entry.getKey()).size());
                        int randomMate = fs.get(entry.getKey()).get(randomIndex);
                        if (randomMate == node || inAdjacencyMatrix.get(node).contains(randomMate))
                            break;

                        List<Integer> notCommon = new ArrayList<Integer>();
                        for (int itEst : outAdjacencyMatrix.get(randomMate))
                            if (!outAdjacencyMatrix.get(node).contains(itEst))
                                notCommon.add(itEst);

                        if (notCommon.isEmpty()) {
                            break;
                        }

                        int randomNeighbour = notCommon
                                .get((int) (Math.random() * notCommon.size()));

                        outAdjacencyMatrix.get(node).add(randomNeighbour);
                        inAdjacencyMatrix.get(node).add(randomMate);

                        inAdjacencyMatrix.get(randomNeighbour).add(node);
                        inAdjacencyMatrix.get(randomMate).remove(randomMate);

                        outAdjacencyMatrix.get(randomMate).add(node);
                        outAdjacencyMatrix.get(randomMate).remove(randomNeighbour);

                        breaker = true;
                        break;

                    }

                    if (breaker)
                        break;

                }

                if (!breaker) {
                    inAdjacencyMatrix.get(node).remove(node);
                    outAdjacencyMatrix.get(node).remove(node);

                }
            }
        }
    }

    protected void getDegreeSequences(List<Integer> inDegreeSequence,
            List<Integer> outDegreeSequence) {
        List<Double> cumulative = Methods.powerlaw(parameters.getMaxDegree(),
                parameters.getMinDegree(), parameters.getTau());
        for (int i = 0; i < parameters.getNumberOfNodes(); i++) {
            int nn = Methods.lowerBound(cumulative, Math.random()) + parameters.getMinDegree();
            inDegreeSequence.add(nn);
        }

        Collections.sort(inDegreeSequence);

        int inarcs = Methods.degreeSum(inDegreeSequence);
        Methods.computeInternalDegreePerNode(inarcs, inDegreeSequence.size(), outDegreeSequence);
    }

}
