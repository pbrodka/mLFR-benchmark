package com.pl.wroc.pwr.ii.zsi.jlfr.gui.table;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.text.JTextComponent;

import com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors.ParameterCellEditor;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.celleditors.ParameterCellFactory;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.cellrenderers.ParameterCellRenderer;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel.ParameterRow;
import com.pl.wroc.pwr.ii.zsi.jlfr.gui.tablemodel.ParameterTableModel;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.InputType;
import com.pl.wroc.pwr.ii.zsi.jlfr.parameters.KeyMapping;

public class ParameterTable extends JTable {

    private String[] columnsNames = { "Key", "Value" };

    private ParameterTableModel model;
    private ParameterCellEditor[] parameterEditors;

    public ParameterTable(ParameterTableModel model) {
        super.setModel(model);
        this.model = model;
        this.setColumnSelectionAllowed(true);
        this.setRowSelectionAllowed(true);
        this.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        initiate(model);
    }

    private void initiate(ParameterTableModel model) {
        parameterEditors = new ParameterCellEditor[model.getRowCount()];
        for (int rowIndex = 0; rowIndex < model.getRowCount(); rowIndex++) {
            ParameterRow row = model.getRow(rowIndex);
            KeyMapping keyMapping = row.getKeyMapping();

            parameterEditors[rowIndex] = ParameterCellFactory.createParameterCellEditor(this,
                    keyMapping.getInputType(), keyMapping.getMinimum(), keyMapping.getMaximum());
        }

        this.getColumnModel().getColumn(1).setCellRenderer(new ParameterCellRenderer());
    }

    public Component prepareRenderer(TableCellRenderer renderer, int rowIndex, int colIndex) {
        Component c = super.prepareRenderer(renderer, rowIndex, colIndex);
        if (rowIndex % 2 == 0) {
            c.setBackground(new Color(0.95f, 0.95f, 0.95f));
        } else {
            c.setBackground(getBackground());
        }
        if (isCellSelected(rowIndex, colIndex)) {
            c.setBackground(new Color(0.80f, 0.80f, 0.80f));
        }
        return c;
    }

    public TableCellEditor getCellEditor(int row, int column) {
        if (column != 0 && parameterEditors[row] != null) {
            return parameterEditors[row];
        }
        return super.getCellEditor(row, column);
    }

    public InputType getInputTypeForRow(int rowIndex) {
        return model.getRow(rowIndex).getKeyMapping().getInputType();
    }

    public String getColumnName(int col) {
        return columnsNames[col];
    }

    @Override
    public void changeSelection(int row, int column, boolean toggle, boolean extend) {
        super.changeSelection(row, column, toggle, extend);

        if (editCellAt(row, column)) {
            Component editor = getEditorComponent();
            editor.requestFocusInWindow();
            ((JTextComponent) editor).selectAll();
        }
    }

    public void setModel(TableModel model) {
        super.setModel(model);
        if (model instanceof ParameterTableModel) {
            // this.model = (ParameterTableModel) model;
            ParameterTableModel parameterModel = (ParameterTableModel) model;
            initiate(parameterModel);
        }
    }
}
